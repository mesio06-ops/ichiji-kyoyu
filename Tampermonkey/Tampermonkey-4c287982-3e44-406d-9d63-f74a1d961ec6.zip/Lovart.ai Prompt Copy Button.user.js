// ==UserScript==
// @name         Lovart.ai Prompt Copy Button
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  lovart.aiのチャットツールのプロンプト指示箇所にコピーボタンを追加
// @author       You
// @match        https://lovart.ai/*
// @match        https://*.lovart.ai/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // コピーボタンのスタイルを追加
    const style = document.createElement('style');
    style.textContent = `
        .lovart-copy-button {
            position: absolute;
            bottom: 8px;
            right: 8px;
            padding: 6px 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.2s ease;
            z-index: 10;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .lovart-copy-button:hover {
            background-color: #45a049;
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }

        .lovart-copy-button:active {
            transform: scale(0.95);
        }

        .lovart-copy-button.copied {
            background-color: #2196F3;
        }

        .agent-chat-user-input-text-container {
            position: relative !important;
        }
    `;
    document.head.appendChild(style);

    // コピーボタンを作成する関数
    function createCopyButton(textElement) {
        const button = document.createElement('button');
        button.className = 'lovart-copy-button';
        button.textContent = 'コピー';

        button.addEventListener('click', async (e) => {
            e.stopPropagation();
            const text = textElement.textContent;

            try {
                await navigator.clipboard.writeText(text);
                button.textContent = 'コピー完了！';
                button.classList.add('copied');

                setTimeout(() => {
                    button.textContent = 'コピー';
                    button.classList.remove('copied');
                }, 2000);
            } catch (err) {
                console.error('コピーに失敗しました:', err);
                button.textContent = 'エラー';
                setTimeout(() => {
                    button.textContent = 'コピー';
                }, 2000);
            }
        });

        return button;
    }

    // メッセージ要素にコピーボタンを追加
    function addCopyButtons() {
        // ユーザー入力のテキストコンテナを取得
        const containers = document.querySelectorAll('.agent-chat-user-input-text-container');

        containers.forEach(container => {
            // 既にボタンが追加されている場合はスキップ
            if (container.querySelector('.lovart-copy-button')) {
                return;
            }

            // テキスト要素を取得
            const textElement = container.querySelector('div[class*="rounded-lg"]');

            if (textElement) {
                // コピーボタンを追加
                const copyButton = createCopyButton(textElement);
                container.style.position = 'relative';
                container.appendChild(copyButton);
            }
        });
    }

    // 初期実行
    setTimeout(addCopyButtons, 500);

    // DOMの変更を監視して新しいメッセージにもボタンを追加
    const observer = new MutationObserver((mutations) => {
        let shouldUpdate = false;

        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === 1) {
                    if (node.classList && (
                        node.classList.contains('agent-chat-user-input') ||
                        node.querySelector('.agent-chat-user-input-text-container')
                    )) {
                        shouldUpdate = true;
                    }
                }
            });
        });

        if (shouldUpdate) {
            setTimeout(addCopyButtons, 100);
        }
    });

    // チャットセッションのコンテナを監視
    const chatContainer = document.querySelector('#agent-chat-sessions');
    if (chatContainer) {
        observer.observe(chatContainer, {
            childList: true,
            subtree: true
        });
    } else {
        // コンテナが見つからない場合はbody全体を監視
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    console.log('Lovart.ai Prompt Copy Button スクリプトが起動しました');
})();