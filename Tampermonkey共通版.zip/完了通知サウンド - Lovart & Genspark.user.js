// ==UserScript==
// @name         完了通知サウンド - Lovart & Genspark
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  lovart.aiとgenspark.aiで「完了しました」「完成しました」が表示されたら通知音を鳴らす
// @author       You
// @match        https://www.lovart.ai/*
// @match        https://lovart.ai/*
// @match        https://www.genspark.ai/*
// @match        https://genspark.ai/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 通知音を生成する関数（Web Audio APIを使用）
    function playNotificationSound() {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();

        // 2音の通知音を作成
        const playTone = (frequency, startTime, duration) => {
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();

            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);

            oscillator.frequency.value = frequency;
            oscillator.type = 'sine';

            gainNode.gain.setValueAtTime(0.3, startTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration);

            oscillator.start(startTime);
            oscillator.stop(startTime + duration);
        };

        const now = audioContext.currentTime;
        playTone(523.25, now, 0.15);        // C5
        playTone(659.25, now + 0.15, 0.15); // E5
        playTone(783.99, now + 0.3, 0.3);   // G5
    }

    // 検出するキーワード
    const keywords = ['完了しました', '完成しました'];

    // 既に通知済みのテキストを追跡（重複通知防止）
    let notifiedTexts = new Set();

    // ページ内のテキストをチェックする関数
    function checkForCompletion() {
        const bodyText = document.body.innerText;

        for (const keyword of keywords) {
            if (bodyText.includes(keyword)) {
                // このキーワードを含む要素を特定
                const elements = document.querySelectorAll('*');
                for (const el of elements) {
                    if (el.children.length === 0 && el.innerText && el.innerText.includes(keyword)) {
                        const textKey = el.innerText.trim();
                        if (!notifiedTexts.has(textKey)) {
                            notifiedTexts.add(textKey);
                            console.log(`[完了通知] 検出: "${keyword}"`);
                            playNotificationSound();
                            return; // 1回の検出につき1回だけ音を鳴らす
                        }
                    }
                }
            }
        }
    }

    // MutationObserverでDOM変更を監視
    const observer = new MutationObserver((mutations) => {
        checkForCompletion();
    });

    // ページ読み込み完了後に監視開始
    window.addEventListener('load', () => {
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            characterData: true
        });

        // 初回チェック
        checkForCompletion();

        console.log('[完了通知] 監視を開始しました - lovart.ai / genspark.ai');
    });

})();