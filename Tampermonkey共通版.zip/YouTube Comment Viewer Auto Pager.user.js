// ==UserScript==
// @name         YouTube Comment Viewer Auto Pager
// @namespace    https://commentviewer.com/
// @version      1.2.0
// @description  commentviewer.comで「Show more comments...」ボタンを自動クリック（スタート・ストップ機能付き）
// @author       AutoPager
// @match        https://commentviewer.com/*
// @match        http://commentviewer.com/*
// @match        https://*.commentviewer.com/*
// @match        http://*.commentviewer.com/*
// @grant        GM_addStyle
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    // **設定とグローバル変数**
    let isRunning = false;
    let autoClickInterval = null;
    let clickCount = 0;
    let ui = null;

    // **CSSスタイルの追加**
    GM_addStyle(`
        #cv-autopager-panel {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            border: 2px solid #007bff;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            z-index: 99999;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
            min-width: 250px;
            backdrop-filter: blur(5px);
        }

        #cv-autopager-panel .title {
            font-weight: bold;
            color: #333;
            margin-bottom: 12px;
            text-align: center;
            border-bottom: 1px solid #eee;
            padding-bottom: 8px;
        }

        #cv-autopager-panel .control-row {
            display: flex;
            gap: 8px;
            margin-bottom: 10px;
            align-items: center;
        }

        #cv-autopager-panel .control-row label {
            min-width: 60px;
            font-size: 12px;
            color: #666;
        }

        #cv-autopager-panel input[type="number"] {
            width: 60px;
            padding: 4px 6px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 12px;
        }

        #cv-autopager-panel .button-row {
            display: flex;
            gap: 8px;
            margin-bottom: 10px;
        }

        #cv-autopager-panel button {
            flex: 1;
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            font-size: 12px;
            transition: all 0.2s ease;
        }

        #cv-autopager-panel .start-btn {
            background: #28a745;
            color: white;
        }

        #cv-autopager-panel .start-btn:hover:not(:disabled) {
            background: #218838;
            transform: translateY(-1px);
        }

        #cv-autopager-panel .stop-btn {
            background: #dc3545;
            color: white;
        }

        #cv-autopager-panel .stop-btn:hover:not(:disabled) {
            background: #c82333;
            transform: translateY(-1px);
        }

        #cv-autopager-panel button:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none !important;
        }

        #cv-autopager-panel .status {
            font-size: 11px;
            color: #666;
            text-align: center;
            padding: 5px;
            background: #f8f9fa;
            border-radius: 4px;
            margin-bottom: 8px;
        }

        #cv-autopager-panel .stats {
            font-size: 11px;
            color: #666;
            display: flex;
            justify-content: space-between;
        }
    `);

    // **Show moreボタンの検出と検証**
    function findShowMoreButton() {
        // 複数のセレクタでボタンを探す
        const selectors = [
            '#showMoreBtn',
            '#showMoreDiv .loadMore',
            'button.loadMore',
            '.card-footer button'
        ];

        for (const selector of selectors) {
            const button = document.querySelector(selector);
            if (button) return button;
        }
        return null;
    }

    function isButtonClickable(button) {
        if (!button) return false;

        // disabled状態をチェック
        if (button.disabled) return false;

        // 表示状態をチェック
        const style = window.getComputedStyle(button);
        if (style.display === 'none' || style.visibility === 'hidden') return false;

        // 親要素の表示状態もチェック
        const parentDiv = button.closest('#showMoreDiv');
        if (parentDiv) {
            const parentStyle = window.getComputedStyle(parentDiv);
            if (parentStyle.display === 'none') return false;
        }

        // ローディング状態をチェック
        const buttonText = (button.textContent || '').toLowerCase();
        if (buttonText.includes('loading') || buttonText.includes('読み込み中')) return false;

        return true;
    }

    // **自動クリック処理**
    async function performAutoClick() {
        const button = findShowMoreButton();

        if (!isButtonClickable(button)) {
            updateStatus('ボタンが見つかりません...');
            return false;
        }

        try {
            // ボタンが画面外にある場合はスクロール
            const rect = button.getBoundingClientRect();
            if (rect.top < 0 || rect.bottom > window.innerHeight) {
                button.scrollIntoView({ behavior: 'smooth', block: 'center' });
                await new Promise(resolve => setTimeout(resolve, 300));
            }

            // クリック実行
            button.click();
            clickCount++;
            updateStats();
            updateStatus(`クリック完了 (${new Date().toLocaleTimeString()})`);

            return true;
        } catch (error) {
            console.error('AutoPager: クリックエラー', error);
            updateStatus('クリックエラーが発生しました');
            return false;
        }
    }

    // **UI更新関数**
    function updateStatus(message) {
        if (ui && ui.status) {
            ui.status.textContent = message;
        }
    }

    function updateStats() {
        if (ui && ui.clickCounter) {
            ui.clickCounter.textContent = clickCount;
        }
    }

    function updateButtons() {
        if (!ui) return;

        ui.startBtn.disabled = isRunning;
        ui.stopBtn.disabled = !isRunning;

        if (isRunning) {
            updateStatus('自動クリック実行中...');
        } else {
            updateStatus('停止中');
        }
    }

    // **自動クリック開始**
    async function startAutoClick() {
        if (isRunning) return;

        const intervalSeconds = parseInt(ui.intervalInput.value) || 2;
        const intervalMs = intervalSeconds * 1000;

        isRunning = true;
        updateButtons();

        console.log(`AutoPager: 自動クリック開始 (間隔: ${intervalSeconds}秒)`);

        // 初回クリック
        await performAutoClick();

        // 定期実行
        autoClickInterval = setInterval(async () => {
            if (!isRunning) return;

            const success = await performAutoClick();

            // 連続でボタンが見つからない場合は自動停止
            if (!success) {
                let retryCount = 0;
                const maxRetries = 5;

                const retryInterval = setInterval(async () => {
                    retryCount++;
                    const retrySuccess = await performAutoClick();

                    if (retrySuccess || retryCount >= maxRetries) {
                        clearInterval(retryInterval);
                        if (!retrySuccess && retryCount >= maxRetries) {
                            updateStatus('ボタンが見つからないため自動停止しました');
                            stopAutoClick();
                        }
                    }
                }, 1000);
            }
        }, intervalMs);
    }

    // **自動クリック停止**
    function stopAutoClick() {
        if (!isRunning) return;

        isRunning = false;
        if (autoClickInterval) {
            clearInterval(autoClickInterval);
            autoClickInterval = null;
        }

        updateButtons();
        console.log('AutoPager: 自動クリック停止');
    }

    // **UI作成**
    function createUI() {
        if (document.getElementById('cv-autopager-panel')) return;

        const panel = document.createElement('div');
        panel.id = 'cv-autopager-panel';

        panel.innerHTML = `
            <div class="title">Comment Auto Loader</div>

            <div class="status">待機中</div>

            <div class="control-row">
                <label>間隔:</label>
                <input type="number" id="cv-interval" value="2" min="1" max="30">
                <span style="font-size: 11px; color: #999;">秒</span>
            </div>

            <div class="button-row">
                <button class="start-btn" id="cv-start">スタート</button>
                <button class="stop-btn" id="cv-stop" disabled>ストップ</button>
            </div>

            <div class="stats">
                <span>クリック数: <span id="cv-counter">0</span></span>
                <span id="cv-time">--:--:--</span>
            </div>
        `;

        document.body.appendChild(panel);

        // UI要素の参照を保存
        ui = {
            panel: panel,
            status: panel.querySelector('.status'),
            intervalInput: panel.querySelector('#cv-interval'),
            startBtn: panel.querySelector('#cv-start'),
            stopBtn: panel.querySelector('#cv-stop'),
            clickCounter: panel.querySelector('#cv-counter'),
            timeDisplay: panel.querySelector('#cv-time')
        };

        // イベントリスナー設定
        ui.startBtn.addEventListener('click', startAutoClick);
        ui.stopBtn.addEventListener('click', stopAutoClick);

        // ESCキーで停止
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && isRunning) {
                stopAutoClick();
            }
        });

        // 時刻表示更新
        setInterval(() => {
            if (ui.timeDisplay) {
                ui.timeDisplay.textContent = new Date().toLocaleTimeString();
            }
        }, 1000);

        console.log('AutoPager: UI初期化完了');
    }

    // **初期化**
    function initialize() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initialize);
            return;
        }

        // 少し遅延してからUI作成（ページの読み込み完了を待つ）
        setTimeout(createUI, 1000);
    }

    // **実行開始**
    initialize();
})();