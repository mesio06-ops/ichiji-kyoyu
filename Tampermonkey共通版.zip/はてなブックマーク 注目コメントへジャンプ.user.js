// ==UserScript==
// @name         はてなブックマーク 注目コメントへジャンプ
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  注目コメント算出アルゴリズムの説明文までスクロールするボタンを追加
// @author       You
// @match        https://b.hatena.ne.jp/entry/*
// @match        https://b.hatena.ne.jp/entry/s/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // ページが完全に読み込まれるまで待機
    function init() {
        // ボタンを作成
        const button = document.createElement('button');
        button.textContent = '注目コメントへ';
        button.id = 'jump-to-featured-comments';
        button.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 9999;
            padding: 12px 20px;
            background-color: #00a4de;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
            transition: background-color 0.3s;
        `;

        // ホバー時のスタイル
        button.addEventListener('mouseenter', function() {
            this.style.backgroundColor = '#0090c8';
        });
        button.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '#00a4de';
        });

        // クリック時の動作
        button.addEventListener('click', function() {
            // 複数のパターンで検索
            const patterns = [
                '注目コメント算出アルゴリズムの一部にLINEヤフー株式会社の「建設的コメント順位付けモデルAPI」を使用しています',
                '注目コメント算出アルゴリズム',
                'LINEヤフー株式会社'
            ];

            let targetElement = null;

            // テキストノードを含む全要素を検索
            const walker = document.createTreeWalker(
                document.body,
                NodeFilter.SHOW_TEXT,
                null,
                false
            );

            let node;
            while (node = walker.nextNode()) {
                for (let pattern of patterns) {
                    if (node.textContent.includes(pattern)) {
                        targetElement = node.parentElement;
                        break;
                    }
                }
                if (targetElement) break;
            }

            if (targetElement) {
                // スムーズにスクロール
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });

                // 一時的にハイライト
                const originalBg = targetElement.style.backgroundColor;
                const originalTransition = targetElement.style.transition;
                targetElement.style.transition = 'background-color 0.3s';
                targetElement.style.backgroundColor = '#fff799';
                setTimeout(() => {
                    targetElement.style.backgroundColor = originalBg;
                    setTimeout(() => {
                        targetElement.style.transition = originalTransition;
                    }, 300);
                }, 1500);
            } else {
                alert('注目コメントセクションが見つかりませんでした');
            }
        });

        // ページにボタンを追加（既に存在する場合は追加しない）
        if (!document.getElementById('jump-to-featured-comments')) {
            document.body.appendChild(button);
        }
    }

    // ページ読み込み後に実行
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // 動的コンテンツ読み込みに対応
    setTimeout(init, 2000);
})();