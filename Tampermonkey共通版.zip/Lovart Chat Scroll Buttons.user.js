// ==UserScript==
// @name         Lovart Chat Scroll Buttons
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  lovartチャット欄にページを上部/下部にスクロールする矢印ボタンを追加
// @author       You
// @match        https://*.lovart.ai/*
// @match        https://lovart.ai/*
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    // スタイルを追加
    GM_addStyle(`
        .lovart-scroll-buttons {
            position: fixed;
            right: 20px;
            bottom: 150px;
            display: flex;
            flex-direction: column;
            gap: 8px;
            z-index: 9999;
        }

        .lovart-scroll-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(47, 54, 64, 0.9);
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }

        .lovart-scroll-btn:hover {
            background: rgba(47, 54, 64, 1);
            transform: scale(1.1);
        }

        .lovart-scroll-btn:active {
            transform: scale(0.95);
        }

        .lovart-scroll-btn svg {
            width: 20px;
            height: 20px;
            fill: white;
        }

        .lovart-scroll-btn.hidden {
            opacity: 0;
            pointer-events: none;
        }
    `);

    // ボタンコンテナを作成
    function createScrollButtons() {
        const container = document.createElement('div');
        container.className = 'lovart-scroll-buttons';

        // 上へスクロールボタン
        const upBtn = document.createElement('button');
        upBtn.className = 'lovart-scroll-btn';
        upBtn.innerHTML = `
            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 4l-8 8h5v8h6v-8h5z"/>
            </svg>
        `;
        upBtn.title = '上部へスクロール';
        upBtn.addEventListener('click', () => scrollToPosition('top'));

        // 下へスクロールボタン
        const downBtn = document.createElement('button');
        downBtn.className = 'lovart-scroll-btn';
        downBtn.innerHTML = `
            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 20l8-8h-5V4H9v8H4z"/>
            </svg>
        `;
        downBtn.title = '下部へスクロール';
        downBtn.addEventListener('click', () => scrollToPosition('bottom'));

        container.appendChild(upBtn);
        container.appendChild(downBtn);

        return container;
    }

    // スクロール処理
    function scrollToPosition(position) {
        const chatContainer = document.getElementById('agent-chat-sessions');
        if (!chatContainer) {
            console.log('チャットコンテナが見つかりません');
            return;
        }

        if (position === 'top') {
            chatContainer.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        } else if (position === 'bottom') {
            chatContainer.scrollTo({
                top: chatContainer.scrollHeight,
                behavior: 'smooth'
            });
        }
    }

    // チャットコンテナの監視と初期化
    function init() {
        // 既存のボタンがあれば削除
        const existingButtons = document.querySelector('.lovart-scroll-buttons');
        if (existingButtons) {
            existingButtons.remove();
        }

        // チャットコンテナが存在するか確認
        const chatContainer = document.getElementById('agent-chat-sessions');
        if (chatContainer) {
            const buttons = createScrollButtons();
            document.body.appendChild(buttons);
            console.log('Lovart Scroll Buttons: ボタンを追加しました');
        }
    }

    // DOMの変更を監視
    const observer = new MutationObserver((mutations) => {
        const chatContainer = document.getElementById('agent-chat-sessions');
        const existingButtons = document.querySelector('.lovart-scroll-buttons');

        if (chatContainer && !existingButtons) {
            init();
        } else if (!chatContainer && existingButtons) {
            existingButtons.remove();
        }
    });

    // ページ読み込み完了時に初期化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            init();
            observer.observe(document.body, { childList: true, subtree: true });
        });
    } else {
        init();
        observer.observe(document.body, { childList: true, subtree: true });
    }
})();