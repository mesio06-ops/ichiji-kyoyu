// ==UserScript==
// @name         Yahoo News Auto Scroll (safe) with Control Buttons
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Yahooニュース無限スクロール対応。スタート・ストップボタンで制御可能
// @match        https://news.yahoo.co.jp/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    // スクロール制御の状態管理変数
    let scrollInterval = null;
    let lastHeight = 0;
    let tries = 0;
    let maxTries = 50; // 最大試行数（約50秒）
    let isScrolling = false;

    // UI要素の参照
    let startBtn, stopBtn, statusSpan;

    /**
     * スクロール処理の1回分を実行する関数
     * 元のスクリプトのロジックをそのまま保持
     */
    function executeScrollTick() {
        window.scrollTo(0, document.body.scrollHeight);
        const currentHeight = document.body.scrollHeight;

        // 高さが更新されていなければカウント
        if (currentHeight === lastHeight) {
            tries++;
        } else {
            tries = 0;
            lastHeight = currentHeight;
        }

        // 元のロジック通り：何回か試しても変化なければ停止
        if (tries > 5 || maxTries-- <= 0) {
            stopScrolling();
            console.log("スクロール終了（自動停止）");
        }
    }

    /**
     * 自動スクロールを開始する関数
     */
    function startScrolling() {
        if (isScrolling) return; // 既に動作中の場合は何もしない

        // 状態を初期化
        isScrolling = true;
        lastHeight = document.body.scrollHeight;
        tries = 0;
        maxTries = 50; // 毎回リセット

        // 1秒間隔でスクロール処理を実行
        scrollInterval = setInterval(executeScrollTick, 1000);

        updateUI('スクロール中...', true);
        console.log("スクロール開始");
    }

    /**
     * 自動スクロールを停止する関数
     */
    function stopScrolling() {
        if (!isScrolling) return; // 既に停止中の場合は何もしない

        isScrolling = false;
        if (scrollInterval) {
            clearInterval(scrollInterval);
            scrollInterval = null;
        }

        updateUI('停止中', false);
        console.log("スクロール停止");
    }

    /**
     * UIの状態を更新する関数
     * @param {string} statusText - ステータス表示テキスト
     * @param {boolean} scrollingState - スクロール中かどうか
     */
    function updateUI(statusText, scrollingState) {
        if (statusSpan) {
            statusSpan.textContent = statusText;
            statusSpan.style.color = scrollingState ? '#28a745' : '#6c757d';
        }

        if (startBtn && stopBtn) {
            startBtn.disabled = scrollingState;
            stopBtn.disabled = !scrollingState;

            // 無効化されたボタンのスタイル調整
            startBtn.style.opacity = scrollingState ? '0.6' : '1';
            stopBtn.style.opacity = scrollingState ? '1' : '0.6';
        }
    }

    /**
     * コントロールパネルのUIを作成する関数
     */
    function createControlPanel() {
        const controlPanel = document.createElement('div');
        controlPanel.id = 'yahoo-scroll-control';
        controlPanel.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 999999;
            background: rgba(255, 255, 255, 0.95);
            border: 2px solid #007bff;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px;
            min-width: 200px;
        `;

        // タイトル
        const title = document.createElement('div');
        title.textContent = '自動スクロール制御';
        title.style.cssText = `
            font-weight: bold;
            margin-bottom: 12px;
            color: #333;
            text-align: center;
            font-size: 16px;
        `;

        // ボタンコンテナ
        const buttonContainer = document.createElement('div');
        buttonContainer.style.cssText = `
            display: flex;
            gap: 8px;
            margin-bottom: 10px;
        `;

        // スタートボタン
        startBtn = document.createElement('button');
        startBtn.textContent = 'スタート';
        startBtn.style.cssText = `
            flex: 1;
            background: #28a745;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
        `;

        // ストップボタン
        stopBtn = document.createElement('button');
        stopBtn.textContent = 'ストップ';
        stopBtn.style.cssText = `
            flex: 1;
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s ease;
        `;

        // ステータス表示
        statusSpan = document.createElement('div');
        statusSpan.textContent = '停止中';
        statusSpan.style.cssText = `
            text-align: center;
            font-size: 12px;
            color: #6c757d;
            font-weight: 500;
        `;

        // ホバーエフェクトの追加
        startBtn.addEventListener('mouseover', () => {
            if (!startBtn.disabled) startBtn.style.background = '#218838';
        });
        startBtn.addEventListener('mouseout', () => {
            if (!startBtn.disabled) startBtn.style.background = '#28a745';
        });

        stopBtn.addEventListener('mouseover', () => {
            if (!stopBtn.disabled) stopBtn.style.background = '#c82333';
        });
        stopBtn.addEventListener('mouseout', () => {
            if (!stopBtn.disabled) stopBtn.style.background = '#dc3545';
        });

        // イベントリスナーの設定
        startBtn.addEventListener('click', startScrolling);
        stopBtn.addEventListener('click', stopScrolling);

        // 要素を組み立て
        buttonContainer.appendChild(startBtn);
        buttonContainer.appendChild(stopBtn);

        controlPanel.appendChild(title);
        controlPanel.appendChild(buttonContainer);
        controlPanel.appendChild(statusSpan);

        document.body.appendChild(controlPanel);

        // 初期状態の設定
        updateUI('停止中', false);
    }

    /**
     * スクリプトの初期化処理
     */
    function initialize() {
        // DOM要素が完全に読み込まれてからUI作成
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', createControlPanel);
        } else {
            createControlPanel();
        }
    }

    // スクリプト開始
    initialize();

})();