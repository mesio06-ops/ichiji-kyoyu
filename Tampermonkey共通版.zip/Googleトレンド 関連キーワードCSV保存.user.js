// ==UserScript==
// @name         Googleトレンド 関連キーワードCSV保存
// @namespace    local-gtrend-tools
// @version      1.0.0
// @description  上位の語句・増加傾向の語句をCSVで保存（通常ブラウザのセッションを使用）
// @match        https://trends.google.com/trends/explore*
// @match        https://trends.google.co.jp/trends/explore*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  "use strict";

  const TZ = 540; // 日本（UTC+9）
  const HL = "ja";

  // =========================================================
  // ユーティリティ
  // =========================================================

  function parsePageParams() {
    const params = new URLSearchParams(window.location.search);
    const keyword = params.get("q") || "";
    const geo = params.get("geo") || "JP";
    const date = params.get("date") || "now 1-d";
    const gprop = params.get("gprop") || "";
    return { keyword, geo, date, gprop };
  }

  function searchTypeLabel(gprop) {
    return gprop === "youtube" ? "YouTube" : "Web";
  }

  function safeFilename(text) {
    return text.replace(/[\\/:*?"<>|]/g, "_").trim();
  }

  function buildFilename(keyword, gprop, kind) {
    const today = new Date().toISOString().slice(0, 10);
    return `${safeFilename(keyword)}_${searchTypeLabel(gprop)}_${kind}_${today}.csv`;
  }

  function parseGoogleJson(text) {
    const cleaned = text.replace(/^\)\]\}',?\n?/, "");
    return JSON.parse(cleaned);
  }

  function rowsToCsv(headers, rows) {
    const escape = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
    const lines = [headers.map(escape).join(",")];
    for (const row of rows) {
      lines.push(headers.map((h) => escape(row[h])).join(","));
    }
    return "\uFEFF" + lines.join("\n");
  }

  function downloadCsv(filename, csvText) {
    const blob = new Blob([csvText], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.style.display = "none";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  function normalizeKeywordRows(list) {
    if (!Array.isArray(list)) return [];
    return list.map((item) => ({
      語句: item.query || "",
      スコア: item.formattedValue || item.value || "",
    }));
  }

  function setStatus(message, isError) {
    const el = document.getElementById("gtrend-csv-status");
    if (!el) return;
    el.textContent = message;
    el.style.color = isError ? "#c0392b" : "#333";
  }

  // =========================================================
  // Google Trends API（ページと同じセッション・Cookieを使用）
  // =========================================================

  async function fetchExploreWidgets(keyword, geo, date, gprop) {
    const req = {
      comparisonItem: [{ keyword, time: date, geo }],
      category: 0,
      property: gprop || "",
    };

    const body = new URLSearchParams({
      hl: HL,
      tz: String(TZ),
      req: JSON.stringify(req),
    });

    const response = await fetch(
      "https://trends.google.com/trends/api/explore?" + body.toString(),
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
      }
    );

    if (response.status === 429) {
      throw new Error(
        "429: アクセス制限中です。しばらく待ってから、通常ブラウザで1ページずつ開いて再試行してください。"
      );
    }
    if (!response.ok) {
      throw new Error(`探索APIエラー: HTTP ${response.status}`);
    }

    const data = parseGoogleJson(await response.text());
    return data.widgets || [];
  }

  async function fetchRelatedQueries(widget) {
    const params = new URLSearchParams({
      req: JSON.stringify(widget.request),
      token: widget.token,
      tz: String(TZ),
    });

    const response = await fetch(
      "https://trends.google.com/trends/api/widgetdata/relatedsearches?" +
        params.toString(),
      {
        credentials: "include",
      }
    );

    if (response.status === 429) {
      throw new Error("429: アクセス制限中です。時間を空けて再試行してください。");
    }
    if (!response.ok) {
      throw new Error(`関連クエリAPIエラー: HTTP ${response.status}`);
    }

    return parseGoogleJson(await response.text());
  }

  async function getRelatedQueryData() {
    const { keyword, geo, date, gprop } = parsePageParams();
    if (!keyword) {
      throw new Error("URLにキーワード（q=）が見つかりません。");
    }

    const widgets = await fetchExploreWidgets(keyword, geo, date, gprop);
    const relatedWidget = widgets.find((w) =>
      String(w.id || "").includes("RELATED_QUERIES")
    );

    if (!relatedWidget) {
      throw new Error("関連クエリのウィジェットが見つかりません。ページの読み込み完了後に再試行してください。");
    }

    const result = await fetchRelatedQueries(relatedWidget);
    const rankedList = result?.default?.rankedList || [];

    const top = normalizeKeywordRows(rankedList[0]?.rankedKeyword);
    const rising = normalizeKeywordRows(rankedList[1]?.rankedKeyword);

    return { keyword, gprop, top, rising };
  }

  // =========================================================
  // 保存処理
  // =========================================================

  async function saveCsv(kind) {
    try {
      setStatus("取得中…", false);
      const { keyword, gprop, top, rising } = await getRelatedQueryData();

      if (kind === "top" || kind === "both") {
        if (top.length === 0) {
          setStatus("上位の語句: データなし", true);
        } else {
          const csv = rowsToCsv(["語句", "スコア"], top);
          downloadCsv(buildFilename(keyword, gprop, "上位"), csv);
        }
      }

      if (kind === "rising" || kind === "both") {
        if (rising.length === 0) {
          setStatus("増加傾向の語句: データなし", true);
        } else {
          const csv = rowsToCsv(["語句", "スコア"], rising);
          downloadCsv(buildFilename(keyword, gprop, "増加"), csv);
        }
      }

      if (kind === "both") {
        setStatus("上位・増加のCSVを保存しました。", false);
      } else if (kind === "top") {
        setStatus("上位の語句を保存しました。", false);
      } else {
        setStatus("増加傾向の語句を保存しました。", false);
      }
    } catch (error) {
      setStatus(error.message || "取得に失敗しました。", true);
    }
  }

  // =========================================================
  // 画面に操作パネルを追加
  // =========================================================

  function createPanel() {
    if (document.getElementById("gtrend-csv-panel")) return;

    const { keyword, gprop } = parsePageParams();

    const panel = document.createElement("div");
    panel.id = "gtrend-csv-panel";
    panel.innerHTML = `
      <style>
        #gtrend-csv-panel {
          position: fixed;
          right: 16px;
          bottom: 16px;
          z-index: 999999;
          width: 280px;
          background: #fff;
          border: 1px solid #dadce0;
          border-radius: 10px;
          box-shadow: 0 4px 16px rgba(0,0,0,.18);
          font-family: "Meiryo", "Hiragino Sans", sans-serif;
          color: #202124;
        }
        #gtrend-csv-panel .header {
          padding: 12px 14px 8px;
          font-size: 13px;
          font-weight: 700;
          border-bottom: 1px solid #eee;
        }
        #gtrend-csv-panel .meta {
          padding: 0 14px 8px;
          font-size: 11px;
          color: #5f6368;
          line-height: 1.5;
        }
        #gtrend-csv-panel .buttons {
          display: grid;
          gap: 8px;
          padding: 10px 14px 12px;
        }
        #gtrend-csv-panel button {
          border: none;
          border-radius: 6px;
          padding: 10px 12px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          color: #fff;
          background: #1a73e8;
        }
        #gtrend-csv-panel button.secondary {
          background: #5f6368;
        }
        #gtrend-csv-panel button:hover {
          filter: brightness(0.95);
        }
        #gtrend-csv-status {
          padding: 0 14px 12px;
          font-size: 11px;
          line-height: 1.5;
          min-height: 32px;
        }
      </style>
      <div class="header">関連キーワード CSV保存</div>
      <div class="meta">
        キーワード: <strong>${keyword || "（未設定）"}</strong><br>
        種別: <strong>${searchTypeLabel(gprop)}</strong>
      </div>
      <div class="buttons">
        <button type="button" id="gtrend-save-top">上位の語句をCSV保存</button>
        <button type="button" id="gtrend-save-rising" class="secondary">増加傾向の語句をCSV保存</button>
        <button type="button" id="gtrend-save-both">両方まとめて保存</button>
      </div>
      <div id="gtrend-csv-status">ページ読み込み後にボタンを押してください。</div>
    `;

    document.body.appendChild(panel);

    document.getElementById("gtrend-save-top").addEventListener("click", () => saveCsv("top"));
    document.getElementById("gtrend-save-rising").addEventListener("click", () => saveCsv("rising"));
    document.getElementById("gtrend-save-both").addEventListener("click", () => saveCsv("both"));
  }

  createPanel();
})();
