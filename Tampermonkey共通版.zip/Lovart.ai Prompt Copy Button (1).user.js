// ==UserScript==
// @name         Lovart.ai Prompt Copy Button
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  lovart.aiのチャットツールのプロンプト指示箇所にコピーボタンを追加
// @author       You
// @match        https://lovart.ai/*
// @match        https://*.lovart.ai/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // コピーボタンのスタイルを追加
    const style = document.createElement('style');
    style.textContent = `
        .lovart-copy-button {
            position: absolute;
            bottom: 8px;
            right: 8px;
            padding: 6px 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.2s ease;
            z-index: 10;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .lovart-copy-button:hover {
            background-color: #45a049;
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }

        .lovart-copy-button:active {
            transform: scale(0.95);
        }

        .lovart-copy-button.copied {
            background-color: #2196F3;
        }

        .lovart-message-wrapper {
            position: relative;
        }
    `;
    document.head.appendChild(style);

    // コピーボタンを作成する関数
    function createCopyButton(textElement) {
        const button = document.createElement('button');
        button.className = 'lovart-copy-button';
        button.textContent = 'コピー';

        button.addEventListener('click', async (e) => {
            e.stopPropagation();
            const text = textElement.textContent;

            try {
                await navigator.clipboard.writeText(text);
                button.textContent = 'コピー完了！';
                button.classList.add('copied');

                setTimeout(() => {
                    button.textContent = 'コピー';
                    button.classList.remove('copied');
                }, 2000);
            } catch (err) {
                console.error('コピーに失敗しました:', err);
                button.textContent = 'エラー';
                setTimeout(() => {
                    button.textContent = 'コピー';
                }, 2000);
            }
        });

        return button;
    }

    // メッセージ要素にコピーボタンを追加
    function addCopyButtons() {
        const messageElements = document.querySelectorAll('[data-testid="user-message-text"]');

        messageElements.forEach(element => {
            // 既にボタンが追加されている場合はスキップ
            if (element.parentElement.classList.contains('lovart-message-wrapper')) {
                return;
            }

            // ラッパーを作成
            const wrapper = document.createElement('div');
            wrapper.className = 'lovart-message-wrapper';

            // 元の要素をラッパーで囲む
            element.parentNode.insertBefore(wrapper, element);
            wrapper.appendChild(element);

            // コピーボタンを追加
            const copyButton = createCopyButton(element);
            wrapper.appendChild(copyButton);
        });
    }

    // 初期実行
    addCopyButtons();

    // DOMの変更を監視して新しいメッセージにもボタンを追加
    const observer = new MutationObserver((mutations) => {
        let shouldUpdate = false;

        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === 1) { // Element node
                    if (node.querySelector('[data-testid="user-message-text"]') ||
                        node.matches('[data-testid="user-message-text"]')) {
                        shouldUpdate = true;
                    }
                }
            });
        });

        if (shouldUpdate) {
            setTimeout(addCopyButtons, 100);
        }
    });

    // body全体を監視
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    console.log('Lovart.ai Prompt Copy Button スクリプトが起動しました');
})();