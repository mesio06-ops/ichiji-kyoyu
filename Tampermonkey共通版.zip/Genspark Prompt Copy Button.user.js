// ==UserScript==
// @name         Genspark Prompt Copy Button
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Gensparkのコードブロックにコピーボタンを追加
// @author       You
// @match        https://www.genspark.ai/*
// @match        https://genspark.ai/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // コピーボタンのスタイルを追加
    const style = document.createElement('style');
    style.textContent = `
        .genspark-custom-copy-button {
            position: absolute;
            bottom: 8px;
            right: 8px;
            padding: 6px 12px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.2s ease;
            z-index: 10;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .genspark-custom-copy-button:hover {
            background-color: #45a049;
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }

        .genspark-custom-copy-button:active {
            transform: scale(0.95);
        }

        .genspark-custom-copy-button.copied {
            background-color: #2196F3;
        }

        code.hljs {
            position: relative;
            padding-bottom: 45px !important;
            display: block;
        }
    `;
    document.head.appendChild(style);

    // テキストノードのみを取得する関数
    function getTextFromElement(element) {
        let text = '';

        // 既存のCopyボタンとカスタムボタンを除外
        const clone = element.cloneNode(true);
        const buttons = clone.querySelectorAll('button');
        buttons.forEach(btn => btn.remove());

        // spanタグ内のテキストのみを取得
        const spans = clone.querySelectorAll('span');
        spans.forEach(span => {
            text += span.textContent;
        });

        // spanがない場合は直接のテキストノードを取得
        if (text === '') {
            text = clone.textContent || clone.innerText;
        }

        return text.trim();
    }

    // コピーボタンを作成する関数
    function createCopyButton(codeElement) {
        const button = document.createElement('button');
        button.className = 'genspark-custom-copy-button';
        button.textContent = 'コピー';

        button.addEventListener('click', async (e) => {
            e.stopPropagation();

            const text = getTextFromElement(codeElement);

            try {
                await navigator.clipboard.writeText(text);
                button.textContent = 'コピー完了！';
                button.classList.add('copied');

                setTimeout(() => {
                    button.textContent = 'コピー';
                    button.classList.remove('copied');
                }, 2000);
            } catch (err) {
                console.error('コピーに失敗しました:', err);
                button.textContent = 'エラー';
                setTimeout(() => {
                    button.textContent = 'コピー';
                }, 2000);
            }
        });

        return button;
    }

    // コード要素にコピーボタンを追加
    function addCopyButtons() {
        const codeElements = document.querySelectorAll('code.hljs');

        codeElements.forEach(element => {
            // 既にカスタムボタンが追加されている場合はスキップ
            if (element.querySelector('.genspark-custom-copy-button')) {
                return;
            }

            // コピーボタンを追加
            const copyButton = createCopyButton(element);
            element.appendChild(copyButton);
        });
    }

    // 初期実行
    setTimeout(addCopyButtons, 1000);

    // DOMの変更を監視して新しいコードブロックにもボタンを追加
    const observer = new MutationObserver((mutations) => {
        let shouldUpdate = false;

        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === 1) { // Element node
                    if (node.querySelector('code.hljs') ||
                        node.matches('code.hljs')) {
                        shouldUpdate = true;
                    }
                }
            });
        });

        if (shouldUpdate) {
            setTimeout(addCopyButtons, 100);
        }
    });

    // body全体を監視
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    console.log('Genspark Prompt Copy Button スクリプトが起動しました');
})();