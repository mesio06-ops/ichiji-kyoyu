// ==UserScript==
// @name         YouTube - Hide Subscribed Channels from Search
// @namespace    http://tampermonkey.net/
// @version      1.0.0
// @description  YouTubeの検索結果から登録済みチャンネルを非表示にする
// @author       You
// @match        https://www.youtube.com/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  // 登録済みチャンネルを非表示にするメイン処理
  function hideSubscribedChannels() {
    // 検索結果ページ以外はスキップ
    if (!location.pathname.startsWith('/results')) return;

    // 検索結果内の動画カードを全取得
    const videoRenderers = document.querySelectorAll(
      'ytd-video-renderer, ytd-channel-renderer'
    );

    videoRenderers.forEach((renderer) => {
      // 登録ボタンを探す（登録済みの場合は特定のaria属性や表示が変わる）
      const subscribeButton = renderer.querySelector(
        'yt-subscribe-button-view-model, ytd-subscribe-button-renderer'
      );

      if (!subscribeButton) return;

      // 登録済みかどうかの判定
      const isSubscribed = isChannelSubscribed(subscribeButton);

      if (isSubscribed) {
        renderer.style.display = 'none';
        console.log('[HideSubscribed] 非表示:', renderer);
      }
    });
  }

  // 登録済みチャンネルかどうかを判定する
  function isChannelSubscribed(subscribeButton) {
    // 方法1: aria-label に「登録済み」「Subscribed」などが含まれるか確認
    const ariaLabel = subscribeButton.getAttribute('aria-label') || '';
    if (/登録済み|Subscribed|Unsubscribe/i.test(ariaLabel)) return true;

    // 方法2: ボタン内テキストを確認
    const buttonText = subscribeButton.innerText || '';
    if (/登録済み|Subscribed/i.test(buttonText)) return true;

    // 方法3: subscribed属性やクラスを確認
    if (
      subscribeButton.hasAttribute('subscribed') ||
      subscribeButton.classList.contains('ytd-subscribe-button-renderer--subscribed')
    ) return true;

    // 方法4: 内部のボタン要素を再帰的に確認
    const innerButton = subscribeButton.querySelector('button, tp-yt-paper-button, yt-button-shape');
    if (innerButton) {
      const innerText = innerButton.innerText || '';
      const innerAria = innerButton.getAttribute('aria-label') || '';
      if (/登録済み|Subscribed/i.test(innerText + innerAria)) return true;
    }

    return false;
  }

  // MutationObserverで動的に追加される要素も監視
  function observeDOM() {
    const observer = new MutationObserver((mutations) => {
      let shouldRun = false;

      for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
          shouldRun = true;
          break;
        }
      }

      if (shouldRun) {
        // 連続実行を防ぐためデバウンス
        clearTimeout(observeDOM._timer);
        observeDOM._timer = setTimeout(hideSubscribedChannels, 300);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  // URLの変化（SPAナビゲーション）を検知
  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(hideSubscribedChannels, 800);
    }
  }).observe(document, { subtree: true, childList: true });

  // 初期実行
  window.addEventListener('load', () => {
    hideSubscribedChannels();
    observeDOM();
  });

  // load前に既にDOMがあれば即実行
  if (document.readyState === 'complete') {
    hideSubscribedChannels();
    observeDOM();
  }
})();