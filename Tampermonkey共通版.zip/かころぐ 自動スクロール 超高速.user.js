// ==UserScript==
// @name         かころぐ 自動スクロール 超高速
// @namespace    http://tampermonkey.net/
// @version      4.2
// @description  かころぐβで超高速に自動スクロール
// @author       You
// @match        *://kakolog.jp/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    let autoScrollEnabled = false; // 最初は停止状態
    let scrollSpeed = 200; // デフォルトを爆速に
    let hasReachedBottom = false;

    function autoScroll() {
        if (!autoScrollEnabled) {
            requestAnimationFrame(autoScroll);
            return;
        }

        const bodyHeight = document.body.scrollHeight;
        const windowHeight = window.innerHeight;
        const scrollTop = window.pageYOffset;
        const remainingScroll = bodyHeight - scrollTop - windowHeight;

        if (remainingScroll > 50) {
            window.scrollBy(0, scrollSpeed);
            hasReachedBottom = false;
        } else {
            if (!hasReachedBottom) {
                showMessage('最下部に到達しました');
                hasReachedBottom = true;
            }
        }

        requestAnimationFrame(autoScroll);
    }

    function showMessage(text) {
        const message = document.createElement('div');
        message.style.cssText = 'position: fixed; top: 80px; right: 20px; background: #229900; color: white; padding: 15px 25px; border-radius: 8px; z-index: 99999; box-shadow: 0 4px 15px rgba(0,0,0,0.3); font-size: 14px; font-weight: bold;';
        message.textContent = text;
        document.body.appendChild(message);
        setTimeout(() => {
            message.style.opacity = '0';
            message.style.transition = 'opacity 0.5s';
            setTimeout(() => message.remove(), 500);
        }, 3000);
    }

    function createControlPanel() {
        const panel = document.createElement('div');
        panel.style.cssText = 'position: fixed; top: 120px; right: 20px; background: white; border: 3px solid #229900; padding: 15px; border-radius: 10px; z-index: 99998; box-shadow: 0 4px 15px rgba(0,0,0,0.2); min-width: 200px;';
        panel.innerHTML = `
            <div style="margin-bottom: 10px; font-weight: bold; color: #229900; font-size: 14px;">🔄 自動スクロール</div>
            <button id="toggleAutoScroll" style="margin-bottom: 10px; padding: 8px 15px; width: 100%; cursor: pointer; background: #999; color: white; border: none; border-radius: 5px; font-size: 13px; font-weight: bold;">▶ 開始</button>
            <div style="margin-bottom: 10px;">
                <label style="display: block; margin-bottom: 5px; font-size: 12px;">速度: <span id="speedValue">200</span></label>
                <input type="range" id="scrollSpeedSlider" min="1" max="200" value="200" style="width: 100%;">
            </div>
            <div style="margin-bottom: 10px;">
                <button id="speedPreset1" style="padding: 5px; width: 32%; cursor: pointer; background: #ddd; border: none; border-radius: 3px; font-size: 11px;">遅い</button>
                <button id="speedPreset2" style="padding: 5px; width: 32%; cursor: pointer; background: #ddd; border: none; border-radius: 3px; font-size: 11px;">普通</button>
                <button id="speedPreset3" style="padding: 5px; width: 32%; cursor: pointer; background: #ffcc00; border: none; border-radius: 3px; font-size: 11px; font-weight: bold;">爆速</button>
            </div>
            <div style="font-size: 10px; color: #666; padding-top: 10px; border-top: 1px solid #ddd;">
                残り: <span id="remainingScroll">-</span>px
            </div>
        `;
        document.body.appendChild(panel);

        document.getElementById('toggleAutoScroll').addEventListener('click', function() {
            autoScrollEnabled = !autoScrollEnabled;
            this.innerHTML = autoScrollEnabled ? '⏸ 停止' : '▶ 開始';
            this.style.background = autoScrollEnabled ? '#229900' : '#999';
            if (autoScrollEnabled) {
                showMessage('自動スクロール開始');
            } else {
                showMessage('自動スクロール停止');
            }
            hasReachedBottom = false;
        });

        document.getElementById('scrollSpeedSlider').addEventListener('input', function(e) {
            scrollSpeed = parseInt(e.target.value);
            document.getElementById('speedValue').textContent = scrollSpeed;
        });

        document.getElementById('speedPreset1').addEventListener('click', function() {
            scrollSpeed = 10;
            document.getElementById('scrollSpeedSlider').value = 10;
            document.getElementById('speedValue').textContent = 10;
        });

        document.getElementById('speedPreset2').addEventListener('click', function() {
            scrollSpeed = 50;
            document.getElementById('scrollSpeedSlider').value = 50;
            document.getElementById('speedValue').textContent = 50;
        });

        document.getElementById('speedPreset3').addEventListener('click', function() {
            scrollSpeed = 200;
            document.getElementById('scrollSpeedSlider').value = 200;
            document.getElementById('speedValue').textContent = 200;
        });

        setInterval(() => {
            const bodyHeight = document.body.scrollHeight;
            const windowHeight = window.innerHeight;
            const scrollTop = window.pageYOffset;
            const remaining = Math.round(bodyHeight - scrollTop - windowHeight);
            const remainingElement = document.getElementById('remainingScroll');
            if (remainingElement) {
                remainingElement.textContent = remaining;
            }
        }, 100);
    }

    function createScrollTopButton() {
        const button = document.createElement('div');
        button.id = 'scrollTopButton';
        button.style.cssText = 'position: fixed; bottom: 30px; right: 30px; width: 60px; height: 60px; background: #229900; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 99997; box-shadow: 0 4px 15px rgba(0,0,0,0.3); font-size: 24px; font-weight: bold; opacity: 0; transition: opacity 0.3s;';
        button.innerHTML = '↑';
        button.title = 'ページトップへ戻る';

        button.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            hasReachedBottom = false;
            showMessage('ページトップへ移動');
        });

        button.addEventListener('mouseenter', function() {
            this.style.background = '#33aa11';
            this.style.transform = 'scale(1.1)';
        });

        button.addEventListener('mouseleave', function() {
            this.style.background = '#229900';
            this.style.transform = 'scale(1)';
        });

        document.body.appendChild(button);

        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset;
            const button = document.getElementById('scrollTopButton');
            if (button) {
                if (scrollTop > 300) {
                    button.style.opacity = '1';
                } else {
                    button.style.opacity = '0';
                }
            }
        });
    }

    function init() {
        const resultDiv = document.querySelector('.result');
        if (resultDiv) {
            createControlPanel();
            createScrollTopButton();
            autoScroll(); // ループは開始するが、停止状態
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        setTimeout(init, 500);
    }

})();