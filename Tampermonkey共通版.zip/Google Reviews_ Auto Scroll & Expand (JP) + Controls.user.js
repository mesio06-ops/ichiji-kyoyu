// ==UserScript==
// @name         Google Reviews: Auto Scroll & Expand (JP) + Controls
// @namespace    gp-auto
// @version      1.4
// @description  Googleのクチコミ・リストで自動スクロール＆「もっと見る」を自動クリック（開始/停止ボタン付き）
// @match        https://www.google.com/maps*
// @match        https://www.google.co.jp/maps*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  let running = false;
  let scrollTimer = null;
  let clickTimer = null;
  let mo = null;

  const LOG = (...a) => console.log('[AutoExpand]', ...a);

  // ===== UI: Start/Stop ボタン =====
  function buildControl() {
    if (document.getElementById('gp-auto-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'gp-auto-panel';
    panel.style.cssText = `
      position: fixed; top: 16px; right: 16px; z-index: 999999;
      background: rgba(32,33,36,.95); color: #fff; font: 12px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans JP", sans-serif;
      border: 1px solid rgba(255,255,255,.15); border-radius: 10px; padding: 10px; box-shadow: 0 4px 16px rgba(0,0,0,.3);
      display: flex; gap: 8px; align-items: center;
    `;

    const status = document.createElement('span');
    status.id = 'gp-auto-status';
    status.textContent = '停止中';
    status.style.opacity = '0.8';

    const btnStart = document.createElement('button');
    btnStart.textContent = 'スタート';
    btnStart.style.cssText = baseBtnCss();
    btnStart.addEventListener('click', start);

    const btnStop = document.createElement('button');
    btnStop.textContent = 'ストップ';
    btnStop.style.cssText = baseBtnCss(true);
    btnStop.addEventListener('click', stop);

    const hint = document.createElement('span');
    hint.textContent = 'Alt+S';
    hint.style.cssText = 'opacity:.6; padding-left:4px;';

    panel.append(btnStart, btnStop, status, hint);
    document.body.appendChild(panel);

    function baseBtnCss(outline = false) {
      return `
        cursor: pointer; border-radius: 8px; padding: 6px 10px; border: ${outline ? '1px solid rgba(255,255,255,.35)' : '0'};
        background: ${outline ? 'transparent' : '#1a73e8'}; color: ${outline ? '#fff' : '#fff'};
      `;
    }
  }

  function setStatus(txt) {
    const el = document.getElementById('gp-auto-status');
    if (el) el.textContent = txt;
  }

  // ===== 可視要素判定 =====
  const isVisible = (el) => {
    if (!el) return false;
    const s = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return (
      style.visibility !== 'hidden' &&
      style.display !== 'none' &&
      s.width > 0 &&
      s.height > 0
    );
  };

  // ===== 展開テキスト =====
  const CLICK_TEXTS = [
    'もっと見る', '全文を表示', '続きを読む',
    'More', 'See more', 'Read more', 'More reviews'
  ];

  function hasExpandText(el) {
    const t = (el.innerText || el.textContent || '').trim();
    if (!t) return false;
    return CLICK_TEXTS.some(x => t === x || t.startsWith(x));
  }

  function findExpandableButtons(root = document) {
    const candidates = [
      ...root.querySelectorAll('button'),
      ...root.querySelectorAll('[role="button"]'),
      ...root.querySelectorAll('span'),
      ...root.querySelectorAll('div')
    ];
    return candidates.filter(el => isVisible(el) && hasExpandText(el));
  }

  // ===== スクロール対象 =====
  function getScrollContainers() {
    const list = [];
    const selectors = [
      'div[role="feed"]',           // クチコミ一覧（新UI）
      '.m6QErb.DxyBCb',             // マップのパネル
      '.section-scrollbox',         // 旧UI
      '.m6QErb',                    // マップ汎用
      '#pane .DxyBCb',              // マップ左ペイン
    ];
    selectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        const style = getComputedStyle(el);
        if (/(auto|scroll)/.test(style.overflowY) && el.scrollHeight > el.clientHeight) {
          list.push(el);
        }
      });
    });
    if (list.length === 0) list.push(document.scrollingElement || document.documentElement);
    return Array.from(new Set(list));
  }

  function autoClick() {
    const buttons = findExpandableButtons();
    if (buttons.length) {
      buttons.forEach(btn => { try { btn.click(); } catch (e) {} });
      LOG('Clicked expand buttons:', buttons.length);
    }
  }

  function autoScroll() {
    const containers = getScrollContainers();
    containers.forEach(el => {
      const before = el.scrollTop;
      el.scrollBy({ top: Math.max(400, el.clientHeight * 0.8), behavior: 'instant' });
      if (Math.abs(el.scrollHeight - el.clientHeight - el.scrollTop) < 50) {
        el.scrollBy({ top: 50, behavior: 'instant' });
      }
      const after = el.scrollTop;
      if (after === before && el.scrollTop + el.clientHeight < el.scrollHeight) {
        el.scrollTop += 100;
      }
    });
  }

  function start() {
    if (running) return;
    running = true;
    setStatus('稼働中');
    LOG('START');
    autoClick();
    autoScroll();
    clickTimer = setInterval(autoClick, 800);
    scrollTimer = setInterval(autoScroll, 1200);

    mo = new MutationObserver((muts) => {
      for (const mut of muts) {
        for (const node of mut.addedNodes || []) {
          if (node.nodeType === 1) {
            findExpandableButtons(node).forEach(btn => { try { btn.click(); } catch (e) {} });
          }
        }
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  function stop() {
    if (!running) return;
    running = false;
    setStatus('停止中');
    LOG('STOP');
    clearInterval(clickTimer);
    clearInterval(scrollTimer);
    clickTimer = null;
    scrollTimer = null;
    if (mo) { mo.disconnect(); mo = null; }
  }

  // Alt+S でトグル
  window.addEventListener('keydown', (e) => {
    if (e.altKey && (e.key.toLowerCase() === 's')) {
      running ? stop() : start();
      e.preventDefault();
    }
  });

  // ページ読み込み後にUI設置
  const ready = () => {
    if (document.body) buildControl();
    else document.addEventListener('DOMContentLoaded', buildControl, { once: true });
  };
  ready();

  // 自動開始したい場合は↓のコメントを外す
  // setTimeout(start, 3000);
})();