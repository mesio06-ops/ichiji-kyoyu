// ==UserScript==
// @name         Reddit Auto Expand Comments
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Redditの「その他の返信」「コメントをさらに表示する」を自動で開く
// @author       You
// @match        https://www.reddit.com/*
// @match        https://old.reddit.com/*
// @match        https://sh.reddit.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let intervalId = null;
    let isRunning = false;

    // --- UI作成 ---
    const panel = document.createElement('div');
    panel.id = 'reddit-auto-expand-panel';
    panel.innerHTML = `
        <div style="
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 999999;
            background: #1a1a2e;
            border: 2px solid #e94560;
            border-radius: 12px;
            padding: 14px 18px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            font-size: 14px;
            color: #eee;
            box-shadow: 0 4px 20px rgba(0,0,0,0.5);
            user-select: none;
            display: flex;
            flex-direction: column;
            gap: 10px;
            min-width: 220px;
        ">
            <div style="font-weight: bold; font-size: 13px; text-align: center; color: #e94560;">
                Auto Expand Comments
            </div>
            <div style="display: flex; gap: 8px; justify-content: center;">
                <button id="re-start-btn" style="
                    padding: 8px 18px;
                    border: none;
                    border-radius: 8px;
                    background: #0f3460;
                    color: #fff;
                    font-size: 13px;
                    font-weight: bold;
                    cursor: pointer;
                    transition: background 0.2s;
                ">▶ Start</button>
                <button id="re-stop-btn" style="
                    padding: 8px 18px;
                    border: none;
                    border-radius: 8px;
                    background: #53354a;
                    color: #fff;
                    font-size: 13px;
                    font-weight: bold;
                    cursor: pointer;
                    transition: background 0.2s;
                " disabled>■ Stop</button>
            </div>
            <div id="re-status" style="
                text-align: center;
                font-size: 12px;
                color: #aaa;
            ">停止中</div>
        </div>
    `;
    document.body.appendChild(panel);

    const startBtn = document.getElementById('re-start-btn');
    const stopBtn = document.getElementById('re-stop-btn');
    const status = document.getElementById('re-status');

    // --- クリック対象を探してクリック ---
    function expandComments() {
        let clicked = 0;

        // 1) faceplate-partial（新Reddit）の "もっと見る" 系ボタン
        document.querySelectorAll('faceplate-partial[loading="action"]').forEach(el => {
            const btn = el.querySelector('button');
            if (btn && btn.offsetParent !== null) {
                btn.click();
                clicked++;
            }
        });

        // 2) shadow DOM 内の slot を持つ div[tabindex="0"]（展開トリガー）
        document.querySelectorAll('div[tabindex="0"]').forEach(el => {
            if (el.querySelector('slot') && el.offsetParent !== null) {
                // 親要素がまだ展開されていなければクリック
                try {
                    el.click();
                    clicked++;
                } catch (e) { /* ignore */ }
            }
        });

        // 3) "More replies" / "その他の返信" / "コメントをさらに表示" テキストを含むボタン
        const allButtons = document.querySelectorAll('button, [role="button"], a');
        const patterns = [
            /その他の返信/,
            /コメントをさらに表示/,
            /more repl/i,
            /more comment/i,
            /view more/i,
            /load more/i,
            /続きを読む/,
            /もっと見る/,
        ];
        allButtons.forEach(btn => {
            const text = btn.textContent || '';
            if (patterns.some(p => p.test(text)) && btn.offsetParent !== null) {
                btn.click();
                clicked++;
            }
        });

        // 4) shreddit-comment-tree の展開要素
        document.querySelectorAll('shreddit-comment-tree button').forEach(btn => {
            const text = btn.textContent || '';
            if (patterns.some(p => p.test(text)) && btn.offsetParent !== null) {
                btn.click();
                clicked++;
            }
        });

        // 5) "morechildren" クラスや id を含む要素（旧Reddit対応）
        document.querySelectorAll('.morecomments a, .morechildren a').forEach(a => {
            if (a.offsetParent !== null) {
                a.click();
                clicked++;
            }
        });

        return clicked;
    }

    // --- スタート ---
    function start() {
        if (isRunning) return;
        isRunning = true;
        startBtn.disabled = true;
        stopBtn.disabled = false;
        startBtn.style.opacity = '0.5';
        stopBtn.style.opacity = '1';
        status.textContent = '実行中...';
        status.style.color = '#4ecca3';

        let totalClicked = 0;
        intervalId = setInterval(() => {
            const c = expandComments();
            totalClicked += c;
            status.textContent = `実行中... (${totalClicked} クリック)`;
        }, 1500);
    }

    // --- ストップ ---
    function stop() {
        if (!isRunning) return;
        isRunning = false;
        clearInterval(intervalId);
        intervalId = null;
        startBtn.disabled = false;
        stopBtn.disabled = true;
        startBtn.style.opacity = '1';
        stopBtn.style.opacity = '0.5';
        status.textContent = '停止中';
        status.style.color = '#aaa';
    }

    startBtn.addEventListener('click', start);
    stopBtn.addEventListener('click', stop);

})();