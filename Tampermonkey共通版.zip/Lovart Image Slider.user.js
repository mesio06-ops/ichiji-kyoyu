// ==UserScript==
// @name         Lovart Image Slider
// @namespace    http://tampermonkey.net/
// @version      3.4
// @description  同じチャット内の4枚の画像をスライド表示
// @author       You
// @match        https://*.lovart.ai/*
// @match        https://lovart.ai/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let currentImageIndex = 0;
    let images = [];
    let arrowsVisible = false;
    let toggleButtonAdded = false;

    // スタイルを追加
    const style = document.createElement('style');
    style.textContent = `
        .image-slider-arrow {
            position: fixed !important;
            top: 50% !important;
            transform: translateY(-50%) !important;
            background: rgba(0, 0, 0, 0.6) !important;
            color: white !important;
            border: none !important;
            width: 60px !important;
            height: 60px !important;
            border-radius: 50% !important;
            cursor: pointer !important;
            font-size: 24px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            z-index: 99999 !important;
            transition: all 0.3s ease !important;
            opacity: 0 !important;
            pointer-events: none !important;
        }

        .image-slider-arrow.visible {
            opacity: 1 !important;
            pointer-events: auto !important;
        }

        .image-slider-arrow:hover {
            background: rgba(0, 0, 0, 0.8) !important;
            transform: translateY(-50%) scale(1.1) !important;
        }

        .image-slider-arrow:active {
            transform: translateY(-50%) scale(0.95) !important;
        }

        .image-slider-arrow-left {
            left: 20px !important;
        }

        .image-slider-arrow-right {
            right: 20px !important;
        }

        .image-slider-counter {
            position: fixed !important;
            top: 20px !important;
            left: 50% !important;
            transform: translateX(-50%) !important;
            background: rgba(0, 0, 0, 0.6) !important;
            color: white !important;
            padding: 10px 20px !important;
            border-radius: 20px !important;
            font-size: 16px !important;
            z-index: 99999 !important;
            opacity: 0 !important;
            pointer-events: none !important;
            transition: opacity 0.3s ease !important;
        }

        .image-slider-counter.visible {
            opacity: 1 !important;
        }

        .image-slider-toggle {
            position: fixed !important;
            top: 50% !important;
            right: 100px !important;
            transform: translateY(-50%) !important;
            background: rgba(33, 150, 243, 0.9) !important;
            color: white !important;
            border: 2px solid rgba(255, 255, 255, 0.3) !important;
            padding: 14px 28px !important;
            border-radius: 30px !important;
            cursor: pointer !important;
            font-size: 15px !important;
            font-weight: bold !important;
            z-index: 99999 !important;
            transition: all 0.3s ease !important;
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3) !important;
            white-space: nowrap !important;
        }

        .image-slider-toggle:hover {
            background: rgba(33, 150, 243, 1) !important;
            transform: translateY(-50%) scale(1.05) !important;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.4) !important;
        }

        .image-slider-toggle:active {
            transform: translateY(-50%) scale(0.95) !important;
        }

        /* 画像に一意のマーカーを追加 */
        .lovart-slider-marked {
            position: relative;
        }
    `;
    document.head.appendChild(style);

    // 各画像に一意のIDを付与
    function markAllImages() {
        const allCards = document.querySelectorAll('[data-testid="image-generation-card"]');

        allCards.forEach((card, cardIndex) => {
            const imgsInCard = card.querySelectorAll('.agent-chat-image-preview img');
            imgsInCard.forEach((img, imgIndex) => {
                if (!img.dataset.lovartCardId) {
                    img.dataset.lovartCardId = `card-${cardIndex}`;
                    img.dataset.lovartImgIndex = imgIndex;
                    img.classList.add('lovart-slider-marked');
                }
            });
        });
    }

    // 画像グループを取得
    function getImageGroup(cardId) {
        const groupImages = document.querySelectorAll(`img[data-lovart-card-id="${cardId}"]`);
        const imageUrls = [];

        groupImages.forEach(img => {
            const cleanUrl = img.src.split('?')[0];
            if (!imageUrls.includes(cleanUrl)) {
                imageUrls.push(cleanUrl);
            }
        });

        return imageUrls;
    }

    // プレビュー画像から元の画像を探す
    function findSourceImage(previewSrc) {
        const cleanPreviewSrc = previewSrc.split('?')[0];
        const allMarkedImages = document.querySelectorAll('.lovart-slider-marked');

        for (let img of allMarkedImages) {
            const cleanImgSrc = img.src.split('?')[0];
            if (cleanImgSrc === cleanPreviewSrc) {
                return img;
            }
        }

        return null;
    }

    // 画像を切り替え(完全に新しい画像要素を作成)
    function switchImage(direction) {
        if (images.length === 0) return;

        currentImageIndex += direction;

        if (currentImageIndex < 0) {
            currentImageIndex = images.length - 1;
        } else if (currentImageIndex >= images.length) {
            currentImageIndex = 0;
        }

        const imgWrapper = document.querySelector('.ant-image-preview-img-wrapper');
        const oldImg = document.querySelector('.ant-image-preview-img');

        if (imgWrapper && oldImg) {
            const newSrc = images[currentImageIndex];
            console.log('Lovart Slider: 画像を切り替え試行:', newSrc);

            // 古い画像のスタイルを保存
            const oldStyle = oldImg.style.cssText;
            const oldTransform = oldImg.style.transform;

            // 新しい画像要素を作成
            const newImg = document.createElement('img');
            newImg.className = 'ant-image-preview-img';
            newImg.draggable = true;
            newImg.src = newSrc;
            newImg.style.cssText = oldStyle;
            newImg.style.transform = oldTransform || 'translate3d(0px, 0px, 0px) scale3d(1, 1, 1) rotate(0deg)';

            // 画像を読み込んでから置き換え
            newImg.onload = function() {
                // 古い画像を削除して新しい画像を追加
                imgWrapper.removeChild(oldImg);
                imgWrapper.appendChild(newImg);
                console.log('Lovart Slider: 画像切り替え完了:', currentImageIndex + 1, '/', images.length);
            };

            newImg.onerror = function() {
                console.error('Lovart Slider: 画像の読み込みに失敗:', newSrc);
            };

            updateCounter();
        } else {
            console.error('Lovart Slider: 画像要素が見つかりません');
        }
    }

    // カウンター表示を更新
    function updateCounter() {
        let counter = document.querySelector('.image-slider-counter');
        if (counter) {
            counter.textContent = `${currentImageIndex + 1} / ${images.length}`;
        }
    }

    // 矢印の表示/非表示を切り替え
    function toggleArrows() {
        arrowsVisible = !arrowsVisible;

        const leftArrow = document.querySelector('.image-slider-arrow-left');
        const rightArrow = document.querySelector('.image-slider-arrow-right');
        const counter = document.querySelector('.image-slider-counter');
        const toggleButton = document.querySelector('.image-slider-toggle');

        if (leftArrow && rightArrow && counter && toggleButton) {
            if (arrowsVisible) {
                leftArrow.classList.add('visible');
                rightArrow.classList.add('visible');
                counter.classList.add('visible');
                toggleButton.innerHTML = '✕ 非表示';
                toggleButton.style.background = 'rgba(244, 67, 54, 0.9)';
            } else {
                leftArrow.classList.remove('visible');
                rightArrow.classList.remove('visible');
                counter.classList.remove('visible');
                toggleButton.innerHTML = '⬅➡ 矢印表示';
                toggleButton.style.background = 'rgba(33, 150, 243, 0.9)';
            }
        }
    }

    // UIを追加
    function addSliderUI() {
        if (toggleButtonAdded) return;

        const previewWrap = document.querySelector('.ant-image-preview-wrap');
        if (!previewWrap) return;

        // 左矢印
        const leftArrow = document.createElement('button');
        leftArrow.className = 'image-slider-arrow image-slider-arrow-left';
        leftArrow.innerHTML = '←';
        leftArrow.onclick = (e) => {
            e.stopPropagation();
            switchImage(-1);
        };

        // 右矢印
        const rightArrow = document.createElement('button');
        rightArrow.className = 'image-slider-arrow image-slider-arrow-right';
        rightArrow.innerHTML = '→';
        rightArrow.onclick = (e) => {
            e.stopPropagation();
            switchImage(1);
        };

        // カウンター
        const counter = document.createElement('div');
        counter.className = 'image-slider-counter';
        counter.textContent = `${currentImageIndex + 1} / ${images.length}`;

        // トグルボタン
        const toggleButton = document.createElement('button');
        toggleButton.className = 'image-slider-toggle';
        toggleButton.innerHTML = '⬅➡ 矢印表示';
        toggleButton.onclick = (e) => {
            e.stopPropagation();
            toggleArrows();
        };

        document.body.appendChild(leftArrow);
        document.body.appendChild(rightArrow);
        document.body.appendChild(counter);
        document.body.appendChild(toggleButton);

        toggleButtonAdded = true;
        arrowsVisible = false;
        console.log('Lovart Slider: スライダーUIを追加しました');
    }

    // UIを削除
    function removeSliderUI() {
        document.querySelectorAll('.image-slider-arrow, .image-slider-counter, .image-slider-toggle').forEach(el => el.remove());
        toggleButtonAdded = false;
        arrowsVisible = false;
        currentImageIndex = 0;
        images = [];
        console.log('Lovart Slider: スライダーUIを削除しました');
    }

    // キーボード操作
    document.addEventListener('keydown', (e) => {
        const previewWrap = document.querySelector('.ant-image-preview-wrap');
        if (!previewWrap || !arrowsVisible) return;

        if (e.key === 'ArrowLeft') {
            e.preventDefault();
            switchImage(-1);
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            switchImage(1);
        } else if (e.key === 'Escape') {
            removeSliderUI();
        }
    });

    // 定期的に画像をマーク
    setInterval(markAllImages, 1000);

    // 画像プレビューの監視
    const observer = new MutationObserver((mutations) => {
        const previewWrap = document.querySelector('.ant-image-preview-wrap');
        const previewImg = document.querySelector('.ant-image-preview-img');

        if (previewWrap && previewImg && !toggleButtonAdded) {
            console.log('Lovart Slider: プレビューが開かれました');

            setTimeout(() => {
                markAllImages();

                const currentPreviewSrc = previewImg.src;
                console.log('Lovart Slider: プレビュー画像URL:', currentPreviewSrc);

                const sourceImg = findSourceImage(currentPreviewSrc);

                if (sourceImg && sourceImg.dataset.lovartCardId) {
                    const cardId = sourceImg.dataset.lovartCardId;
                    console.log('Lovart Slider: カードID:', cardId);

                    images = getImageGroup(cardId);

                    console.log('Lovart Slider: 同じグループの画像数:', images.length);

                    const cleanPreviewSrc = currentPreviewSrc.split('?')[0];
                    currentImageIndex = images.indexOf(cleanPreviewSrc);
                    if (currentImageIndex === -1) currentImageIndex = 0;

                    console.log('Lovart Slider: 現在のインデックス:', currentImageIndex);

                    if (images.length > 1) {
                        addSliderUI();
                    } else {
                        console.log('Lovart Slider: 画像が1枚のみのため矢印は表示しません');
                    }
                } else {
                    console.log('Lovart Slider: 元の画像が見つかりませんでした');
                }
            }, 300);
        } else if (!previewWrap && toggleButtonAdded) {
            removeSliderUI();
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    setTimeout(markAllImages, 2000);

    console.log('Lovart Image Slider: スクリプトが読み込まれました');
})();