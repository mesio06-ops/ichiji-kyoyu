// ==UserScript==
// @name         YouTube 弾幕コメント(APIなし版)
// @namespace    https://example.com/
// @version      0.8.5
// @description  通常コメントを上下に1件ずつ流し、タイムスタンプ付きは件数制限なしで指定時刻に追加する
// @match        https://www.youtube.com/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_registerMenuCommand
// @grant        unsafeWindow
// @run-at       document-idle
// ==/UserScript==

(() => {
  'use strict';

  // ===== 設定 =====
  const CFG = {
    maxPages: 50,       // コメント取得ページ数の上限(1ページ=約20件)
    chunkSec: 30,       // 字幕をまとめる単位(秒)
    minScore: 4.0,      // これ未満の一致度は「当てはまらない」扱い
    scrollScreenSec: 6, // 全コメント共通の速度: 画面幅を6秒で進む
    reactionDelay: 2,   // 字幕の発言から何秒後に出すか
    relatedWindowSec: 12, // タイムスタンプの前後で関連コメントを優先する秒数
    relatedMinScore: 0.18, // 共通キーワードによる関連度の下限
    cacheVersion: 3,
  };

  let enabled = GM_getValue('enabled', true);
  let unmatchedMode = GM_getValue('unmatchedMode', 'spread'); // spread=全体に散らす / hide=表示しない

  // ===== メニュー =====
  GM_registerMenuCommand('弾幕 表示/非表示', () => {
    enabled = !enabled;
    GM_setValue('enabled', enabled);
    if (overlay) overlay.style.display = enabled ? '' : 'none';
  });
  GM_registerMenuCommand('当てはまらないコメント: 散らす/隠す', () => {
    unmatchedMode = unmatchedMode === 'spread' ? 'hide' : 'spread';
    GM_setValue('unmatchedMode', unmatchedMode);
    alert('現在の設定: ' + (unmatchedMode === 'spread' ? '全体に散らす' : '表示しない'));
    start(true);
  });
  GM_registerMenuCommand('キャッシュを削除', () => {
    GM_listValues().filter(k => k.startsWith('cache_')).forEach(GM_deleteValue);
    alert('キャッシュを削除しました');
  });

  // ===== ユーティリティ =====
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const debounce = (fn, ms) => { let id; return () => { clearTimeout(id); id = setTimeout(fn, ms); }; };

  // 入れ子になったデータの中から条件に合うものを探す
  function findFirst(obj, pred, depth = 0) {
    if (!obj || typeof obj !== 'object' || depth > 40) return null;
    if (pred(obj)) return obj;
    for (const v of Object.values(obj)) {
      const r = findFirst(v, pred, depth + 1);
      if (r) return r;
    }
    return null;
  }

  // ===== データ取得 =====
  function getPlayer() { return document.getElementById('movie_player'); }

  function getPlayerResponse() {
    try {
      return unsafeWindow.document.getElementById('movie_player')?.getPlayerResponse?.() || null;
    } catch { return null; }
  }

  function ytcfgGet(name) {
    try { return unsafeWindow.ytcfg?.get?.(name); } catch { return undefined; }
  }

  // ※YouTube内部の通信。仕様変更で壊れやすい部分
  async function innertubeNext(body) {
    const key = ytcfgGet('INNERTUBE_API_KEY');
    const context = ytcfgGet('INNERTUBE_CONTEXT') || {
      client: { clientName: 'WEB', clientVersion: ytcfgGet('INNERTUBE_CLIENT_VERSION') || '2.20250101.00.00' },
    };
    const url = '/youtubei/v1/next?prettyPrint=false' + (key ? '&key=' + encodeURIComponent(key) : '');
    const res = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ context, ...body }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  function tokenOf(cir) {
    return cir?.continuationEndpoint?.continuationCommand?.token
      || cir?.button?.buttonRenderer?.command?.continuationCommand?.token
      || null;
  }

  async function fetchComments(videoId) {
    // 動画ページの情報から、コメント欄を読み込むための最初の合図(トークン)を探す
    const first = await innertubeNext({ videoId });
    const section = findFirst(first, o => o.itemSectionRenderer?.sectionIdentifier === 'comment-item-section');
    let token = tokenOf(findFirst(section, o => o.continuationItemRenderer)?.continuationItemRenderer);
    if (!token) { console.warn('[弾幕] コメント欄が見つかりません(コメントが無効の動画かもしれません)'); return []; }

    const out = [];
    const seen = new Set();
    const add = (id, text) => {
      if (!id || seen.has(id)) return;
      seen.add(id);
      out.push({ id, text: text || '' });
    };

    const seenTokens = new Set();
    for (let i = 0; i < CFG.maxPages && token && !seenTokens.has(token); i++) {
      seenTokens.add(token);
      const data = await innertubeNext({ continuation: token });

      // 新しい形式:本文は別の場所にまとめて入っている
      for (const m of data.frameworkUpdates?.entityBatchUpdate?.mutations || []) {
        const p = m.payload?.commentEntityPayload?.properties;
        if (p) add(p.commentId, p.content?.content);
      }

      // 古い形式と、次のページのトークン
      token = null;
      for (const ep of data.onResponseReceivedEndpoints || []) {
        const items = ep.reloadContinuationItemsCommand?.continuationItems
          || ep.appendContinuationItemsAction?.continuationItems || [];
        for (const it of items) {
          const cr = it.commentThreadRenderer?.comment?.commentRenderer;
          if (cr) add(cr.commentId, (cr.contentText?.runs || []).map(r => r.text).join(''));
          if (it.continuationItemRenderer) token = tokenOf(it.continuationItemRenderer);
        }
      }
      await sleep(300); // 連続で叩きすぎないように
    }
    return out;
  }

  // ※YouTube側の仕様変更で壊れやすい部分
  async function fetchTranscript(pr) {
    const tracks = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
    if (!tracks.length) return [];
    const pick =
      tracks.find(t => t.languageCode === 'ja' && t.kind !== 'asr') ||
      tracks.find(t => t.languageCode === 'ja') ||
      tracks.find(t => t.kind !== 'asr') ||
      tracks[0];
    const res = await fetch(pick.baseUrl + '&fmt=json3', { credentials: 'include' });
    const text = await res.text();
    if (!text) return [];
    const data = JSON.parse(text);
    return (data.events || [])
      .filter(e => e.segs)
      .map(e => ({
        start: e.tStartMs / 1000,
        text: e.segs.map(s => s.utf8).join('').replace(/\n/g, ' ').trim(),
      }))
      .filter(s => s.text);
  }

  // ===== トークン化(日本語は2文字ずつに区切る) =====
  const HIRA_ONLY = /^[\u3041-\u309f]+$/;

  function tokenize(str) {
    const s = str.normalize('NFKC').toLowerCase();
    const toks = [];
    for (const m of s.matchAll(/[a-z0-9]{2,}/g)) toks.push(m[0]);
    for (const m of s.matchAll(/[\u3041-\u30ff\u4e00-\u9fff\u3005]+/g)) {
      const w = m[0];
      if (w.length === 1) { if (!HIRA_ONLY.test(w)) toks.push(w); continue; }
      for (let i = 0; i < w.length - 1; i++) {
        const bg = w.slice(i, i + 2);
        if (!HIRA_ONLY.test(bg)) toks.push(bg);
      }
    }
    return toks;
  }

  // ===== BM25で字幕チャンクとコメントを照合 =====
  function buildIndex(segments) {
    const chunks = [];
    for (const seg of segments) {
      const i = Math.floor(seg.start / CFG.chunkSec);
      (chunks[i] ||= { start: i * CFG.chunkSec, segs: [] }).segs.push(seg);
    }
    const list = chunks.filter(Boolean).map(c => {
      const toks = tokenize(c.segs.map(s => s.text).join(' '));
      const tf = new Map();
      toks.forEach(t => tf.set(t, (tf.get(t) || 0) + 1));
      return { ...c, tf, len: toks.length };
    });
    const df = new Map();
    list.forEach(c => c.tf.forEach((_, t) => df.set(t, (df.get(t) || 0) + 1)));
    const N = list.length;
    const avgLen = list.reduce((a, c) => a + c.len, 0) / (N || 1);
    const idf = t => { const d = df.get(t) || 0; return Math.log(1 + (N - d + 0.5) / (d + 0.5)); };
    return { list, idf, avgLen };
  }

  function bm25(index, qToks, chunk) {
    const k1 = 1.2, b = 0.75;
    let score = 0;
    for (const t of qToks) {
      const f = chunk.tf.get(t);
      if (!f) continue;
      score += index.idf(t) * (f * (k1 + 1)) / (f + k1 * (1 - b + b * chunk.len / index.avgLen));
    }
    return score;
  }

  // ===== コメントに時刻を割り当てる =====
  const TS_RE = /(?:(\d{1,2}):)?(\d{1,2}):([0-5]\d)/g;

  function placeComments(comments, segments, videoLen) {
    const index = segments.length ? buildIndex(segments) : null;
    const items = [];

    for (const c of comments) {
      const text = c.text.replace(/\s+/g, ' ').trim();
      if (!text) continue;

      // (a) タイムスタンプ付き
      const stamps = [...text.matchAll(TS_RE)]
        .map(m => (+(m[1] || 0)) * 3600 + (+m[2]) * 60 + (+m[3]))
        .filter(t => t < videoLen);
      if (stamps.length > 3) continue; // 目次っぽいコメントは除外
      if (stamps.length) {
        stamps.forEach(t => items.push({ id: c.id, text, time: t }));
        continue;
      }

      // (b) 字幕と照合
      let time = null;
      if (index) {
        const q = [...new Set(tokenize(text))];
        if (q.length >= 2) {
          let best = null, bestScore = 0;
          for (const ch of index.list) {
            const s = bm25(index, q, ch);
            if (s > bestScore) { bestScore = s; best = ch; }
          }
          if (best && bestScore >= CFG.minScore) {
            let seg = best.segs[0], segBest = -1;
            for (const sg of best.segs) {
              const st = new Set(tokenize(sg.text));
              const ov = q.reduce((a, t) => a + (st.has(t) ? index.idf(t) : 0), 0);
              if (ov > segBest) { segBest = ov; seg = sg; }
            }
            time = Math.min(seg.start + CFG.reactionDelay, videoLen - 1);
          }
        }
      }

      // (c) 当てはまらないものは time = null のまま
      items.push({ id: c.id, text, time });
    }
    return items;
  }

  function buildDisplayList(items) {
    const list = [];
    for (const it of items) {
      let t = it.time;
      const text = it.text;
      const timestamp = t !== null && [...it.text.matchAll(TS_RE)].some(m =>
        (+(m[1] || 0)) * 3600 + (+m[2]) * 60 + (+m[3]) === t);
      list.push({ id: it.id, t, text, fullText: it.text, timestamp });
    }
    assignRelatedComments(list);
    for (const it of list) delete it.fullText;
    return list.filter(it => unmatchedMode !== 'hide' || it.t !== null || it.relatedTime !== undefined)
      .sort((a, b) => (a.t ?? Infinity) - (b.t ?? Infinity));
  }

  function assignRelatedComments(list) {
    // 感想によく出る言葉や時刻の数字だけでは、同じ話題と判定しない。
    const ignoredPhrases = ['コメント', '動画', '最高', '好き', '面白い', 'ありがとう', 'すごい', 'シーン', '場面'];
    const tokens = it => {
      let text = it.fullText.replace(TS_RE, ' ').normalize('NFKC').toLowerCase();
      for (const phrase of ignoredPhrases) text = text.replaceAll(phrase, ' ');
      return new Set(tokenize(text).filter(t => /[^0-9]/.test(t)));
    };
    const docs = list.map(it => ({ it, words: tokens(it) }));
    const anchors = docs.filter(d => d.it.timestamp && d.words.size);
    if (!anchors.length) return;
    const df = new Map();
    const seen = new Set();
    for (const d of docs) {
      if (seen.has(d.it.id)) continue;
      seen.add(d.it.id);
      d.words.forEach(t => df.set(t, (df.get(t) || 0) + 1));
    }
    const weight = t => Math.log(1 + (seen.size + 0.5) / ((df.get(t) || 0) + 0.5));
    const total = words => [...words].reduce((sum, t) => sum + weight(t), 0);
    anchors.forEach(d => { d.total = total(d.words); });
    for (const d of docs) {
      if (d.it.timestamp || !d.words.size) continue;
      const queryTotal = total(d.words);
      let best = null, bestScore = CFG.relatedMinScore;
      for (const anchor of anchors) {
        const common = [...d.words].filter(t => anchor.words.has(t));
        // 日本語の2文字区切りが一つだけ偶然一致した場合は採用しない。
        if (common.length < 2 && !common.some(t => /^[a-z][a-z0-9]{2,}$/.test(t) || /^[\u4e00-\u9fff]{2}$/.test(t))) continue;
        const shared = common.reduce((sum, t) => sum + weight(t), 0);
        const score = shared / Math.sqrt(queryTotal * anchor.total);
        if (score > bestScore || (score === bestScore && best && d.it.t !== null
          && Math.abs(anchor.it.t - d.it.t) < Math.abs(best.it.t - d.it.t))) {
          best = anchor; bestScore = score;
        }
      }
      if (best) {
        d.it.relatedTime = best.it.t;
        d.it.relatedScore = bestScore;
      }
    }
  }

  // ===== 描画 =====
  let overlay = null, state = null, rafId = 0, ro = null;
  const pool = new Map();

  function clearPool() { pool.forEach(el => el.remove()); pool.clear(); }

  function createOverlay(player) {
    overlay = document.createElement('div');
    Object.assign(overlay.style, {
      position: 'absolute', inset: '0', overflow: 'hidden',
      pointerEvents: 'none', zIndex: '30', display: enabled ? '' : 'none',
    });
    player.appendChild(overlay);
  }

  function layout() {
    const W = overlay.clientWidth, H = overlay.clientHeight;
    const fs = Math.max(14, Math.round(H / 16));
    Object.assign(state, { W, H, fs });
    clearPool();
    if (W <= 0 || H <= 0) {
      state.lanes = [[], []]; state.timestamps = []; state.timestampRows = 0;
      return;
    }

    const measure = document.createElement('div');
    Object.assign(measure.style, {
      position: 'absolute', visibility: 'hidden', whiteSpace: 'nowrap',
      fontSize: `${fs}px`, fontWeight: 'bold',
    });
    overlay.appendChild(measure);
    for (const it of state.list) {
      measure.textContent = it.text;
      it.w = measure.offsetWidth;
      // 全文を右端から一定速度で流す。長さによって変わるのは表示時間だけ。
      it.x = W;
      it.v = W / CFG.scrollScreenSec;
      it.duration = (it.x + it.w) / it.v;
    }
    measure.remove();
    state.lanes = buildLaneSchedules(state.list, state.videoLen);
    const rowEnds = [];
    state.timestamps = state.list.filter(it => it.timestamp && it.t >= 0 && it.t < state.videoLen)
      .map(it => {
        let row = rowEnds.findIndex(end => end <= it.t);
        if (row < 0) row = rowEnds.length;
        const end = it.t + it.duration;
        rowEnds[row] = end;
        return { it, start: it.t, end, row };
      });
    state.timestampRows = rowEnds.length;
  }

  function buildLaneSchedules(list, videoLen) {
    const lanes = [[], []];
    const ends = [0, 0];
    const normal = list.filter(it => !it.timestamp);
    const fillers = normal.filter(it => it.t === null && unmatchedMode !== 'hide');
    const timed = normal.filter(it => it.t !== null);
    const related = normal.filter(it => it.relatedTime !== undefined);
    const consumed = new Set();
    const append = (lane, it, start) => {
      const entry = { it, start, end: start + it.duration };
      lanes[lane].push(entry);
      ends[lane] = entry.end;
    };
    const windowStart = it => Math.max(0, it.relatedTime - CFG.relatedWindowSec);
    const windowEnd = it => Math.min(videoLen, it.relatedTime + CFG.relatedWindowSec);
    // 空いた段ごとに選ぶ。関連コメントは前後の範囲内で関連度が高い順に採用する。
    // 表示しきれない分は通常表示に回し、流れているコメントは最後まで残す。
    while (Math.min(...ends) < videoLen) {
      const lane = ends[0] <= ends[1] ? 0 : 1;
      let start = ends[lane];
      const other = lanes[1 - lane].at(-1);
      const candidates = related.filter(it => !consumed.has(it)
        && start >= windowStart(it) && start < windowEnd(it)
        && !(other?.end > start && other.it.id === it.id));
      candidates.sort((a, b) => b.relatedScore - a.relatedScore
        || Math.abs(start - a.relatedTime) - Math.abs(start - b.relatedTime));
      let it = candidates[0];
      // 関連する時刻が先にある場合は、まずその近辺での採用を待つ。
      if (!it) it = timed.find(item => !consumed.has(item) && item.t <= start
        && item.t >= 0 && item.t < videoLen
        && (item.relatedTime === undefined || start + item.duration > windowEnd(item)));
      if (!it) {
        const future = [];
        for (const item of related) {
          if (consumed.has(item)) continue;
          const at = Math.max(start, windowStart(item));
          if (at < windowEnd(item)) {
            future.push(other?.end > at && other.it.id === item.id ? other.end : at);
          }
        }
        for (const item of timed) {
          if (consumed.has(item) || item.t < 0 || item.t >= videoLen) continue;
          future.push(item.relatedTime === undefined ? item.t : Math.max(item.t, windowEnd(item)));
        }
        const upcoming = future.filter(at => at > start && at < videoLen);
        if (!upcoming.length) { ends[lane] = videoLen; continue; }
        ends[lane] = Math.min(...upcoming);
        continue;
      }
      consumed.add(it);
      append(lane, it, start);
    }
    // 時刻指定・関連コメントを先に確保し、残りを「何も流れていない区間」に配分する。
    // 動画全体への単純な等間隔配置では、時刻指定が集中した区間に重なってしまう。
    const gapsOf = entries => {
      const occupied = entries.filter(e => e.end > 0 && e.start < videoLen)
        .slice().sort((a, b) => a.start - b.start);
      const gaps = [];
      let end = 0;
      for (const e of occupied) {
        const start = Math.max(0, e.start);
        if (start > end) gaps.push({ start: end, end: start });
        end = Math.min(videoLen, Math.max(end, e.end));
      }
      if (end < videoLen) gaps.push({ start: end, end: videoLen });
      return gaps;
    };
    const stamps = list.filter(it => it.timestamp && it.t >= 0 && it.t < videoLen)
      .map(it => ({ start: it.t, end: it.t + it.duration }));
    let remainingDuration = fillers.filter(it => !consumed.has(it)).reduce((sum, it) => sum + it.duration, 0);
    for (const it of fillers) {
      if (consumed.has(it)) continue;
      const blank = gapsOf([...lanes.flat(), ...stamps]);
      const canCover = remainingDuration >= blank.reduce((sum, gap) => sum + gap.end - gap.start, 0);
      remainingDuration -= it.duration;
      let best = null;
      for (let lane = 0; lane < 2; lane++) {
        let gapIndex = 0;
        for (const slot of gapsOf(lanes[lane])) {
          if (slot.end - slot.start + 1e-8 < it.duration) continue;
          while (gapIndex < blank.length && blank[gapIndex].end <= slot.start) gapIndex++;
          for (let i = gapIndex; i < blank.length && blank[i].start < slot.end; i++) {
            const gap = blank[i];
            // 十分な件数があれば空白の端から連続して埋める。不足時は中央から分散する。
            const target = gap.start === 0 ? 0 : gap.end === videoLen
              ? videoLen - it.duration : canCover ? gap.start : (gap.start + gap.end - it.duration) / 2;
            const start = Math.max(slot.start, Math.min(target, slot.end - it.duration));
            const gain = Math.max(0, Math.min(start + it.duration, gap.end) - Math.max(start, gap.start));
            if (!gain) continue;
            const size = gap.end - gap.start;
            const priority = size + (gap.start === 0 ? videoLen * 2 : gap.end === videoLen ? videoLen : 0);
            if (!best || priority > best.priority || (priority === best.priority && gain > best.gain)
              || (priority === best.priority && gain === best.gain && lanes[lane].length < lanes[best.lane].length)) {
              best = { lane, start, size, priority, gain };
            }
          }
        }
      }
      // すでに全体が埋まっている場合は、空いている段へ追加する。
      if (!best) {
        for (let lane = 0; lane < 2; lane++) {
          for (const slot of gapsOf(lanes[lane])) {
            const size = slot.end - slot.start;
            if (size + 1e-8 < it.duration || (best && size <= best.size)) continue;
            best = { lane, start: (slot.start + slot.end - it.duration) / 2, size };
          }
        }
      }
      if (!best) continue;
      consumed.add(it);
      lanes[best.lane].push({ it, start: best.start, end: best.start + it.duration });
    }
    return lanes.map(entries => entries.sort((a, b) => a.start - b.start));
  }

  function frame() {
    rafId = requestAnimationFrame(frame);
    if (!state || !enabled) return;

    const isAd = state.player.classList.contains('ad-showing');
    overlay.style.visibility = isAd ? 'hidden' : '';
    if (isAd) return;

    const t = state.video.currentTime;
    if (state.W <= 0 || state.H <= 0) return;

    const alive = new Set();
    const draw = (key, entry, top, bottom = '') => {
      const it = entry.it;
      alive.add(key);
      let el = pool.get(key);
      if (!el) {
        el = document.createElement('div');
        Object.assign(el.style, {
          position: 'absolute', left: '0',
          whiteSpace: 'nowrap', fontSize: `${state.fs}px`, fontWeight: 'bold',
          lineHeight: '1.2', color: '#fff', opacity: '0.9', willChange: 'transform',
          textShadow: '1px 1px 2px #000,-1px -1px 2px #000,1px -1px 2px #000,-1px 1px 2px #000',
        });
        overlay.appendChild(el);
        pool.set(key, el);
      }
      if (el.textContent !== it.text) el.textContent = it.text;
      el.style.top = top;
      el.style.bottom = bottom;
      el.style.transform = `translateX(${it.x - (t - entry.start) * it.v}px)`;
    };
    for (let lane = 0; lane < 2; lane++) {
      const entries = state.lanes[lane];
      let lo = 0, hi = entries.length;
      while (lo < hi) {
        const m = (lo + hi) >> 1;
        if (entries[m].start <= t) lo = m + 1; else hi = m;
      }
      const entry = entries[lo - 1];
      if (!entry || t >= entry.end) continue;
      draw(lane, entry, lane === 0 ? '4px' : '',
        lane === 1 ? `${Math.min(50, state.H / 4)}px` : '');
    }
    // 同時刻・近い時刻のタイムスタンプも全件追加し、各コメントの終了まで残す。
    const lineH = state.fs * 1.2;
    const areaTop = 4 + lineH;
    const space = Math.max(0, state.H - Math.min(50, state.H / 4) - lineH - areaTop);
    const step = state.timestampRows > 1
      ? Math.min(lineH + 4, Math.max(0, space - lineH) / (state.timestampRows - 1)) : 0;
    for (let i = 0; i < state.timestamps.length; i++) {
      const entry = state.timestamps[i];
      if (entry.start > t) break;
      if (t < entry.end) draw(`timestamp:${i}`, entry, `${areaTop + entry.row * step}px`);
    }
    pool.forEach((el, key) => {
      if (!alive.has(key)) { el.remove(); pool.delete(key); }
    });
  }

  // ===== 起動・動画切り替え =====
  let runId = 0, startedVid = null;

  function teardown() {
    cancelAnimationFrame(rafId);
    ro?.disconnect(); ro = null;
    clearPool();
    overlay?.remove(); overlay = null;
    state = null;
  }

  async function start(force = false) {
    const videoId = location.pathname === '/watch' ? new URLSearchParams(location.search).get('v') : null;
    if (!force && videoId === startedVid) return;
    startedVid = videoId;
    const myRun = ++runId;
    teardown();
    if (!videoId) return;

    let pr = null;
    for (let i = 0; i < 50 && myRun === runId; i++) {
      const r = getPlayerResponse();
      if (r?.videoDetails?.videoId === videoId) { pr = r; break; }
      await sleep(200);
    }
    if (!pr || myRun !== runId) return;

    const videoLen = +pr.videoDetails.lengthSeconds || 0;
    if (!videoLen) return; // ライブ配信中などは対象外

    const cacheKey = `cache_${videoId}`;
    const cached = GM_getValue(cacheKey, null);
    let items;
    if (cached?.v === CFG.cacheVersion) {
      items = cached.items;
    } else {
      try {
        const [comments, segments] = await Promise.all([
          fetchComments(videoId),
          fetchTranscript(pr).catch(e => { console.warn('[弾幕] 字幕取得失敗', e); return []; }),
        ]);
        items = placeComments(comments, segments, videoLen);
        if (comments.length && segments.length) {
          GM_setValue(cacheKey, { v: CFG.cacheVersion, items, savedAt: Date.now() });
        }
        const matched = items.filter(i => i.time !== null).length;
        console.log(`[弾幕] コメント${comments.length}件 / 字幕${segments.length}行 / 時刻割り当て${matched}件`);
      } catch (e) {
        console.error('[弾幕]', e);
        return;
      }
    }
    if (myRun !== runId) return;

    const player = getPlayer();
    const video = player?.querySelector('video.html5-main-video');
    if (!player || !video) return;

    createOverlay(player);
    state = { player, video, videoLen, list: buildDisplayList(items) };
    layout();
    ro = new ResizeObserver(debounce(() => state && layout(), 150));
    ro.observe(player);
    rafId = requestAnimationFrame(frame);
  }

  document.addEventListener('yt-navigate-finish', () => start());
  start();
})();
