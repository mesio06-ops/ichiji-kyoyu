// ==UserScript==
// @name         Lovart.ai Prompt Copy Button
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  自宅・事務所の両方のLovart画面に対応し、プロンプトへコピーボタンを追加
// @author       You
// @match        https://lovart.ai/*
// @match        https://*.lovart.ai/*
// @grant        GM_setClipboard
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    const marker = 'lovart-copy-common-1-3';
    if (document.getElementById(marker)) return;
    const style = document.createElement('style');
    style.id = marker;
    style.textContent = `
        .lovart-copy-button {
            position: absolute; bottom: 8px; right: 8px; padding: 6px 12px;
            background-color: #4CAF50; color: white; border: none;
            border-radius: 6px; cursor: pointer; font-size: 12px;
            font-weight: 500; transition: all 0.2s ease; z-index: 10;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .lovart-copy-button:hover {
            background-color: #45a049;
            box-shadow: 0 3px 6px rgba(0,0,0,0.15);
        }
        .lovart-copy-button:active { transform: scale(0.95); }
        .lovart-copy-button.copied { background-color: #2196F3; }
        .lovart-message-wrapper { position: relative; }
        .agent-chat-user-input-text-container.lovart-copy-host {
            position: relative !important;
        }
    `;
    (document.head || document.documentElement).appendChild(style);

    async function copyToClipboard(text) {
        if (typeof GM_setClipboard === 'function') {
            try {
                await GM_setClipboard(text);
                return true;
            } catch (_) { /* 次のコピー方法を試します。 */ }
        }

        const textarea = document.createElement('textarea');
        const focusedElement = document.activeElement;
        textarea.value = text;
        textarea.style.cssText = 'position:fixed;left:-9999px;top:0;';
        textarea.setAttribute('readonly', '');
        try {
            document.body.appendChild(textarea);
            textarea.select();
            textarea.setSelectionRange(0, textarea.value.length);
            if (document.execCommand('copy')) return true;
        } catch (_) { /* ブラウザーのコピー機能へ進みます。 */ }
        finally {
            textarea.remove();
            if (focusedElement?.isConnected) {
                focusedElement.focus({ preventScroll: true });
            }
        }

        if (navigator.clipboard?.writeText) {
            try {
                await navigator.clipboard.writeText(text);
                return true;
            } catch (_) { /* 呼び出し元に失敗を伝えます。 */ }
        }
        return false;
    }

    function createCopyButton(textElement) {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'lovart-copy-button';
        button.textContent = 'コピー';
        let resetTimer;
        button.addEventListener('click', async (event) => {
            event.preventDefault();
            event.stopPropagation();
            clearTimeout(resetTimer);
            const text = textElement.innerText || textElement.textContent || '';
            const success = await copyToClipboard(text);
            button.textContent = success ? 'コピー完了！' : 'エラー';
            button.classList.toggle('copied', success);
            resetTimer = setTimeout(() => {
                button.textContent = 'コピー';
                button.classList.remove('copied');
            }, 2000);
        });
        return button;
    }

    function addCopyButtons() {
        // 自宅版が対象にしていた画面構造へ対応します。
        document.querySelectorAll('[data-testid="user-message-text"]').forEach(element => {
            if (!element.parentElement) return;
            let wrapper = element.parentElement;
            if (!wrapper.classList.contains('lovart-message-wrapper')) {
                wrapper = document.createElement('div');
                wrapper.className = 'lovart-message-wrapper';
                element.parentNode.insertBefore(wrapper, element);
                wrapper.appendChild(element);
            }
            if (!wrapper.querySelector('.lovart-copy-button')) {
                wrapper.appendChild(createCopyButton(element));
            }
        });

        // 事務所版が対象にしていた画面構造へ対応します。
        document.querySelectorAll('.agent-chat-user-input-text-container').forEach(container => {
            if (container.querySelector('[data-testid="user-message-text"], .lovart-copy-button')) return;
            const textElement = container.querySelector('div[class*="rounded-lg"]');
            if (!textElement) return;
            container.classList.add('lovart-copy-host');
            container.appendChild(createCopyButton(textElement));
        });
    }

    let scanTimer;
    function scheduleScan() {
        clearTimeout(scanTimer);
        scanTimer = setTimeout(addCopyButtons, 100);
    }

    function initialize() {
        addCopyButtons();
        const observer = new MutationObserver(scheduleScan);
        observer.observe(document.body, { childList: true, subtree: true });
    }

    if (document.body) initialize();
    else document.addEventListener('DOMContentLoaded', initialize, { once: true });
})();
