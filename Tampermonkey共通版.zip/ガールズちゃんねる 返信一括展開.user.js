// ==UserScript==
// @name         ガールズちゃんねる 返信一括展開
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  返信を自動で一括展開（スタート/ストップ機能付き）
// @match        https://girlschannel.net/topics/*
// @grant        GM_xmlhttpRequest
// @connect      girlschannel.net
// ==/UserScript==

(function() {
    'use strict';

    let isRunning = false;
    let shouldStop = false;

    // スタイル追加
    const style = document.createElement('style');
    style.textContent = `
        .inline-replies {
            margin: 10px 0 10px 20px;
            padding: 10px;
            background: #f9f9f9;
            border-left: 3px solid #e91e63;
            border-radius: 4px;
        }
        .inline-replies .comment-item {
            margin: 8px 0;
            padding: 8px;
            background: #fff;
            border: 1px solid #eee;
            border-radius: 4px;
        }
        .gc-auto-expand-panel {
            position: fixed;
            top: 100px;
            right: 20px;
            z-index: 9999;
            background: #fff;
            border: 2px solid #e91e63;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            font-family: sans-serif;
        }
        .gc-auto-expand-panel h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #e91e63;
        }
        .gc-auto-expand-panel button {
            display: block;
            width: 100%;
            margin: 5px 0;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            transition: opacity 0.2s;
        }
        .gc-auto-expand-panel button:hover {
            opacity: 0.8;
        }
        .gc-btn-start {
            background: #4CAF50;
            color: #fff;
        }
        .gc-btn-stop {
            background: #f44336;
            color: #fff;
        }
        .gc-btn-close-all {
            background: #9e9e9e;
            color: #fff;
        }
        .gc-status {
            margin-top: 10px;
            padding: 8px;
            background: #f5f5f5;
            border-radius: 4px;
            font-size: 12px;
            text-align: center;
        }
        .gc-progress {
            margin-top: 5px;
            height: 6px;
            background: #eee;
            border-radius: 3px;
            overflow: hidden;
        }
        .gc-progress-bar {
            height: 100%;
            background: #e91e63;
            width: 0%;
            transition: width 0.3s;
        }
    `;
    document.head.appendChild(style);

    // コントロールパネル作成
    const panel = document.createElement('div');
    panel.className = 'gc-auto-expand-panel';
    panel.innerHTML = `
        <h3>📝 返信一括展開</h3>
        <button class="gc-btn-start" id="gcStartBtn">▶ スタート</button>
        <button class="gc-btn-stop" id="gcStopBtn" disabled>■ ストップ</button>
        <button class="gc-btn-close-all" id="gcCloseAllBtn">✕ 全て閉じる</button>
        <div class="gc-status" id="gcStatus">待機中</div>
        <div class="gc-progress"><div class="gc-progress-bar" id="gcProgressBar"></div></div>
    `;
    document.body.appendChild(panel);

    const startBtn = document.getElementById('gcStartBtn');
    const stopBtn = document.getElementById('gcStopBtn');
    const closeAllBtn = document.getElementById('gcCloseAllBtn');
    const status = document.getElementById('gcStatus');
    const progressBar = document.getElementById('gcProgressBar');

    // 返信を取得して展開
    function fetchReplies(btn) {
        return new Promise((resolve, reject) => {
            const commentItem = btn.closest('.comment-item');

            if (commentItem.querySelector('.inline-replies')) {
                resolve('skip');
                return;
            }

            const url = btn.href;

            GM_xmlhttpRequest({
                method: 'GET',
                url: url,
                onload: (response) => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response.responseText, 'text/html');
                    const replies = doc.querySelectorAll('.comment-item');

                    const container = document.createElement('div');
                    container.className = 'inline-replies';

                    replies.forEach(reply => {
                        container.appendChild(reply.cloneNode(true));
                    });

                    commentItem.appendChild(container);
                    btn.style.color = '#999';
                    resolve('done');
                },
                onerror: () => {
                    reject('error');
                }
            });
        });
    }

    // 自動展開処理
    async function autoExpand() {
        const buttons = document.querySelectorAll('.res-count-btn');
        const total = buttons.length;

        if (total === 0) {
            status.textContent = '返信がありません';
            return;
        }

        isRunning = true;
        shouldStop = false;
        startBtn.disabled = true;
        stopBtn.disabled = false;

        for (let i = 0; i < buttons.length; i++) {
            if (shouldStop) {
                status.textContent = `停止しました (${i}/${total})`;
                break;
            }

            status.textContent = `展開中... ${i + 1}/${total}`;
            progressBar.style.width = `${((i + 1) / total) * 100}%`;

            try {
                await fetchReplies(buttons[i]);
                // サーバー負荷軽減のため待機
                await new Promise(r => setTimeout(r, 500));
            } catch (e) {
                console.error('取得エラー:', e);
            }
        }

        if (!shouldStop) {
            status.textContent = `完了！ (${total}件展開)`;
        }

        isRunning = false;
        startBtn.disabled = false;
        stopBtn.disabled = true;
    }

    // 全て閉じる
    function closeAll() {
        document.querySelectorAll('.inline-replies').forEach(el => el.remove());
        document.querySelectorAll('.res-count-btn').forEach(btn => {
            btn.style.color = '';
        });
        status.textContent = '全て閉じました';
        progressBar.style.width = '0%';
    }

    // イベント
    startBtn.addEventListener('click', autoExpand);
    stopBtn.addEventListener('click', () => {
        shouldStop = true;
        status.textContent = '停止中...';
    });
    closeAllBtn.addEventListener('click', closeAll);

})();