// ==UserScript==
// @name         はてなブックマーク無限スクロール（修正版）
// @namespace    https://tampermonkey.net/
// @version      1.1.0
// @description  はてなブックマークで無限スクロールを実現（現在のHTML構造に対応）
// @author       AI Assistant
// @match        https://b.hatena.ne.jp/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ===== 設定項目 =====
    const CONFIG = {
        PREFETCH_MARGIN_PX: 800,     // 自動読み込みを開始する距離（ピクセル）
        MIN_ITEMS_THRESHOLD: 1,      // 有効なページと判定する最小アイテム数
        LOAD_DELAY: 1500,           // 連続読み込み間隔（ミリ秒）
        DEBUG: true,                // デバッグモード
        AUTO_LOAD_ENABLED: true     // 初期状態での自動読み込み有効/無効
    };

    // ===== セレクタ定義（実際のHTMLに基づく） =====
    const SELECTORS = {
        ITEMS: [
            'ul.entrylist-item > li',               // メインエントリーリスト
            'ul.entrylist-header-main > li',        // ヘッダー部分のエントリー
            'li.js-keyboard-selectable-item',       // キーボード選択可能アイテム
            'li.entrylist-image-entry'              // 画像付きエントリー
        ],
        NEXT_LINKS: [
            'a.js-keyboard-openable',               // 提供されたセレクタ
            'p.entrylist-readmore a',               // 「次のページ」リンク
            'a[href*="page="]'                      // ページパラメータを含むリンク
        ]
    };

    // ===== グローバル変数 =====
    let isLoading = false;
    let isFinished = false;
    let autoLoadEnabled = CONFIG.AUTO_LOAD_ENABLED;
    let nextURL = null;
    let listContainer = null;
    let itemSelector = null;
    let seenItems = new Set();
    let statusBar = null;
    let controlPanel = null;

    // ===== ユーティリティ関数 =====

    /**
     * デバッグログ出力
     */
    function log(...args) {
        if (CONFIG.DEBUG) {
            console.log('[はてなブックマーク無限スクロール]', ...args);
        }
    }

    /**
     * 絶対URL変換
     */
    function toAbsoluteURL(href, base = location.href) {
        try {
            return new URL(href, base).href;
        } catch (e) {
            log('URL変換エラー:', e);
            return null;
        }
    }

    /**
     * アイテムの一意キーを生成（重複チェック用）
     */
    function generateItemKey(element) {
        // data-entry-idを優先的に使用
        const entryId = element.querySelector('[data-entry-id]')?.getAttribute('data-entry-id');
        if (entryId) {
            return `id:${entryId}`;
        }

        // エントリーリンクを検索
        const link = element.querySelector('h3 a, .entrylist-contents-title a, a[href*="toyokeizai.net"]');
        if (link && link.href) {
            return `url:${link.href}`;
        }

        // 最終手段：テキスト内容の一部を使用
        const text = (element.textContent || '').trim().slice(0, 100);
        return `text:${text}`;
    }

    // ===== 次ページリンク検出 =====

    /**
     * 次のページへのリンクを検出
     */
    function findNextPageLink(doc = document) {
        // まず「次のページ」テキストを含むリンクを探す
        const readMoreSection = doc.querySelector('p.entrylist-readmore');
        if (readMoreSection) {
            const link = readMoreSection.querySelector('a');
            if (link && link.textContent.trim().includes('次のページ')) {
                log('次のページリンクを発見:', link.href);
                return link;
            }
        }

        // その他のセレクタで検索
        for (const selector of SELECTORS.NEXT_LINKS) {
            const links = doc.querySelectorAll(selector);
            for (const link of links) {
                if (link.textContent.trim().includes('次のページ')) {
                    log('次のページリンクを発見:', link.href);
                    return link;
                }
            }
        }

        log('次のページリンクが見つかりませんでした');
        return null;
    }

    // ===== リストコンテナ検出 =====

    /**
     * エントリーリストのコンテナとセレクタを検出
     */
    function detectListContainer(doc = document) {
        // まずメインのエントリーリストを検索
        const mainList = doc.querySelector('ul.entrylist-item');
        if (mainList) {
            const items = mainList.querySelectorAll('li.js-keyboard-selectable-item');
            if (items.length >= CONFIG.MIN_ITEMS_THRESHOLD) {
                log(`メインリストコンテナを検出: ul.entrylist-item (${items.length}件)`);
                return {
                    container: mainList,
                    selector: 'li.js-keyboard-selectable-item'
                };
            }
        }

        // フォールバック: その他のセレクタで検索
        for (const selector of SELECTORS.ITEMS) {
            const items = doc.querySelectorAll(selector);
            if (items.length >= CONFIG.MIN_ITEMS_THRESHOLD) {
                const firstItem = items[0];
                const container = firstItem.closest('ul, ol, div') || firstItem.parentElement;
                log(`リストコンテナを検出: ${selector} (${items.length}件)`);
                return { container, selector };
            }
        }

        log('リストコンテナが見つかりません');
        return null;
    }

    // ===== UI要素作成 =====

    /**
     * ステータスバー作成
     */
    function createStatusBar() {
        const bar = document.createElement('div');
        bar.id = 'hatena-infinite-scroll-status';
        bar.style.cssText = `
            position: fixed;
            left: 16px;
            bottom: 16px;
            z-index: 2147483647;
            background: rgba(0, 0, 0, 0.8);
            color: white;
            padding: 8px 12px;
            border-radius: 16px;
            font-size: 12px;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            pointer-events: none;
            transition: opacity 0.3s ease;
            opacity: 0;
            max-width: 300px;
        `;
        document.body.appendChild(bar);
        return bar;
    }

    /**
     * コントロールパネル作成
     */
    function createControlPanel() {
        const panel = document.createElement('div');
        panel.id = 'hatena-infinite-scroll-panel';
        panel.style.cssText = `
            position: fixed;
            top: 16px;
            right: 16px;
            z-index: 2147483647;
            background: white;
            border: 2px solid #ff6600;
            border-radius: 8px;
            padding: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 12px;
            min-width: 150px;
        `;

        // タイトル
        const title = document.createElement('div');
        title.textContent = '無限スクロール';
        title.style.cssText = 'font-weight: bold; margin-bottom: 8px; color: #ff6600; text-align: center;';

        // 切り替えボタン
        const toggleButton = document.createElement('button');
        updateToggleButton(toggleButton);
        toggleButton.style.cssText = `
            width: 100%;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: bold;
            transition: background-color 0.2s ease;
        `;

        toggleButton.addEventListener('click', function() {
            autoLoadEnabled = !autoLoadEnabled;
            updateToggleButton(toggleButton);
            showStatus(autoLoadEnabled ? '自動読み込み: 有効' : '自動読み込み: 無効');
        });

        panel.appendChild(title);
        panel.appendChild(toggleButton);
        document.body.appendChild(panel);

        return panel;
    }

    /**
     * 切り替えボタンの表示を更新
     */
    function updateToggleButton(button) {
        button.textContent = autoLoadEnabled ? '停止' : '開始';
        button.style.backgroundColor = autoLoadEnabled ? '#ff4444' : '#44aa44';
        button.style.color = 'white';
    }

    /**
     * ステータスメッセージ表示
     */
    function showStatus(message, duration = 2000) {
        if (!statusBar) return;

        statusBar.textContent = message;
        statusBar.style.opacity = '1';

        clearTimeout(statusBar._hideTimer);
        statusBar._hideTimer = setTimeout(() => {
            statusBar.style.opacity = '0';
        }, duration);
    }

    // ===== メイン機能 =====

    /**
     * 次のページを読み込み
     */
    async function loadNextPage() {
        if (isLoading || isFinished || !autoLoadEnabled || !nextURL) {
            return;
        }

        isLoading = true;
        showStatus('読み込み中...', 0);
        log('次のページを読み込み:', nextURL);

        try {
            const response = await fetch(nextURL, {
                credentials: 'same-origin',
                headers: {
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const html = await response.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            // 新しいページのコンテンツを取得
            const newContainer = detectListContainer(doc);
            if (!newContainer || !newContainer.container) {
                throw new Error('新しいページでコンテンツが見つかりません');
            }

            // アイテムを追加
            const newItems = newContainer.container.querySelectorAll(newContainer.selector);
            let addedCount = 0;

            for (const item of newItems) {
                const itemKey = generateItemKey(item);

                if (!seenItems.has(itemKey)) {
                    seenItems.add(itemKey);

                    // ID重複を避けるため削除
                    const clonedItem = item.cloneNode(true);
                    if (clonedItem.id) {
                        clonedItem.removeAttribute('id');
                    }

                    // 子要素のIDも削除
                    clonedItem.querySelectorAll('[id]').forEach(el => el.removeAttribute('id'));

                    listContainer.appendChild(clonedItem);
                    addedCount++;
                }
            }

            // 次のページのリンクを更新
            const newNextLink = findNextPageLink(doc);
            if (newNextLink) {
                nextURL = toAbsoluteURL(newNextLink.getAttribute('href') || newNextLink.href, nextURL);
                log('次のURL更新:', nextURL);
            } else {
                nextURL = null;
                isFinished = true;
                log('最終ページに到達');
            }

            if (addedCount > 0) {
                showStatus(`${addedCount}件のエントリーを追加`);
            } else if (isFinished) {
                showStatus('すべてのページを読み込み完了');
            } else {
                showStatus('新しいエントリーはありませんでした');
            }

        } catch (error) {
            console.error('読み込みエラー:', error);
            showStatus(`エラー: ${error.message}`);

            // エラー時は一定時間後に再試行可能にする
            setTimeout(() => {
                isLoading = false;
            }, 5000);
            return;
        }

        // 読み込み完了後の処理
        setTimeout(() => {
            isLoading = false;
        }, CONFIG.LOAD_DELAY);
    }

    /**
     * スクロール監視
     */
    function handleScroll() {
        if (!autoLoadEnabled || isLoading || isFinished) return;

        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight;

        const distanceFromBottom = documentHeight - scrollTop - windowHeight;

        if (CONFIG.DEBUG && distanceFromBottom < 1000) {
            log(`スクロール位置: 下から${Math.round(distanceFromBottom)}px`);
        }

        // 設定された距離まで近づいたら読み込み開始
        if (distanceFromBottom < CONFIG.PREFETCH_MARGIN_PX) {
            log('読み込みトリガー発動');
            loadNextPage();
        }
    }

    /**
     * 既存のページャーを非表示
     */
    function hideExistingPagers() {
        const readMoreSection = document.querySelector('p.entrylist-readmore');
        if (readMoreSection) {
            readMoreSection.style.display = 'none';
            log('既存のページャーを非表示にしました');
        }
    }

    // ===== 初期化 =====

    /**
     * スクリプト初期化
     */
    function initialize() {
        log('スクリプトを初期化中...');

        // 次のページリンクを検出
        const nextLink = findNextPageLink();
        if (!nextLink) {
            log('次のページリンクが見つかりません - スクリプトを終了');
            return;
        }

        nextURL = toAbsoluteURL(nextLink.getAttribute('href') || nextLink.href);
        if (!nextURL) {
            log('有効な次のページURLが取得できません');
            return;
        }

        // リストコンテナを検出
        const detected = detectListContainer();
        if (!detected) {
            log('エントリーリストが見つかりません - スクリプトを終了');
            return;
        }

        listContainer = detected.container;
        itemSelector = detected.selector;

        // 既存のアイテムを記録
        const existingItems = listContainer.querySelectorAll(itemSelector);
        existingItems.forEach(item => {
            const key = generateItemKey(item);
            seenItems.add(key);
        });

        log(`既存アイテム数: ${existingItems.length}`);

        // UI要素を作成
        statusBar = createStatusBar();
        controlPanel = createControlPanel();

        // イベントリスナーを設定
        window.addEventListener('scroll', handleScroll, { passive: true });

        // 次のページリンクのクリックを無効化
        nextLink.addEventListener('click', (e) => {
            e.preventDefault();
            if (!isFinished) {
                loadNextPage();
            }
        }, { capture: true });

        // 既存のページャーを非表示
        hideExistingPagers();

        showStatus('無限スクロールが有効になりました');
        log('初期化完了');

        // 初回チェック（コンテンツが少ない場合の対応）
        setTimeout(handleScroll, 1000);
    }

    // ===== エントリーポイント =====

    // DOM読み込み完了後に初期化
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize, { once: true });
    } else {
        // 少し遅延させてページの描画完了を待つ
        setTimeout(initialize, 500);
    }

})();
