// ==UserScript==
// @name         はてな匿名ダイアリー - 自動スクロール
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  「記事への反応」セクションへ自動スクロール + ページトップボタン
// @author       You
// @match        https://anond.hatelabo.jp/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let scrollInterval = null;
    let isScrolling = false;

    // スクロールコントロールパネル（右上）
    const scrollPanel = document.createElement('div');
    scrollPanel.id = 'scroll-control-panel';
    scrollPanel.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        border: 2px solid #333;
        border-radius: 8px;
        padding: 15px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.3);
        z-index: 10000;
        font-family: sans-serif;
        min-width: 180px;
    `;

    scrollPanel.innerHTML = `
        <div style="margin-bottom: 12px; font-weight: bold; font-size: 14px; text-align: center;">
            自動スクロール
        </div>
        <button id="scroll-start-btn" style="
            width: 100%;
            padding: 10px;
            margin-bottom: 8px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
        ">スタート</button>
        <button id="scroll-stop-btn" style="
            width: 100%;
            padding: 10px;
            margin-bottom: 8px;
            background: #f44336;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            font-weight: bold;
            display: none;
        ">ストップ</button>
        <div id="scroll-status" style="
            margin-top: 10px;
            font-size: 12px;
            color: #666;
            text-align: center;
        ">待機中</div>
    `;

    document.body.appendChild(scrollPanel);

    // ページトップボタン（右下）
    const topButton = document.createElement('button');
    topButton.id = 'page-top-btn';
    topButton.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 12px 20px;
        background: #2196F3;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 13px;
        font-weight: bold;
        box-shadow: 0 4px 6px rgba(0,0,0,0.3);
        z-index: 10000;
        transition: all 0.3s;
    `;
    topButton.textContent = 'ページトップへ';
    topButton.title = 'ページトップへ';

    document.body.appendChild(topButton);

    // ボタン要素を取得
    const startBtn = document.getElementById('scroll-start-btn');
    const stopBtn = document.getElementById('scroll-stop-btn');
    const status = document.getElementById('scroll-status');

    // 「記事への反応」セクションを探す関数
    function findReactionSection() {
        // よくあるパターンを探す
        const headings = document.querySelectorAll('h2, h3, h4, .section-title');
        for (let heading of headings) {
            if (heading.textContent.includes('記事への反応') ||
                heading.textContent.includes('ブックマークコメント')) {
                return heading;
            }
        }

        // idやclassで探す
        const sections = document.querySelectorAll('[id*="reaction"], [id*="bookmark"], [class*="reaction"], [class*="bookmark"]');
        if (sections.length > 0) {
            return sections[0];
        }

        return null;
    }

    // スクロール開始
    function startScrolling() {
        const target = findReactionSection();

        if (!target) {
            status.textContent = 'セクションが見つかりません';
            status.style.color = '#f44336';
            return;
        }

        isScrolling = true;
        startBtn.style.display = 'none';
        stopBtn.style.display = 'block';
        status.textContent = 'スクロール中...';
        status.style.color = '#4CAF50';

        // スムーズにスクロール
        const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - 100;
        const startPosition = window.pageYOffset;
        const distance = targetPosition - startPosition;
        const duration = 2000; // 2秒かけてスクロール
        let startTime = null;

        function animation(currentTime) {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const progress = Math.min(timeElapsed / duration, 1);

            // イージング関数（ease-in-out）
            const ease = progress < 0.5
                ? 2 * progress * progress
                : -1 + (4 - 2 * progress) * progress;

            window.scrollTo(0, startPosition + distance * ease);

            if (timeElapsed < duration && isScrolling) {
                requestAnimationFrame(animation);
            } else {
                stopScrolling();
                status.textContent = '到達しました';
                status.style.color = '#4CAF50';
            }
        }

        requestAnimationFrame(animation);
    }

    // スクロール停止
    function stopScrolling() {
        isScrolling = false;
        startBtn.style.display = 'block';
        stopBtn.style.display = 'none';
        status.textContent = '停止';
        status.style.color = '#666';
    }

    // ページトップへ
    function scrollToTop() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }

    // イベントリスナー
    startBtn.addEventListener('click', startScrolling);
    stopBtn.addEventListener('click', stopScrolling);
    topButton.addEventListener('click', scrollToTop);

    // ホバーエフェクト - スクロールボタン
    [startBtn, stopBtn].forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.opacity = '0.8';
        });
        btn.addEventListener('mouseleave', function() {
            this.style.opacity = '1';
        });
    });

    // ホバーエフェクト - ページトップボタン
    topButton.addEventListener('mouseenter', function() {
        this.style.opacity = '0.8';
    });
    topButton.addEventListener('mouseleave', function() {
        this.style.opacity = '1';
    });

})();