// ==UserScript==
// @name         Old Reddit Expand Comments (Buttons Always Show)
// @namespace    http://tampermonkey.net/
// @version      1.8
// @description  Expand Reddit comments with start/stop buttons that never disappear. Runs reliably on old.reddit.com only.
// @author       You
// @match        https://old.reddit.com/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    let stopFlag = false;

    function createControlButtons() {
        if (document.getElementById('expand-comments-container')) return; // 2重設置防止

        const container = document.createElement('div');
        container.id = 'expand-comments-container';
        container.style.position = 'fixed';
        container.style.top = '10px';
        container.style.right = '10px';
        container.style.zIndex = '9999';
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.gap = '10px';

        const startBtn = document.createElement('button');
        startBtn.innerText = '💬 コメントをすぐ開く';
        styleButton(startBtn, '#ff4500');
        startBtn.addEventListener('click', () => {
            stopFlag = false;
            expandAllCommentsSmart();
        });

        const stopBtn = document.createElement('button');
        stopBtn.innerText = '🛑 停止';
        styleButton(stopBtn, '#555');
        stopBtn.addEventListener('click', () => {
            stopFlag = true;
            alert('🛑 展開を停止しました');
        });

        container.appendChild(startBtn);
        container.appendChild(stopBtn);
        document.body.appendChild(container);
    }

    function createScrollToTopButton() {
        if (document.getElementById('scroll-to-top-btn')) return; // 2重設置防止

        const scrollBtn = document.createElement('button');
        scrollBtn.id = 'scroll-to-top-btn';
        scrollBtn.innerText = '⬆️ トップへ';
        scrollBtn.style.position = 'fixed';
        scrollBtn.style.bottom = '20px';
        scrollBtn.style.right = '20px';
        scrollBtn.style.zIndex = '9999';
        styleButton(scrollBtn, '#0079d3');

        scrollBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // スクロール位置に応じてボタンの表示/非表示を切り替え
        scrollBtn.style.display = 'none';
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                scrollBtn.style.display = 'block';
            } else {
                scrollBtn.style.display = 'none';
            }
        });

        document.body.appendChild(scrollBtn);
    }

    function styleButton(btn, bgColor) {
        btn.style.padding = '10px 14px';
        btn.style.fontSize = '14px';
        btn.style.background = bgColor;
        btn.style.color = 'white';
        btn.style.border = 'none';
        btn.style.borderRadius = '8px';
        btn.style.cursor = 'pointer';
        btn.style.boxShadow = '2px 2px 6px rgba(0,0,0,0.3)';
    }

    async function expandAllCommentsSmart() {
        const expandButtons = Array.from(document.querySelectorAll('.expand')).filter(e => e.textContent.trim() === '[+]');
        const moreLinks = Array.from(document.querySelectorAll('a')).filter(link =>
            link.textContent.trim().match(/^コメントをもっと表示する|^load more comments|^continue this thread/i)
        );

        const allTargets = [...expandButtons, ...moreLinks];

        for (let i = 0; i < allTargets.length; i++) {
            if (stopFlag) break;

            try {
                allTargets[i].click();
            } catch (e) {
                console.warn('クリック失敗:', e);
            }

            await new Promise(resolve => setTimeout(resolve, 1000)); // 1秒間隔
        }

        if (!stopFlag) {
            alert('✅ コメントをすべて展開しました!');
        }
    }

    // 安定のボタン設置(100ms後に実行)
    setTimeout(() => {
        createControlButtons();
        createScrollToTopButton();
    }, 100);
})();