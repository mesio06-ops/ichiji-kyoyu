// ==UserScript==
// @name         YouTube コメント自動読み込み（拡張機能対応版）
// @namespace    http://tampermonkey.net/
// @version      2.1
// @description  YouTubeのコメントを自動で読み込み続ける（Show YouTube comments while watching等の拡張機能対応）
// @author       You
// @match        https://www.youtube.com/watch*
// @grant        GM_setValue
// @grant        GM_getValue
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    // 設定項目
    const CONFIG = {
        INTERVAL_MS: 2000,
        AUTO_CLICK_REPLIES: true,
        MAX_CLICKS_PER_TICK: 5,
        SCROLL_STEP: 600,
        DETECTION_TIMEOUT: 8000
    };

    let timer = null;
    let isRunning = false;
    let lastUrl = location.href;
    let controlPanel = null;
    let currentMode = 'detecting'; // 'detecting', 'sidebar', 'normal'
    let targetContainer = null;
    let scrollableElement = null;

    // **コントロールパネルの作成**
    function createControlPanel() {
        if (controlPanel) return;

        controlPanel = document.createElement('div');
        controlPanel.id = 'yt-comment-loader-panel';

        Object.assign(controlPanel.style, {
            position: 'fixed',
            top: '20px',
            right: '20px',
            zIndex: '2147483647',
            background: 'rgba(33, 33, 33, 0.95)',
            color: '#fff',
            padding: '15px',
            borderRadius: '10px',
            fontFamily: 'Roboto, Arial, sans-serif',
            fontSize: '14px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
            border: '1px solid #555',
            minWidth: '240px'
        });

        // タイトル
        const title = document.createElement('div');
        title.textContent = 'コメント自動読み込み';
        title.style.cssText = `
            font-weight: bold;
            margin-bottom: 8px;
            text-align: center;
            color: #fff;
        `;

        // モード表示
        const modeDisplay = document.createElement('div');
        modeDisplay.id = 'yt-mode-display';
        modeDisplay.style.cssText = `
            font-size: 11px;
            text-align: center;
            color: #4CAF50;
            margin-bottom: 12px;
            padding: 4px 8px;
            background: rgba(76, 175, 80, 0.2);
            border-radius: 4px;
            border: 1px solid rgba(76, 175, 80, 0.3);
        `;

        // ボタンコンテナ
        const buttonContainer = document.createElement('div');
        buttonContainer.style.cssText = `
            display: flex;
            gap: 8px;
            margin-bottom: 10px;
        `;

        // スタートボタン
        const startButton = document.createElement('button');
        startButton.textContent = 'スタート';
        startButton.id = 'yt-start-btn';
        styleButton(startButton, '#00c851');
        startButton.addEventListener('click', startAutoLoader);

        // ストップボタン
        const stopButton = document.createElement('button');
        stopButton.textContent = 'ストップ';
        stopButton.id = 'yt-stop-btn';
        styleButton(stopButton, '#ff4444');
        stopButton.addEventListener('click', stopAutoLoader);

        // 再検出ボタン
        const redetectButton = document.createElement('button');
        redetectButton.textContent = '再検出';
        redetectButton.id = 'yt-redetect-btn';
        styleButton(redetectButton, '#2196F3');
        redetectButton.style.fontSize = '11px';
        redetectButton.style.padding = '6px 12px';
        redetectButton.addEventListener('click', () => {
            currentMode = 'detecting';
            detectCommentContainer().then(() => {
                updateModeDisplay();
                updateButtonStates();
            });
        });

        // ステータス表示
        const statusDiv = document.createElement('div');
        statusDiv.id = 'yt-status';
        statusDiv.style.cssText = `
            font-size: 12px;
            text-align: center;
            color: #ccc;
            margin-top: 8px;
        `;

        // 要素の組み立て
        buttonContainer.appendChild(startButton);
        buttonContainer.appendChild(stopButton);
        controlPanel.appendChild(title);
        controlPanel.appendChild(modeDisplay);
        controlPanel.appendChild(buttonContainer);
        controlPanel.appendChild(redetectButton);
        controlPanel.appendChild(statusDiv);

        document.body.appendChild(controlPanel);

        updateModeDisplay();
        updateStatus('検出中...');
        updateButtonStates();
    }

    // **ボタンのスタイル設定**
    function styleButton(button, backgroundColor) {
        Object.assign(button.style, {
            background: backgroundColor,
            color: '#fff',
            border: 'none',
            padding: '8px 16px',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '12px',
            fontWeight: '500',
            transition: 'all 0.2s ease',
            flex: '1'
        });

        button.addEventListener('mouseenter', () => {
            button.style.filter = 'brightness(1.1)';
        });

        button.addEventListener('mouseleave', () => {
            button.style.filter = 'brightness(1)';
        });
    }

    // **拡張機能とコメントコンテナの検出**
    function detectCommentContainer() {
        return new Promise((resolve) => {
            let attempts = 0;
            const maxAttempts = 15;

            const detect = () => {
                attempts++;

                // 1. サイドバー拡張機能の検出
                const sidebarResult = detectSidebarExtension();
                if (sidebarResult.found) {
                    currentMode = 'sidebar';
                    targetContainer = sidebarResult.container;
                    scrollableElement = sidebarResult.scrollable;
                    console.log('サイドバーコメント拡張機能を検出:', sidebarResult.type);
                    resolve();
                    return;
                }

                // 2. 通常のYouTubeコメントセクション
                const normalComments = document.querySelector('ytd-comments#comments');
                if (normalComments && normalComments.offsetParent !== null) {
                    currentMode = 'normal';
                    targetContainer = normalComments;
                    scrollableElement = null; // windowスクロールを使用
                    console.log('通常のYouTubeコメントを検出');
                    resolve();
                    return;
                }

                if (attempts < maxAttempts) {
                    setTimeout(detect, 500);
                } else {
                    // フォールバック: 通常モード
                    currentMode = 'normal';
                    targetContainer = document;
                    scrollableElement = null;
                    console.log('検出タイムアウト。通常モードで動作します。');
                    resolve();
                }
            };

            detect();
        });
    }

    // **サイドバー拡張機能の検出**
    function detectSidebarExtension() {
        // パターン1: 固定位置のサイドバー
        const fixedElements = document.querySelectorAll('div[style*="position: fixed"]');
        for (const element of fixedElements) {
            if (element.style.right || element.style.left) {
                const commentIndicators = element.querySelectorAll([
                    'ytd-comment-thread-renderer',
                    'ytd-comment-renderer',
                    '[id*="comment"]',
                    '[class*="comment"]'
                ].join(','));

                if (commentIndicators.length > 2) {
                    const scrollable = findScrollableParent(element) || element;
                    return {
                        found: true,
                        container: element,
                        scrollable: scrollable,
                        type: 'fixed-sidebar'
                    };
                }
            }
        }

        // パターン2: iframe内のコメント
        const iframes = document.querySelectorAll('iframe');
        for (const iframe of iframes) {
            try {
                if (iframe.src && iframe.src.includes('youtube.com')) {
                    const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                    const comments = iframeDoc.querySelectorAll('ytd-comment-thread-renderer');
                    if (comments.length > 0) {
                        return {
                            found: true,
                            container: iframeDoc.body,
                            scrollable: iframeDoc.documentElement,
                            type: 'iframe-comments'
                        };
                    }
                }
            } catch (e) {
                // クロスオリジンの場合はスキップ
            }
        }

        // パターン3: Shadow DOM内のコメント
        const shadowHosts = document.querySelectorAll('*');
        for (const host of shadowHosts) {
            if (host.shadowRoot) {
                const shadowComments = host.shadowRoot.querySelectorAll([
                    'ytd-comment-thread-renderer',
                    '[id*="comment"]',
                    '[class*="comment"]'
                ].join(','));

                if (shadowComments.length > 2) {
                    return {
                        found: true,
                        container: host.shadowRoot,
                        scrollable: findScrollableInShadow(host.shadowRoot),
                        type: 'shadow-dom'
                    };
                }
            }
        }

        // パターン4: 特定のclass/idパターン
        const commonSelectors = [
            '[id*="sidebar"][id*="comment"]',
            '[class*="sidebar"][class*="comment"]',
            '[id*="comment"][id*="sidebar"]',
            '[class*="comment"][class*="sidebar"]',
            '[data-extension*="comment"]'
        ];

        for (const selector of commonSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
                const comments = element.querySelectorAll([
                    'ytd-comment-thread-renderer',
                    'ytd-comment-renderer',
                    '[class*="comment-text"]',
                    '[id*="comment-text"]'
                ].join(','));

                if (comments.length > 1) {
                    return {
                        found: true,
                        container: element,
                        scrollable: findScrollableParent(element) || element,
                        type: 'pattern-match'
                    };
                }
            }
        }

        return { found: false };
    }

    // **スクロール可能な親要素を探す**
    function findScrollableParent(element) {
        let current = element;
        while (current && current !== document.body) {
            const style = getComputedStyle(current);
            const hasScroll = current.scrollHeight > current.clientHeight;
            const isScrollable = ['auto', 'scroll'].includes(style.overflowY) ||
                               ['auto', 'scroll'].includes(style.overflow);

            if (hasScroll && isScrollable) {
                return current;
            }
            current = current.parentElement;
        }
        return null;
    }

    // **Shadow DOM内でスクロール可能要素を探す**
    function findScrollableInShadow(shadowRoot) {
        const elements = shadowRoot.querySelectorAll('*');
        for (const element of elements) {
            const style = getComputedStyle(element);
            const hasScroll = element.scrollHeight > element.clientHeight;
            const isScrollable = ['auto', 'scroll'].includes(style.overflowY);

            if (hasScroll && isScrollable) {
                return element;
            }
        }
        return shadowRoot.host;
    }

    // **コメント読み込み処理の実行**
    function executeCommentLoading() {
        if (!isOnWatchPage() || !targetContainer) return;

        try {
            // ボタンクリック処理
            clickLoadMoreButtons();
            if (CONFIG.AUTO_CLICK_REPLIES) {
                clickReplyButtons();
            }
            clickReadMoreButtons();

            // スクロール処理
            performScrolling();

        } catch (error) {
            console.log('コメント読み込み処理でエラー:', error);
        }
    }

    // **「さらに読み込む」系ボタンのクリック**
    function clickLoadMoreButtons() {
        const selectors = [
            'button',
            '[role="button"]',
            'tp-yt-paper-button',
            'ytd-continuation-item-renderer button',
            '#continuations button'
        ];

        let clickCount = 0;
        for (const selector of selectors) {
            if (clickCount >= CONFIG.MAX_CLICKS_PER_TICK) break;

            const buttons = targetContainer.querySelectorAll(selector);
            for (const button of buttons) {
                if (clickCount >= CONFIG.MAX_CLICKS_PER_TICK) break;

                const text = button.textContent?.toLowerCase() || '';
                const isLoadButton = text.includes('more') || text.includes('続き') ||
                                   text.includes('さらに') || text.includes('表示') ||
                                   text.includes('load') || text.includes('show') ||
                                   text.includes('コメント');

                if (isLoadButton && isElementClickable(button)) {
                    button.click();
                    clickCount++;
                }
            }
        }
    }

    // **返信ボタンのクリック**
    function clickReplyButtons() {
        const selectors = [
            'ytd-comment-replies-renderer button',
            '[id*="more-replies"] button',
            '[class*="reply"] button'
        ];

        let clickCount = 0;
        for (const selector of selectors) {
            if (clickCount >= CONFIG.MAX_CLICKS_PER_TICK) break;

            const buttons = targetContainer.querySelectorAll(selector);
            for (const button of buttons) {
                if (clickCount >= CONFIG.MAX_CLICKS_PER_TICK) break;

                const text = button.textContent?.toLowerCase() || '';
                if ((text.includes('reply') || text.includes('返信')) &&
                    isElementClickable(button)) {
                    button.click();
                    clickCount++;
                }
            }
        }
    }

    // **「続きを読む」ボタンのクリック**
    function clickReadMoreButtons() {
        const selectors = [
            '[id*="more"] button',
            '[class*="more"] button',
            'ytd-expander button'
        ];

        let clickCount = 0;
        for (const selector of selectors) {
            if (clickCount >= 2) break;

            const buttons = targetContainer.querySelectorAll(selector);
            for (const button of buttons) {
                if (clickCount >= 2) break;

                const text = button.textContent?.toLowerCase() || '';
                if ((text.includes('more') || text.includes('続き')) &&
                    isElementClickable(button)) {
                    button.click();
                    clickCount++;
                }
            }
        }
    }

    // **スクロール処理**
    function performScrolling() {
        if (scrollableElement && scrollableElement !== window) {
            // 特定要素のスクロール
            const current = scrollableElement.scrollTop;
            const max = scrollableElement.scrollHeight - scrollableElement.clientHeight;

            if (current < max - 100) {
                scrollableElement.scrollTop += CONFIG.SCROLL_STEP;
            } else {
                // 最下部で軽く上下に動かす
                scrollableElement.scrollTop = max;
                setTimeout(() => {
                    scrollableElement.scrollTop = Math.max(0, max - 100);
                    setTimeout(() => scrollableElement.scrollTop = max, 200);
                }, 300);
            }
        } else {
            // ウィンドウスクロール
            const current = document.documentElement.scrollTop;
            const max = document.documentElement.scrollHeight - window.innerHeight;

            if (current < max - 200) {
                window.scrollBy(0, CONFIG.SCROLL_STEP);
            } else {
                window.scrollTo(0, max);
                setTimeout(() => {
                    window.scrollBy(0, -100);
                    setTimeout(() => window.scrollTo(0, max), 200);
                }, 300);
            }
        }
    }

    // **要素がクリック可能かチェック**
    function isElementClickable(element) {
        if (!element || element.disabled || element.getAttribute('aria-disabled') === 'true') {
            return false;
        }

        const rect = element.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return false;

        return element.offsetParent !== null;
    }

    // **自動読み込み開始**
    async function startAutoLoader() {
        if (isRunning) return;

        if (currentMode === 'detecting') {
            updateStatus('検出中...');
            await detectCommentContainer();
            updateModeDisplay();
        }

        isRunning = true;
        GM_setValue('yt_auto_loader_state', true);
        updateStatus('実行中...');
        updateButtonStates();

        executeCommentLoading();
        timer = setInterval(executeCommentLoading, CONFIG.INTERVAL_MS);

        console.log(`コメント自動読み込み開始 (${currentMode}モード)`);
    }

    // **自動読み込み停止**
    function stopAutoLoader() {
        if (!isRunning) return;

        isRunning = false;
        GM_setValue('yt_auto_loader_state', false);

        if (timer) {
            clearInterval(timer);
            timer = null;
        }

        updateStatus('停止中');
        updateButtonStates();

        console.log('コメント自動読み込み停止');
    }

    // **モード表示の更新**
    function updateModeDisplay() {
        const modeElement = document.getElementById('yt-mode-display');
        if (modeElement) {
            let modeText = '';
            let color = '#4CAF50';

            switch (currentMode) {
                case 'detecting':
                    modeText = '🔍 検出中...';
                    color = '#FF9800';
                    break;
                case 'sidebar':
                    modeText = '📋 サイドバーモード';
                    color = '#4CAF50';
                    break;
                case 'normal':
                    modeText = '📺 通常モード';
                    color = '#2196F3';
                    break;
            }

            modeElement.textContent = modeText;
            modeElement.style.color = color;
            modeElement.style.background = `rgba(${color === '#4CAF50' ? '76, 175, 80' : color === '#FF9800' ? '255, 152, 0' : '33, 150, 243'}, 0.2)`;
            modeElement.style.borderColor = `rgba(${color === '#4CAF50' ? '76, 175, 80' : color === '#FF9800' ? '255, 152, 0' : '33, 150, 243'}, 0.3)`;
        }
    }

    // **ステータス表示の更新**
    function updateStatus(text) {
        const statusElement = document.getElementById('yt-status');
        if (statusElement) {
            statusElement.textContent = `ステータス: ${text}`;
        }
    }

    // **ボタン状態の更新**
    function updateButtonStates() {
        const startBtn = document.getElementById('yt-start-btn');
        const stopBtn = document.getElementById('yt-stop-btn');
        const redetectBtn = document.getElementById('yt-redetect-btn');

        if (startBtn && stopBtn) {
            const detecting = currentMode === 'detecting';

            startBtn.disabled = isRunning || detecting;
            stopBtn.disabled = !isRunning;

            startBtn.style.opacity = (isRunning || detecting) ? '0.5' : '1';
            stopBtn.style.opacity = !isRunning ? '0.5' : '1';
            startBtn.style.cursor = (isRunning || detecting) ? 'not-allowed' : 'pointer';
            stopBtn.style.cursor = !isRunning ? 'not-allowed' : 'pointer';
        }

        if (redetectBtn) {
            redetectBtn.disabled = isRunning;
            redetectBtn.style.opacity = isRunning ? '0.5' : '1';
        }
    }

    // **視聴ページかどうかの判定**
    function isOnWatchPage() {
        return location.pathname === '/watch' && location.search.includes('v=');
    }

    // **パネル表示の制御**
    function updatePanelVisibility() {
        if (controlPanel) {
            controlPanel.style.display = isOnWatchPage() ? 'block' : 'none';
        }
    }

    // **ページ遷移の監視**
    function monitorPageChanges() {
        setInterval(() => {
            if (location.href !== lastUrl) {
                lastUrl = location.href;
                console.log('ページ変更:', location.href);

                // 新しいページでは再検出
                currentMode = 'detecting';
                targetContainer = null;
                scrollableElement = null;
                updateModeDisplay();
                updatePanelVisibility();

                if (!isOnWatchPage() && isRunning) {
                    stopAutoLoader();
                } else if (isOnWatchPage()) {
                    setTimeout(() => {
                        detectCommentContainer().then(() => {
                            updateModeDisplay();
                            updateButtonStates();
                        });
                    }, 2000);
                }
            }
        }, 1000);
    }

    // **初期化処理**
    function initialize() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setTimeout(onReady, 1000);
            });
        } else {
            setTimeout(onReady, 1000);
        }
    }

    async function onReady() {
        createControlPanel();
        monitorPageChanges();
        updatePanelVisibility();

        if (isOnWatchPage()) {
            await detectCommentContainer();
            updateModeDisplay();
            updateButtonStates();

            // 前回の実行状態を復元
            if (GM_getValue('yt_auto_loader_state', false)) {
                startAutoLoader();
            }
        }
    }

    // スクリプト開始
    initialize();

})();