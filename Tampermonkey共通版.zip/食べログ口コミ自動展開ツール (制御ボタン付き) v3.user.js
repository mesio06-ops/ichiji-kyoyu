// ==UserScript==
// @name         食べログ口コミ自動展開ツール (制御ボタン付き) v3
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  食べログの口コミページで「もっと見る」ボタンを自動クリック。複数のページ構造に対応。スタート/ストップボタンで制御可能。
// @author       YourName
// @match        https://tabelog.com/*/dtlrvwlst/*
// @match        https://tabelog.com/*/dtlrvwlst
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    // === 設定 ===
    const CONFIG = {
        clickDelay: 200,        // ボタンクリック間隔（ミリ秒）
        scanInterval: 1500,     // 定期スキャン間隔（ミリ秒）
        initialDelay: 1000      // 初回実行までの遅延（ミリ秒）
    };

    // === 状態管理 ===
    let isActive = false;
    let scanTimer = null;
    let mutationObserver = null;
    let clickedCount = 0;
    const CLICKED_MARKER = 'data-tm-expanded';

    // === スタイル定義 ===
    GM_addStyle(`
        #tabelog-expander-panel {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border: 2px solid #d70035;
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-width: 240px;
            backdrop-filter: blur(10px);
        }

        #tabelog-expander-panel h3 {
            margin: 0 0 12px 0;
            color: #d70035;
            font-size: 16px;
            font-weight: 600;
            text-align: center;
            border-bottom: 1px solid #eee;
            padding-bottom: 8px;
        }

        .expander-controls {
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        }

        .expander-btn {
            flex: 1;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-start {
            background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
            color: white;
        }

        .btn-stop {
            background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%);
            color: white;
        }

        .expander-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }

        .expander-btn:active {
            transform: translateY(0);
        }

        .expander-status {
            text-align: center;
            font-size: 13px;
            padding: 8px 12px;
            border-radius: 6px;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .status-active {
            background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
            color: #2e7d32;
            border: 1px solid #4caf50;
        }

        .status-inactive {
            background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%);
            color: #c62828;
            border: 1px solid #f44336;
        }

        .expander-stats {
            font-size: 12px;
            color: #666;
            text-align: center;
            margin-top: 8px;
        }
    `);

    // === UI作成 ===
    function createControlPanel() {
        const panel = document.createElement('div');
        panel.id = 'tabelog-expander-panel';
        panel.innerHTML = `
            <h3>🔍 自動展開ツール</h3>
            <div id="expander-status" class="expander-status status-inactive">停止中</div>
            <div class="expander-controls">
                <button id="start-btn" class="expander-btn btn-start">開始</button>
                <button id="stop-btn" class="expander-btn btn-stop">停止</button>
            </div>
            <div id="expander-stats" class="expander-stats">展開済み: 0件</div>
        `;

        document.body.appendChild(panel);

        // イベントリスナー設定
        document.getElementById('start-btn').addEventListener('click', startExpansion);
        document.getElementById('stop-btn').addEventListener('click', stopExpansion);
    }

    // === 自動展開開始 ===
    function startExpansion() {
        if (isActive) return;

        isActive = true;
        updateUI();
        console.log('🚀 食べログ自動展開を開始しました');

        // 定期スキャンタイマー設定
        if (scanTimer) clearInterval(scanTimer);
        scanTimer = setInterval(performScan, CONFIG.scanInterval);

        // DOM変更監視設定
        setupMutationObserver();

        // 即座に1回実行
        performScan();
    }

    // === 自動展開停止 ===
    function stopExpansion() {
        if (!isActive) return;

        isActive = false;
        updateUI();
        console.log('⏹️ 食べログ自動展開を停止しました');

        // タイマー停止
        if (scanTimer) {
            clearInterval(scanTimer);
            scanTimer = null;
        }

        // オブザーバー停止
        if (mutationObserver) {
            mutationObserver.disconnect();
            mutationObserver = null;
        }
    }

    // === UI状態更新 ===
    function updateUI() {
        const statusEl = document.getElementById('expander-status');
        const statsEl = document.getElementById('expander-stats');

        if (statusEl) {
            statusEl.textContent = isActive ? '🟢 実行中' : '🔴 停止中';
            statusEl.className = `expander-status status-${isActive ? 'active' : 'inactive'}`;
        }

        if (statsEl) {
            statsEl.textContent = `展開済み: ${clickedCount}件`;
        }
    }

    // === DOM変更監視設定 ===
    function setupMutationObserver() {
        if (mutationObserver) mutationObserver.disconnect();

        mutationObserver = new MutationObserver((mutations) => {
            if (!isActive) return;

            const hasNewContent = mutations.some(mutation =>
                mutation.addedNodes && mutation.addedNodes.length > 0
            );

            if (hasNewContent) {
                setTimeout(performScan, 500);
            }
        });

        mutationObserver.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // === メインスキャン処理 ===
    function performScan() {
        if (!isActive) return;

        const reviewExpanded = expandReviewTexts();
        const photoExpanded = expandPhotoGalleries();

        const totalExpanded = reviewExpanded + photoExpanded;
        if (totalExpanded > 0) {
            clickedCount += totalExpanded;
            updateUI();
            console.log(`📝 展開完了: 口コミ${reviewExpanded}件, 写真${photoExpanded}件`);
        }
    }

    // === 口コミ本文展開（複数パターン対応） ===
    function expandReviewTexts() {
        // パターン1: 新しいHTML構造 (.js-show-review-item)
        const newButtons = document.querySelectorAll(`.rvw-showall-trigger.js-show-review-item:not([${CLICKED_MARKER}])`);

        // パターン2: 古いHTML構造 (.js-show-review-items)
        const oldButtons = document.querySelectorAll(`.rvw-showall-trigger.js-show-review-items:not([${CLICKED_MARKER}])`);

        // 両方のパターンを統合
        const allButtons = [...newButtons, ...oldButtons];

        allButtons.forEach((button, index) => {
            button.setAttribute(CLICKED_MARKER, 'true');
            setTimeout(() => {
                if (isActive) {
                    try {
                        button.click();
                        console.log('口コミ「もっと見る」をクリックしました');
                    } catch (e) {
                        console.warn('口コミ展開エラー:', e);
                    }
                }
            }, CONFIG.clickDelay * index);
        });

        return allButtons.length;
    }

    // === 写真ギャラリー展開（複数パターン対応） ===
    function expandPhotoGalleries() {
        let totalClicks = 0;

        // パターン1: 新しい構造 (.js-show-review-images)
        const newPhotoButtons = document.querySelectorAll(`.photo-showall-trigger.js-show-review-images:not([${CLICKED_MARKER}])`);
        const newThumbButtons = document.querySelectorAll(`.c-photo-more a.js-show-review-images:not([${CLICKED_MARKER}])`);

        // パターン2: 古い構造 (.js-show-bookmark-images)
        const oldPhotoButtons = document.querySelectorAll(`.photo-showall-trigger.js-show-bookmark-images:not([${CLICKED_MARKER}])`);
        const oldThumbButtons = document.querySelectorAll(`.c-photo-more a.js-show-bookmark-images:not([${CLICKED_MARKER}])`);

        // 全パターンを統合
        const allPhotoButtons = [...newPhotoButtons, ...oldPhotoButtons];
        const allThumbButtons = [...newThumbButtons, ...oldThumbButtons];

        let delayIndex = 0;

        // 写真展開ボタンをクリック
        allPhotoButtons.forEach((button) => {
            button.setAttribute(CLICKED_MARKER, 'true');
            setTimeout(() => {
                if (isActive) {
                    try {
                        button.click();
                        console.log('「写真をもっと見る」をクリックしました');
                    } catch (e) {
                        console.warn('写真展開エラー:', e);
                    }
                }
            }, CONFIG.clickDelay * delayIndex++);
        });

        // サムネイル展開ボタンをクリック
        allThumbButtons.forEach((button) => {
            button.setAttribute(CLICKED_MARKER, 'true');
            setTimeout(() => {
                if (isActive) {
                    try {
                        button.click();
                        console.log('サムネイル「さらに表示」をクリックしました');
                    } catch (e) {
                        console.warn('サムネイル展開エラー:', e);
                    }
                }
            }, CONFIG.clickDelay * delayIndex++);
        });

        return allPhotoButtons.length + allThumbButtons.length;
    }

    // === 初期化処理 ===
    function initialize() {
        console.log('🍽️ 食べログ自動展開ツールを初期化中...');

        // コントロールパネル作成
        createControlPanel();

        // ページ離脱時のクリーンアップ
        window.addEventListener('beforeunload', () => {
            stopExpansion();
        });

        console.log('✅ 初期化完了。右上のパネルから操作してください。');
    }

    // === 実行開始 ===
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(initialize, CONFIG.initialDelay);
        });
    } else {
        setTimeout(initialize, CONFIG.initialDelay);
    }

})();
