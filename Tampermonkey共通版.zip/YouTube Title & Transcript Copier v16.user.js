// ==UserScript==
// @name         YouTube Title & Transcript Copier v16
// @namespace    http://tampermonkey.net/
// @version      16.1
// @description  YouTubeのタイトル、文字起こし、要約用プロンプトをワンクリックでコピーして外部チャットを開く
// @author       Assistant
// @match        https://www.youtube.com/*
// @grant        GM_setClipboard
// @grant        GM_openInTab
// @grant        GM_xmlhttpRequest
// @connect      www.youtube.com
// @connect      youtube.com
// @run-at       document-start
// ==/UserScript==

(function () {
  'use strict';

  const EXTERNAL_CHAT_URL = 'https://www.genspark.ai/agents?type=ai_chat';

  const SUMMARY_PROMPT = `以下のタイトルの記事、または動画の文字起こし、または、そのコメント集をすべて、網羅的かつ構造的に日本語で要約してください。
内容は絶対に省かないようにしてください。
日本人の中学生でもわかる英単語はそのままカタカナで、中学生にはわからない英単語はカタカナではなく、自然な日本語に翻訳してしてください。
not A but B構文は使わないでください。原文に含まれていた場合はAの部分をカットしてください。

■タイトル
{{TITLE}}

■文字起こし
{{TRANSCRIPT}}`;

  const style = document.createElement('style');
  style.textContent = `
    #yt-copier-panel {
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 99999;
      display: flex;
      flex-direction: column;
      gap: 8px;
      font-family: "YouTube Sans","Roboto",Arial,sans-serif;
    }
    .ytc-btn {
      display: flex; align-items: center; gap: 8px;
      padding: 9px 16px; border: none; border-radius: 24px;
      font-size: 13px; font-weight: 600; cursor: pointer; color: #fff;
      transition: transform .12s, box-shadow .2s, background .25s;
      box-shadow: 0 2px 8px rgba(0,0,0,.25); white-space: nowrap;
    }
    .ytc-btn:hover  { transform: scale(1.04); box-shadow: 0 4px 14px rgba(0,0,0,.35); }
    .ytc-btn:active { transform: scale(.97); }
    .ytc-btn:disabled { cursor: wait; opacity: .8; }
    .ytc-btn.title  { background: #065fd4; }
    .ytc-btn.trans  { background: #c00; }
    .ytc-btn.prompt { background: #7b1fa2; }
    .ytc-btn.ok     { background: #2e7d32 !important; }
    .ytc-btn.err    { background: #b71c1c !important; }
    .ytc-btn svg    { width: 16px; height: 16px; fill: #fff; flex-shrink: 0; }
  `;

  function addStyle() {
    if (!document.head) {
      document.addEventListener('DOMContentLoaded', () => document.head.appendChild(style));
    } else {
      document.head.appendChild(style);
    }
  }
  addStyle();

  const SVG_NS = 'http://www.w3.org/2000/svg';
  function makeCopyIcon() {
    const s = document.createElementNS(SVG_NS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    const p = document.createElementNS(SVG_NS, 'path');
    p.setAttribute('d', 'M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z');
    s.appendChild(p);
    return s;
  }

  function makeCheckIcon() {
    const s = document.createElementNS(SVG_NS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24');
    const p = document.createElementNS(SVG_NS, 'path');
    p.setAttribute('d', 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z');
    s.appendChild(p);
    return s;
  }

  function setBtn(button, icon, text) {
    while (button.firstChild) button.removeChild(button.firstChild);
    button.appendChild(icon);
    const span = document.createElement('span');
    span.textContent = text;
    button.appendChild(span);
  }

  function flashOk(button, normalClass, normalText) {
    button.className = 'ytc-btn ok';
    setBtn(button, makeCheckIcon(), 'コピー完了！');
    setTimeout(() => {
      button.className = 'ytc-btn ' + normalClass;
      setBtn(button, makeCopyIcon(), normalText);
    }, 1800);
  }

  function flashErr(button, normalClass, normalText, message) {
    button.className = 'ytc-btn err';
    setBtn(button, makeCopyIcon(), message || 'エラー');
    setTimeout(() => {
      button.className = 'ytc-btn ' + normalClass;
      setBtn(button, makeCopyIcon(), normalText);
    }, 2500);
  }

  function getVideoTitle() {
    const element = document.querySelector('h1.ytd-watch-metadata yt-formatted-string')
      || document.querySelector('#title h1 yt-formatted-string')
      || document.querySelector('#title h1');
    return element
      ? element.textContent.trim()
      : document.title.replace(/ - YouTube$/, '').trim();
  }

  function buildSummaryPrompt(title, transcript) {
    return SUMMARY_PROMPT
      .replace('{{TITLE}}', title)
      .replace('{{TRANSCRIPT}}', transcript);
  }

  function createButton(className, text) {
    const button = document.createElement('button');
    button.className = 'ytc-btn ' + className;
    setBtn(button, makeCopyIcon(), text);
    return button;
  }

  function createPanel() {
    if (document.getElementById('yt-copier-panel')) return;
    if (!document.body) return;

    const panel = document.createElement('div');
    panel.id = 'yt-copier-panel';

    const promptText = '要約プロンプトをコピー';
    const promptButton = createButton('prompt', promptText);
    promptButton.addEventListener('click', async () => {
      const title = getVideoTitle();
      if (!title) {
        flashErr(promptButton, 'prompt', promptText, 'タイトル未検出');
        return;
      }

      setBtn(promptButton, makeCopyIcon(), '字幕を取得中…');
      promptButton.disabled = true;
      try {
        const transcript = await getTranscript();
        if (!transcript) throw '字幕なし';
        GM_setClipboard(buildSummaryPrompt(title, transcript), 'text');
        flashOk(promptButton, 'prompt', promptText);
        GM_openInTab(EXTERNAL_CHAT_URL, {
          active: true,
          insert: true,
          setParent: true
        });
      } catch (error) {
        console.error('[YT Copier]', error);
        flashErr(
          promptButton,
          'prompt',
          promptText,
          typeof error === 'string' ? error : '取得失敗'
        );
      } finally {
        promptButton.disabled = false;
      }
    });

    const titleText = 'タイトルをコピー';
    const titleButton = createButton('title', titleText);
    titleButton.addEventListener('click', () => {
      const title = getVideoTitle();
      if (!title) {
        flashErr(titleButton, 'title', titleText, 'タイトル未検出');
        return;
      }
      GM_setClipboard(title, 'text');
      flashOk(titleButton, 'title', titleText);
    });

    const transcriptText = '文字起こしをコピー';
    const transcriptButton = createButton('trans', transcriptText);
    transcriptButton.addEventListener('click', async () => {
      setBtn(transcriptButton, makeCopyIcon(), '取得中…');
      transcriptButton.disabled = true;
      try {
        const transcript = await getTranscript();
        if (!transcript) throw '字幕なし';
        GM_setClipboard(transcript, 'text');
        flashOk(transcriptButton, 'trans', transcriptText);
      } catch (error) {
        console.error('[YT Copier]', error);
        flashErr(
          transcriptButton,
          'trans',
          transcriptText,
          typeof error === 'string' ? error : '取得失敗'
        );
      } finally {
        transcriptButton.disabled = false;
      }
    });

    panel.appendChild(promptButton);
    panel.appendChild(titleButton);
    panel.appendChild(transcriptButton);
    document.body.appendChild(panel);
  }

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

  function isTimestamp(text) {
    if (/^\d{1,2}:\d{2}(:\d{2})?$/.test(text)) return true;
    if (/^\d+\s*秒$/.test(text)) return true;
    if (/^\d+\s*分(\s*\d+\s*秒)?$/.test(text)) return true;
    if (/^\d+\s*時間(\s*\d+\s*分)?(\s*\d+\s*秒)?$/.test(text)) return true;
    return false;
  }

  function getTranscriptSegments() {
    const lines = [];

    const panels = document.querySelectorAll('ytd-engagement-panel-section-list-renderer');
    for (const panel of panels) {
      if (panel.getAttribute('visibility') !== 'ENGAGEMENT_PANEL_VISIBILITY_EXPANDED') continue;
      const text = panel.innerText || '';
      if (!text.includes('文字起こし') && !text.includes('Transcript')) continue;
      const rawLines = text.split('\n');
      const skipRe = /^(文字音声変換を検索|チャプター.*|動画の関連情報|文字起こし|Transcript)$/;
      for (const raw of rawLines) {
        const textLine = raw.trim();
        if (!textLine) continue;
        if (isTimestamp(textLine)) continue;
        if (skipRe.test(textLine)) continue;
        lines.push(textLine);
      }
      if (lines.length > 0) return lines;
    }

    const modernPanel = document.querySelector(
      'ytd-engagement-panel-section-list-renderer[target-id="PAmodern_transcript_view"]'
    );
    if (modernPanel && modernPanel.getAttribute('visibility') !== 'ENGAGEMENT_PANEL_VISIBILITY_HIDDEN') {
      modernPanel.querySelectorAll('transcript-segment-view-model span.ytAttributedStringHost').forEach(span => {
        const text = (span.textContent || '').trim();
        if (text) lines.push(text);
      });
      if (lines.length > 0) return lines;
    }

    const oldPanel = document.querySelector(
      'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-searchable-transcript"]'
    );
    if (oldPanel && oldPanel.getAttribute('visibility') !== 'ENGAGEMENT_PANEL_VISIBILITY_HIDDEN') {
      oldPanel.querySelectorAll('transcript-segment-view-model span.yt-core-attributed-string').forEach(span => {
        const text = (span.textContent || '').trim();
        if (text) lines.push(text);
      });
      if (lines.length > 0) return lines;

      oldPanel.querySelectorAll(
        'ytd-transcript-segment-renderer .segment-text, yt-formatted-string.segment-text'
      ).forEach(span => {
        const text = (span.textContent || '').trim();
        if (text) lines.push(text);
      });
    }

    return lines;
  }

  function closeTranscriptPanel() {
    try {
      const panels = document.querySelectorAll('ytd-engagement-panel-section-list-renderer');
      for (const panel of panels) {
        if (panel.getAttribute('visibility') !== 'ENGAGEMENT_PANEL_VISIBILITY_EXPANDED') continue;
        const text = panel.innerText || '';
        if (!text.includes('文字起こし') && !text.includes('Transcript')) continue;
        const closeButton = panel.querySelector('#visibility-button button')
          || panel.querySelector('button[aria-label="閉じる"]')
          || panel.querySelector('button[aria-label="Close"]');
        if (closeButton) closeButton.click();
      }
    } catch (error) {
      console.debug('[YT Copier] 文字起こしパネルを閉じられませんでした', error);
    }
  }

  async function fetchViaDom() {
    let segments = getTranscriptSegments();
    if (segments.length >= 3) return segments.join('\n');

    const descriptionExpand = document.querySelector('#description-inline-expander #expand')
      || document.querySelector('tp-yt-paper-button#expand')
      || document.querySelector('#snippet #expand');
    if (descriptionExpand && descriptionExpand.offsetParent !== null) {
      descriptionExpand.click();
      await sleep(1000);
    }

    let clicked = false;
    const keywords = ['文字起こし', 'transcript'];
    const allClickable = document.querySelectorAll(
      'ytd-button-renderer, button, tp-yt-paper-button, [role="button"], yt-button-view-model, a'
    );
    for (const element of allClickable) {
      const text = (element.textContent || '').trim().toLowerCase();
      if (keywords.some(keyword => text.includes(keyword)) && text.length < 60) {
        (element.querySelector('button') || element.querySelector('a') || element).click();
        clicked = true;
        break;
      }
    }

    if (!clicked) {
      const ariaButton = document.querySelector('[aria-label*="文字起こし"]')
        || document.querySelector('[aria-label*="transcript" i]');
      if (ariaButton) {
        ariaButton.click();
        clicked = true;
      }
    }
    if (!clicked) return null;

    for (let i = 0; i < 30; i++) {
      await sleep(400);
      segments = getTranscriptSegments();
      if (segments.length >= 3) {
        closeTranscriptPanel();
        return segments.join('\n');
      }
    }

    if (segments.length > 0) {
      closeTranscriptPanel();
      return segments.join('\n');
    }
    return null;
  }

  async function getTranscript() {
    const result = await fetchViaDom();
    if (result) return result;
    throw '字幕を取得できませんでした';
  }

  function onNav() {
    const panel = document.getElementById('yt-copier-panel');
    if (location.pathname === '/watch') {
      if (!panel) createPanel();
      else panel.style.display = 'flex';
    } else if (panel) {
      panel.style.display = 'none';
    }
  }

  document.addEventListener('yt-navigate-finish', onNav);
  document.addEventListener('yt-page-data-updated', onNav);
  window.addEventListener('popstate', onNav);

  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      onNav();
    }
  }, 500);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(onNav, 500));
  } else {
    setTimeout(onNav, 500);
  }
  setTimeout(onNav, 1500);
  setTimeout(onNav, 3000);
})();
