// ==UserScript==
// @name         Togetter ページジャンプ
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Togetterのページネーション「1 2 次へ」までジャンプするボタンを追加
// @author       You
// @match        https://togetter.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ページネーションを探す関数
    function findPagination() {
        // Togetterのページネーション要素を探す
        const paginationSelectors = [
            '.pagenation',
            '.pagination',
            '[class*="pager"]',
            '[class*="pagination"]'
        ];

        for (let selector of paginationSelectors) {
            const element = document.querySelector(selector);
            if (element) {
                return element;
            }
        }

        // テキストベースで探す（「次へ」を含む要素）
        const allLinks = document.querySelectorAll('a');
        for (let link of allLinks) {
            if (link.textContent.includes('次へ') || link.textContent.includes('次のページ')) {
                return link.closest('div, nav, ul');
            }
        }

        return null;
    }

    // ジャンプボタンを作成
    function createJumpButton() {
        const button = document.createElement('button');
        button.textContent = '📋 ページネーションへジャンプ';
        button.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            padding: 12px 20px;
            background-color: #1da1f2;
            color: white;
            border: none;
            border-radius: 25px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0,0,0,0.3);
            transition: all 0.3s ease;
        `;

        // ホバー効果
        button.addEventListener('mouseenter', () => {
            button.style.backgroundColor = '#1a8cd8';
            button.style.transform = 'scale(1.05)';
        });

        button.addEventListener('mouseleave', () => {
            button.style.backgroundColor = '#1da1f2';
            button.style.transform = 'scale(1)';
        });

        // クリックイベント
        button.addEventListener('click', () => {
            const pagination = findPagination();
            if (pagination) {
                pagination.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
                // スクロール後にハイライト効果
                pagination.style.transition = 'background-color 0.5s';
                pagination.style.backgroundColor = '#fff3cd';
                setTimeout(() => {
                    pagination.style.backgroundColor = '';
                }, 1500);
            } else {
                alert('ページネーションが見つかりませんでした');
            }
        });

        document.body.appendChild(button);
    }

    // ページ読み込み後に実行
    function init() {
        // DOM読み込み完了を待つ
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', createJumpButton);
        } else {
            createJumpButton();
        }

        // 動的コンテンツ対応（必要に応じて）
        const observer = new MutationObserver(() => {
            const existingButton = document.querySelector('button[style*="position: fixed"]');
            if (!existingButton && findPagination()) {
                createJumpButton();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    init();
})();