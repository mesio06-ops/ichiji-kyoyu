// ==UserScript==
// @name         食べログ Auto Expand Review List (Manual Control)
// @namespace    https://example.com/
// @version      2.0
// @description  口コミリスト展開の手動制御機能付き
// @match        https://tabelog.com/*/dtlrvwlst/*
// @run-at       document-end
// @noframes
// ==/UserScript==

(function () {
  'use strict';

  let isRunning = false;
  let intervalId = null;
  let mutationObserver = null;

  // コントロールパネルの作成
  function createControlPanel() {
    const panel = document.createElement('div');
    panel.id = 'review-expander-control';
    panel.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 10000;
      background: #fff;
      border: 2px solid #007bff;
      border-radius: 8px;
      padding: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      font-family: Arial, sans-serif;
      min-width: 200px;
    `;

    const title = document.createElement('div');
    title.textContent = '口コミ展開コントロール';
    title.style.cssText = `
      font-weight: bold;
      margin-bottom: 10px;
      color: #333;
      text-align: center;
    `;

    const startBtn = document.createElement('button');
    startBtn.textContent = 'スタート';
    startBtn.style.cssText = `
      background: #28a745;
      color: white;
      border: none;
      padding: 8px 16px;
      margin: 5px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    `;

    const stopBtn = document.createElement('button');
    stopBtn.textContent = 'ストップ';
    stopBtn.style.cssText = `
      background: #dc3545;
      color: white;
      border: none;
      padding: 8px 16px;
      margin: 5px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
    `;

    const statusDiv = document.createElement('div');
    statusDiv.id = 'expander-status';
    statusDiv.textContent = '停止中';
    statusDiv.style.cssText = `
      text-align: center;
      margin-top: 10px;
      padding: 5px;
      border-radius: 4px;
      background: #f8f9fa;
      color: #666;
    `;

    // イベントリスナーの設定
    startBtn.addEventListener('click', startExpansion);
    stopBtn.addEventListener('click', stopExpansion);

    panel.appendChild(title);
    panel.appendChild(startBtn);
    panel.appendChild(stopBtn);
    panel.appendChild(statusDiv);

    document.body.appendChild(panel);
  }

  // 展開処理の開始
  function startExpansion() {
    if (isRunning) return;

    isRunning = true;
    updateStatus('実行中', '#28a745');

    // Page-context に注入
    injectIntoPageContext(pageContextMain);

    // Native fallback も開始
    startNativeFallback();
  }

  // 展開処理の停止
  function stopExpansion() {
    if (!isRunning) return;

    isRunning = false;
    updateStatus('停止中', '#dc3545');

    // インターバルとオブザーバーをクリア
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }

    // Page-contextでも停止処理を実行
    injectStopCommand();
  }

  // ステータス表示の更新
  function updateStatus(text, color) {
    const statusDiv = document.getElementById('expander-status');
    if (statusDiv) {
      statusDiv.textContent = text;
      statusDiv.style.color = color;
    }
  }

  // Page-context への注入
  function injectIntoPageContext(fn) {
    const s = document.createElement('script');
    s.textContent = `;(${fn})();`;
    (document.head || document.documentElement).appendChild(s);
    s.remove();
  }

  // 停止コマンドの注入
  function injectStopCommand() {
    const stopScript = `
      if (window.reviewExpanderInterval) {
        clearInterval(window.reviewExpanderInterval);
        window.reviewExpanderInterval = null;
      }
      if (window.reviewExpanderObserver) {
        window.reviewExpanderObserver.disconnect();
        window.reviewExpanderObserver = null;
      }
    `;
    const s = document.createElement('script');
    s.textContent = stopScript;
    (document.head || document.documentElement).appendChild(s);
    s.remove();
  }

  // Page-context でのメイン処理
  function pageContextMain() {
    // 既存の処理をクリア
    if (window.reviewExpanderInterval) {
      clearInterval(window.reviewExpanderInterval);
    }
    if (window.reviewExpanderObserver) {
      window.reviewExpanderObserver.disconnect();
    }

    (function waitForjQuery() {
      if (window.jQuery) {
        const $ = window.jQuery;

        const clickAll = () => {
          $('.rvw-showall-trigger.js-show-review-items:visible').each(function () {
            try { $(this).trigger('click'); } catch (e) {}
          });
          $('.rvw-showall-trigger__target:visible').each(function () {
            const p = this.closest('.rvw-showall-trigger');
            if (p) { try { $(p).trigger('click'); } catch (e) {} }
          });
        };

        setTimeout(clickAll, 800);

        window.reviewExpanderObserver = new MutationObserver(() => clickAll());
        window.reviewExpanderObserver.observe(document.body, { childList: true, subtree: true });

        window.reviewExpanderInterval = setInterval(clickAll, 1500);
      } else {
        setTimeout(waitForjQuery, 500);
      }
    })();
  }

  // Native fallback の開始
  function startNativeFallback() {
    function forceUserClick(el) {
      if (!el) return;
      const r = el.getBoundingClientRect();
      const x = r.left + r.width / 2, y = r.top + r.height / 2;
      ['pointerdown','mousedown','mouseup','click'].forEach(type => {
        try {
          el.dispatchEvent(new MouseEvent(type, {
            bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0
          }));
        } catch {}
      });
    }

    const clickAll = () => {
      if (!isRunning) return; // 停止中は処理しない

      const targets = document.querySelectorAll(
        '.rvw-showall-trigger.js-show-review-items, .rvw-showall-trigger__target'
      );
      targets.forEach(el => {
        if (el && el.offsetParent !== null) {
          const t = el.classList && el.classList.contains('rvw-showall-trigger__target')
            ? el.closest('.rvw-showall-trigger') || el
            : el;
          forceUserClick(t);
        }
      });
    };

    setTimeout(clickAll, 900);

    mutationObserver = new MutationObserver(() => {
      if (isRunning) clickAll();
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });

    intervalId = setInterval(() => {
      if (isRunning) clickAll();
    }, 1800);
  }

  // 初期化
  function init() {
    // ページ読み込み完了を待つ
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', createControlPanel);
    } else {
      setTimeout(createControlPanel, 500);
    }
  }

  init();
})();