// ==UserScript==
// @name         Google Cloud TTS Voice List Paginator Enhanced
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Google Cloud Text-to-Speechのドキュメントページを最適化したページ分割表示
// @match        https://docs.cloud.google.com/text-to-speech/docs/list-voices-and-types*
// @match        https://cloud.google.com/text-to-speech/docs/list-voices-and-types*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // === 設定 ===
    const ROWS_PER_PAGE = 50; // 1ページあたりの表示行数

    // === 初期化 ===
    function waitForContent() {
        return new Promise((resolve) => {
            const checkInterval = setInterval(() => {
                const tables = document.querySelectorAll('table tbody tr');
                if (tables.length > 0) {
                    clearInterval(checkInterval);
                    setTimeout(resolve, 500); // Google Docsの動的読み込み対応
                }
            }, 100);
        });
    }

    async function initPaginator() {
        await waitForContent();

        // 最も行数の多いテーブルを自動検出
        const tables = document.querySelectorAll('table');
        if (tables.length === 0) return;

        let targetTable = null;
        let maxRows = 0;

        tables.forEach(table => {
            const rowCount = table.querySelectorAll('tbody tr').length;
            if (rowCount > maxRows) {
                maxRows = rowCount;
                targetTable = table;
            }
        });

        // 分割が必要ない場合は終了
        if (!targetTable || maxRows <= ROWS_PER_PAGE) {
            console.log('ページ分割が不要です（行数が少なすぎます）');
            return;
        }

        console.log(`対象テーブル検出: ${maxRows}行のテーブルを分割します`);

        // === 変数初期化 ===
        const rows = Array.from(targetTable.querySelectorAll('tbody tr'));
        const totalPages = Math.ceil(rows.length / ROWS_PER_PAGE);
        let currentPage = 1;

        // === UI作成 ===
        const controller = createController();
        document.body.appendChild(controller);

        // === 機能実装 ===
        function showPage(page) {
            if (page < 1 || page > totalPages) return;

            currentPage = page;
            const startIdx = (page - 1) * ROWS_PER_PAGE;
            const endIdx = startIdx + ROWS_PER_PAGE;

            // テーブル行の表示/非表示切り替え
            rows.forEach((row, idx) => {
                row.style.display = (idx >= startIdx && idx < endIdx) ? '' : 'none';
            });

            updateController();
            scrollToTable();
        }

        function scrollToTable() {
            const headerOffset = 80;
            const elementPosition = targetTable.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
            window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
        }

        function updateController() {
            const pageInfo = document.getElementById('tts-page-info');
            const prevBtn = document.getElementById('tts-prev-btn');
            const nextBtn = document.getElementById('tts-next-btn');
            const jumpInput = document.getElementById('tts-jump-input');

            if (pageInfo) {
                const startItem = (currentPage - 1) * ROWS_PER_PAGE + 1;
                const endItem = Math.min(currentPage * ROWS_PER_PAGE, rows.length);
                pageInfo.textContent = `${currentPage} / ${totalPages} ページ (${startItem}-${endItem}/${rows.length}件)`;
            }

            if (prevBtn) {
                prevBtn.disabled = currentPage === 1;
                prevBtn.style.opacity = currentPage === 1 ? '0.5' : '1';
            }

            if (nextBtn) {
                nextBtn.disabled = currentPage === totalPages;
                nextBtn.style.opacity = currentPage === totalPages ? '0.5' : '1';
            }

            if (jumpInput) {
                jumpInput.value = currentPage.toString();
            }
        }

        function createController() {
            const controller = document.createElement('div');
            controller.style.cssText = `
                position: fixed;
                bottom: 30px;
                right: 30px;
                z-index: 999999;
                background: linear-gradient(135deg, #4285f4 0%, #1a73e8 100%);
                color: white;
                padding: 20px 24px;
                border-radius: 16px;
                box-shadow: 0 8px 32px rgba(0,0,0,0.3);
                display: flex;
                flex-direction: column;
                gap: 16px;
                font-family: 'Google Sans', 'Roboto', Arial, sans-serif;
                font-size: 14px;
                min-width: 280px;
                backdrop-filter: blur(10px);
            `;

            // ページ情報表示
            const pageInfo = document.createElement('div');
            pageInfo.id = 'tts-page-info';
            pageInfo.style.cssText = `
                text-align: center;
                font-size: 16px;
                font-weight: 500;
                line-height: 1.4;
            `;

            // ボタンコンテナ
            const buttonContainer = document.createElement('div');
            buttonContainer.style.cssText = `
                display: flex;
                gap: 12px;
            `;

            // 前へボタン
            const prevBtn = document.createElement('button');
            prevBtn.id = 'tts-prev-btn';
            prevBtn.innerHTML = '◀ 前へ';
            prevBtn.style.cssText = `
                flex: 1;
                padding: 10px 16px;
                cursor: pointer;
                border: none;
                border-radius: 8px;
                background: rgba(255,255,255,0.2);
                color: white;
                font-weight: 500;
                font-size: 14px;
                transition: all 0.2s ease;
            `;
            prevBtn.addEventListener('mouseover', () => {
                prevBtn.style.background = 'rgba(255,255,255,0.3)';
            });
            prevBtn.addEventListener('mouseout', () => {
                prevBtn.style.background = 'rgba(255,255,255,0.2)';
            });
            prevBtn.onclick = () => showPage(currentPage - 1);

            // 次へボタン
            const nextBtn = document.createElement('button');
            nextBtn.id = 'tts-next-btn';
            nextBtn.innerHTML = '次へ ▶';
            nextBtn.style.cssText = prevBtn.style.cssText;
            nextBtn.addEventListener('mouseover', () => {
                nextBtn.style.background = 'rgba(255,255,255,0.3)';
            });
            nextBtn.addEventListener('mouseout', () => {
                nextBtn.style.background = 'rgba(255,255,255,0.2)';
            });
            nextBtn.onclick = () => showPage(currentPage + 1);

            // ページジャンプ機能
            const jumpContainer = document.createElement('div');
            jumpContainer.style.cssText = `
                display: flex;
                gap: 8px;
                align-items: center;
                justify-content: center;
            `;

            const jumpLabel = document.createElement('span');
            jumpLabel.textContent = 'ページ:';
            jumpLabel.style.fontSize = '13px';

            const jumpInput = document.createElement('input');
            jumpInput.id = 'tts-jump-input';
            jumpInput.type = 'number';
            jumpInput.min = '1';
            jumpInput.max = totalPages.toString();
            jumpInput.value = '1';
            jumpInput.style.cssText = `
                width: 60px;
                padding: 6px 8px;
                border: none;
                border-radius: 6px;
                text-align: center;
                font-size: 14px;
                background: rgba(255,255,255,0.9);
            `;
            jumpInput.addEventListener('change', () => {
                const page = parseInt(jumpInput.value);
                if (page >= 1 && page <= totalPages) {
                    showPage(page);
                }
            });
            jumpInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    const page = parseInt(jumpInput.value);
                    if (page >= 1 && page <= totalPages) {
                        showPage(page);
                    }
                }
            });

            // ショートカットヒント
            const hint = document.createElement('div');
            hint.style.cssText = `
                text-align: center;
                font-size: 11px;
                opacity: 0.8;
                padding-top: 12px;
                border-top: 1px solid rgba(255,255,255,0.2);
                line-height: 1.4;
            `;
            hint.innerHTML = `
                <div>← → キー: ページ移動</div>
                <div>Home/End: 最初/最後のページ</div>
            `;

            // 組み立て
            buttonContainer.appendChild(prevBtn);
            buttonContainer.appendChild(nextBtn);

            jumpContainer.appendChild(jumpLabel);
            jumpContainer.appendChild(jumpInput);

            controller.appendChild(pageInfo);
            controller.appendChild(buttonContainer);
            controller.appendChild(jumpContainer);
            controller.appendChild(hint);

            return controller;
        }

        // === キーボードショートカット ===
        document.addEventListener('keydown', (e) => {
            // 入力フィールドにフォーカスがある場合は無視
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                return;
            }

            switch(e.key) {
                case 'ArrowRight':
                case 'PageDown':
                    e.preventDefault();
                    showPage(currentPage + 1);
                    break;
                case 'ArrowLeft':
                case 'PageUp':
                    e.preventDefault();
                    showPage(currentPage - 1);
                    break;
                case 'Home':
                    e.preventDefault();
                    showPage(1);
                    break;
                case 'End':
                    e.preventDefault();
                    showPage(totalPages);
                    break;
            }
        });

        // 初期表示
        showPage(1);
    }

    // === 実行 ===
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPaginator);
    } else {
        initPaginator();
    }
})();