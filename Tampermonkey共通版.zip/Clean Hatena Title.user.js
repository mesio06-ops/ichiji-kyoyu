// ==UserScript==
// @name         Clean Hatena Title
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Remove [B! category] from document title
// @author       You
// @match        *://b.hatena.ne.jp/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    console.log('スクリプト起動確認');

    const cleanTitle = () => {
        const before = document.title;
        document.title = document.title.replace(/^\[B! .*?\]\s*/, '');
        console.log('変更前:', before, '変更後:', document.title);
    };

    cleanTitle();

    // タイトル変更を監視
    new MutationObserver(cleanTitle).observe(
        document.querySelector('title'),
        { childList: true }
    );
})();