// ==UserScript==
// @name         2ch.sc コメントコピー
// @namespace    https://2ch.sc/
// @version      1.1.0
// @description  2ch.scのAA・重複投稿を除外し、レスを親レスごとに並べ替えてコピーまたはMarkdown保存します。
// @author       Codex
// @match        https://2ch.sc/test/read.cgi/*
// @match        https://*.2ch.sc/test/read.cgi/*
// @match        http://2ch.sc/test/read.cgi/*
// @match        http://*.2ch.sc/test/read.cgi/*
// @grant        GM_setClipboard
// @grant        unsafeWindow
// @run-at       document-idle
// ==/UserScript==

(() => {
  'use strict';

  const BUTTON_ID = 'tm-2ch-sc-comment-copy';
  const SAVE_BUTTON_ID = 'tm-2ch-sc-comment-save';
  const DIALOG_ID = 'tm-2ch-sc-save-dialog';
  const NORMAL_LABEL = 'コメントをコピー';
  const SAVE_LABEL = 'コメントを保存';

  /**
   * 本文内の <br> を改行へ変換し、見た目を保ちながら余分な空白を整える。
   * リンクは 画面上の表示文字列をコピーする。
   */
  function extractBody(contentElement) {
    const clone = contentElement.cloneNode(true);

    clone.querySelectorAll('br').forEach((br) => br.replaceWith('\n'));

    return (clone.textContent || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[ \t]+\n/g, '\n')
      .replace(/\n[ \t]+/g, '\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function extractAnchorNumbers(contentElement) {
    const numbers = [];

    // 2ch.scのアンカーと、リンク化されていないアンカーを本文から読み取る。
    for (const match of extractBody(contentElement).matchAll(/>>\s*(\d+)/g)) {
      numbers.push(String(Number(match[1])));
    }

    return [...new Set(numbers)];
  }

  function readComments() {
    const comments = [];
    const seenNumbers = new Set();

    // 2ch.scの通常表示は、dtがレス見出し、直後のddが本文になる。
    document.querySelectorAll('dl > dt').forEach((header) => {
      const headerText = header.textContent || '';
      const numberMatch = headerText.match(/^\s*(\d+)(?=\s|[:：])/);
      if (!numberMatch) return;

      const number = String(Number(numberMatch[1]));
      if (number === '0' || seenNumbers.has(number)) return;

      let content = header.nextElementSibling;
      while (content && content.tagName !== 'DD') {
        if (content.tagName === 'DT') return;
        content = content.nextElementSibling;
      }
      if (!content) return;

      // スレッド終了の案内を除外する。1000番以降の通常レスも取得する。
      if (/Over\s+\d+\s+Thread|[\d,]+\s*KB\s*Over|スレッドストッパー|停止しました。。。|うふ～ん/i.test(headerText)) {
        return;
      }

      seenNumbers.add(number);
      comments.push({
        number,
        body: extractBody(content),
        anchorNumbers: extractAnchorNumbers(content),
      });
    });

    return comments;
  }

  /**
   * 元のレス順を保ちつつ、アンカー付きレスを親レスの直後へまとめる。
   * 返信への返信も再帰的にたどるため、会話単位の深さ優先順になる。
   */
  function orderComments(comments) {
    const commentNumbers = new Set(comments.map((comment) => comment.number));
    const childrenByParent = new Map();
    const roots = [];

    comments.forEach((comment) => {
      // 複数アンカー時は、現在表示されているレスを指す最初のものを親にする。
      const parentNumber = comment.anchorNumbers.find(
        (number) => number !== comment.number && commentNumbers.has(number),
      );

      if (!parentNumber) {
        roots.push(comment);
        return;
      }

      if (!childrenByParent.has(parentNumber)) {
        childrenByParent.set(parentNumber, []);
      }
      childrenByParent.get(parentNumber).push(comment);
    });

    const ordered = [];
    const visited = new Set();

    function appendTree(comment) {
      if (visited.has(comment.number)) return;

      visited.add(comment.number);
      ordered.push(comment);
      (childrenByParent.get(comment.number) || []).forEach(appendTree);
    }

    roots.forEach(appendTree);

    // 前方アンカーの循環など、通常は発生しない場合でもレスを欠落させない。
    comments.forEach(appendTree);
    return ordered;
  }

  /**
   * 記号が多い行が複数続く投稿をAAとして扱う。1行の顔文字は残す。
   */
  function isAsciiArt(body) {
    const lines = body.split('\n')
      .map((line) => line.trim())
      .filter((line) => line && !/^>>\s*\d+(?:\s*[-,、]\s*\d+)*\s*$/.test(line));
    if (lines.length < 3) return false;

    let artLines = 0;
    let consecutive = 0;
    let longestRun = 0;
    let drawingCharacters = 0;

    lines.forEach((line) => {
      const compact = line.replace(/\s/g, '');
      const symbols = (compact.match(/[\\/|_<>()[\]{}~^'"`.,:;=\-＿￣／＼｜＜＞（）「」『』｛｝［］～＾｀´ｰ―‐ー\u2500-\u259f\u2800-\u28ff○●◎◯■□◆◇▲△▼▽]/g) || []).length;
      const isSeparator = /^[-_=─━―.・…]{3,}$/.test(compact);
      const isUrl = /^https?:\/\/\S+$/i.test(compact);
      const isArtLine = !isSeparator && !isUrl && compact.length >= 3 &&
        symbols >= 3 && symbols / compact.length >= 0.35;
      drawingCharacters += isArtLine ? symbols : 0;

      if (isArtLine) {
        artLines += 1;
        consecutive += 1;
        longestRun = Math.max(longestRun, consecutive);
      } else {
        consecutive = 0;
      }
    });

    return drawingCharacters >= 9 && artLines / lines.length >= 0.4 &&
      (longestRun >= 3 || artLines >= 4);
  }

  function duplicateKey(body) {
    // 全角・半角、空白、返信先番号の違いをそろえて比較する。
    const normalized = body.normalize('NFKC');
    const key = normalized
      .replace(/>>\s*\d+(?:\s*[-,、]\s*\d+)*/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    // アンカーだけの投稿は返信先ごとに残す。
    return key || normalized.replace(/\s+/g, ' ').trim();
  }

  function hasSameLongBody(first, second) {
    // 長い共通本文に短い末尾を付けた連投も1件にまとめる。
    const maxLength = Math.max(first.length, second.length);
    let sharedLength = 0;
    while (sharedLength < Math.min(first.length, second.length) &&
      first[sharedLength] === second[sharedLength]) {
      sharedLength += 1;
    }

    return sharedLength >= 120 && sharedLength / maxLength >= 0.85 &&
      maxLength - sharedLength <= 60;
  }

  function filterComments(comments) {
    const kept = [];
    const exactMatches = new Map();
    const longBodies = new Map();
    const duplicateTargets = new Map();
    let aaRemoved = 0;
    let duplicatesRemoved = 0;

    comments.forEach((comment) => {
      if (isAsciiArt(comment.body)) {
        aaRemoved += 1;
        return;
      }

      const key = duplicateKey(comment.body);
      let original = key ? exactMatches.get(key) : undefined;
      const prefix = key.slice(0, 120);
      if (!original && key.length >= 120) {
        original = (longBodies.get(prefix) || []).find(
          (candidate) => hasSameLongBody(candidate.key, key),
        )?.comment;
      }

      if (original) {
        duplicatesRemoved += 1;
        duplicateTargets.set(comment.number, original.number);
        return;
      }

      kept.push(comment);
      if (key) exactMatches.set(key, comment);
      if (key.length >= 120) {
        if (!longBodies.has(prefix)) longBodies.set(prefix, []);
        longBodies.get(prefix).push({ key, comment });
      }
    });

    // 除外した重複投稿への返信は、最初に残した投稿の直後にまとめる。
    const filtered = kept.map((comment) => ({
      ...comment,
      anchorNumbers: [...new Set(comment.anchorNumbers.map(
        (number) => duplicateTargets.get(number) || number,
      ))],
    }));

    return { comments: filtered, aaRemoved, duplicatesRemoved };
  }

  function collectComments() {
    const { comments, aaRemoved, duplicatesRemoved } = filterComments(readComments());
    const text = orderComments(comments)
      .map(({ number, body }) =>
        body ? `ID:${number}\n${body}` : `ID:${number}`,
      )
      .join('\n\n');

    return { text, count: comments.length, removedCount: aaRemoved + duplicatesRemoved };
  }

  function removalStatus(removedCount) {
    return removedCount ? `（${removedCount}件除外）` : '';
  }

  function copyText(text) {
    if (typeof GM_setClipboard === 'function') {
      GM_setClipboard(text, 'text');
      return Promise.resolve();
    }

    if (navigator.clipboard?.writeText) {
      return navigator.clipboard.writeText(text);
    }

    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const copied = document.execCommand('copy');
    textarea.remove();

    return copied
      ? Promise.resolve()
      : Promise.reject(new Error('クリップボードへコピーできませんでした。'));
  }

  function showStatus(button, message, normalLabel, isError = false) {
    button.textContent = message;
    button.style.background = isError ? '#b42318' : '#16803c';

    window.setTimeout(() => {
      button.textContent = normalLabel;
      button.style.background = '#0066cc';
    }, 2200);
  }

  function defaultFolderName() {
    return (
      document.querySelector('#threadtitle, h1, .thread-title')?.textContent ||
      document.title ||
      '2ch.sc-thread'
    )
      .replace(/\s+/g, ' ')
      .trim();
  }

  function safeFolderName(name) {
    let safeName = name
      .replace(/[<>:"/\\|?*\u0000-\u001f]/g, '＿')
      .replace(/[. ]+$/g, '')
      .trim()
      .slice(0, 120);

    if (!safeName) safeName = '2ch.sc-thread';
    if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(safeName)) {
      safeName = `_${safeName}`;
    }
    return safeName;
  }

  function downloadMarkdownFallback(text, name) {
    const blob = new Blob([`\ufeff${text}`], {
      type: 'text/markdown;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${name}.md`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  async function saveCommentsToFolder(text, requestedFolderName) {
    const folderName = safeFolderName(requestedFolderName);
    const pageWindow =
      typeof unsafeWindow === 'undefined' ? window : unsafeWindow;
    const showDirectoryPicker = pageWindow.showDirectoryPicker;

    // Firefox等、File System Access API非対応ブラウザでは通常のMD保存にする。
    if (typeof showDirectoryPicker !== 'function') {
      downloadMarkdownFallback(text, folderName);
      return { folderName, usedFallback: true };
    }

    const parentDirectory = await showDirectoryPicker.call(pageWindow, {
      id: '2ch-sc-comment-copy-save-location',
      mode: 'readwrite',
    });
    const threadDirectory = await parentDirectory.getDirectoryHandle(folderName, {
      create: true,
    });
    const fileHandle = await threadDirectory.getFileHandle('スレッド.md', {
      create: true,
    });
    const writable = await fileHandle.createWritable();

    try {
      await writable.write(
        new Blob([`\ufeff${text}`], { type: 'text/markdown;charset=utf-8' }),
      );
    } finally {
      await writable.close();
    }

    return { folderName, usedFallback: false };
  }

  function createSaveDialog(saveButton) {
    const overlay = document.createElement('div');
    overlay.id = DIALOG_ID;
    overlay.hidden = true;

    Object.assign(overlay.style, {
      position: 'fixed',
      inset: '0',
      zIndex: '2147483647',
      display: 'none',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
      background: 'rgba(0, 0, 0, 0.5)',
    });

    const panel = document.createElement('div');
    Object.assign(panel.style, {
      width: 'min(560px, 100%)',
      padding: '20px',
      borderRadius: '10px',
      background: '#fff',
      color: '#222',
      boxShadow: '0 10px 35px rgba(0, 0, 0, 0.35)',
      fontSize: '14px',
    });

    const heading = document.createElement('div');
    heading.textContent = '保存フォルダ名';
    Object.assign(heading.style, {
      marginBottom: '10px',
      fontSize: '18px',
      fontWeight: '700',
    });

    const input = document.createElement('textarea');
    input.rows = 2;
    input.wrap = 'soft';
    input.autocomplete = 'off';
    input.setAttribute('aria-label', '保存フォルダ名');
    Object.assign(input.style, {
      boxSizing: 'border-box',
      width: '100%',
      minHeight: '70px',
      maxHeight: '220px',
      margin: '0 0 8px',
      padding: '8px 10px',
      border: '1px solid #888',
      borderRadius: '6px',
      background: '#fff',
      color: '#111',
      fontSize: '15px',
      lineHeight: '1.5',
      overflowY: 'auto',
      resize: 'vertical',
      whiteSpace: 'pre-wrap',
      overflowWrap: 'anywhere',
    });

    function fitInputHeight() {
      input.style.height = 'auto';
      input.style.height = `${Math.min(Math.max(input.scrollHeight, 70), 220)}px`;
    }

    const note = document.createElement('div');
    note.textContent =
      '「保存」を押した後、作成先となる親フォルダを選択してください。中に スレッド.md を保存します。';
    Object.assign(note.style, {
      marginBottom: '14px',
      color: '#555',
      lineHeight: '1.5',
    });

    const error = document.createElement('div');
    Object.assign(error.style, {
      minHeight: '1.5em',
      marginBottom: '8px',
      color: '#b42318',
    });

    const controls = document.createElement('div');
    Object.assign(controls.style, {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '8px',
    });

    const cancelButton = document.createElement('button');
    cancelButton.type = 'button';
    cancelButton.textContent = 'キャンセル';

    const confirmButton = document.createElement('button');
    confirmButton.type = 'button';
    confirmButton.textContent = '保存';

    [cancelButton, confirmButton].forEach((button) => {
      Object.assign(button.style, {
        margin: '0',
        padding: '8px 16px',
        border: 'none',
        borderRadius: '6px',
        fontSize: '14px',
        fontWeight: '700',
        cursor: 'pointer',
      });
    });
    cancelButton.style.background = '#e5e7eb';
    cancelButton.style.color = '#222';
    confirmButton.style.background = '#0066cc';
    confirmButton.style.color = '#fff';

    function closeDialog() {
      overlay.hidden = true;
      overlay.style.display = 'none';
      error.textContent = '';
      confirmButton.disabled = false;
      confirmButton.textContent = '保存';
    }

    function openDialog() {
      input.value = defaultFolderName();
      overlay.hidden = false;
      overlay.style.display = 'flex';
      window.setTimeout(() => {
        fitInputHeight();
        input.focus();
        input.select();
      }, 0);
    }

    cancelButton.addEventListener('click', closeDialog);
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay) closeDialog();
    });
    overlay.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') closeDialog();
    });

    confirmButton.addEventListener('click', async () => {
      if (!input.value.trim()) {
        error.textContent = 'フォルダ名を入力してください。';
        input.focus();
        return;
      }

      const { text, count, removedCount } = collectComments();
      if (!text) {
        error.textContent = '保存できるレスが見つかりません。';
        return;
      }

      confirmButton.disabled = true;
      confirmButton.textContent = '保存中…';
      error.textContent = '';

      try {
        const result = await saveCommentsToFolder(text, input.value);
        closeDialog();
        showStatus(
          saveButton,
          result.usedFallback
            ? `${count}件をMD保存しました${removalStatus(removedCount)}`
            : `${count}件を保存しました${removalStatus(removedCount)}`,
          SAVE_LABEL,
        );
      } catch (saveError) {
        confirmButton.disabled = false;
        confirmButton.textContent = '保存';

        if (saveError?.name === 'AbortError') {
          error.textContent = '保存先の選択をキャンセルしました。';
        } else {
          console.error('[2ch.sc コメント保存]', saveError);
          error.textContent = `保存に失敗しました：${saveError?.message || saveError}`;
        }
      }
    });

    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        confirmButton.click();
      }
    });
    input.addEventListener('input', fitInputHeight);

    controls.append(cancelButton, confirmButton);
    panel.append(heading, input, note, error, controls);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    return { openDialog };
  }

  function createButton() {
    if (document.getElementById(BUTTON_ID)) return;

    const button = document.createElement('button');
    button.id = BUTTON_ID;
    button.type = 'button';
    button.textContent = NORMAL_LABEL;
    button.title = 'AA・重複投稿を除外し、表示中のレスを親子関係で並べ替えてコピー';

    Object.assign(button.style, {
      position: 'fixed',
      right: '18px',
      bottom: '18px',
      zIndex: '2147483647',
      padding: '11px 16px',
      border: 'none',
      borderRadius: '8px',
      background: '#0066cc',
      color: '#fff',
      fontSize: '14px',
      fontWeight: '700',
      lineHeight: '1.4',
      boxShadow: '0 3px 12px rgba(0, 0, 0, 0.28)',
      cursor: 'pointer',
    });

    button.addEventListener('mouseenter', () => {
      if (button.textContent === NORMAL_LABEL) button.style.background = '#0052a3';
    });
    button.addEventListener('mouseleave', () => {
      if (button.textContent === NORMAL_LABEL) button.style.background = '#0066cc';
    });

    button.addEventListener('click', async () => {
      const { text, count, removedCount } = collectComments();

      if (!text) {
        showStatus(button, 'レスが見つかりません', NORMAL_LABEL, true);
        return;
      }

      try {
        await copyText(text);
        showStatus(button, `${count}件コピーしました${removalStatus(removedCount)}`, NORMAL_LABEL);
      } catch (error) {
        console.error('[2ch.sc コメントコピー]', error);
        showStatus(button, 'コピーに失敗しました', NORMAL_LABEL, true);
      }
    });

    document.body.appendChild(button);

    const saveButton = document.createElement('button');
    saveButton.id = SAVE_BUTTON_ID;
    saveButton.type = 'button';
    saveButton.textContent = SAVE_LABEL;
    saveButton.title = 'AA・重複投稿を除外し、並べ替えたレスをMarkdownファイルへ保存';

    Object.assign(saveButton.style, {
      position: 'fixed',
      right: '18px',
      bottom: '68px',
      zIndex: '2147483646',
      padding: '11px 16px',
      border: 'none',
      borderRadius: '8px',
      background: '#0066cc',
      color: '#fff',
      fontSize: '14px',
      fontWeight: '700',
      lineHeight: '1.4',
      boxShadow: '0 3px 12px rgba(0, 0, 0, 0.28)',
      cursor: 'pointer',
    });

    const saveDialog = createSaveDialog(saveButton);
    saveButton.addEventListener('click', saveDialog.openDialog);
    document.body.appendChild(saveButton);
  }

  createButton();
})();
