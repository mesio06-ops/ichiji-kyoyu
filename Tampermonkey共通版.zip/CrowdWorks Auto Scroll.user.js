// ==UserScript==
// @name         CrowdWorks Auto Scroll
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  クラウドワークス求人一覧 自動スクロール(スタート/ストップボタン付き)
// @match        https://crowdworks.jp/job_offers*
// @grant        none
// ==/UserScript==

window.onload = function() {
    let scrollInterval = null;
    let isScrolling = false;
    let lastHeight = 0;
    let tries = 0;
    const maxTriesLimit = 50;

    // ボタンを作成
    const button = document.createElement('button');
    button.textContent = 'スクロール開始';
    button.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        box-shadow: 0 2px 5px rgba(0,0,0,0.3);
    `;

    document.body.appendChild(button);

    // スクロール開始関数
    function startScroll() {
        if (isScrolling) return;

        isScrolling = true;
        lastHeight = 0;
        tries = 0;
        let maxTries = maxTriesLimit;

        button.textContent = 'スクロール停止';
        button.style.backgroundColor = '#f44336';

        scrollInterval = setInterval(() => {
            window.scrollTo(0, document.body.scrollHeight);
            const currentHeight = document.body.scrollHeight;

            if (currentHeight === lastHeight) {
                tries++;
            } else {
                tries = 0;
                lastHeight = currentHeight;
            }

            if (tries > 5 || maxTries-- <= 0) {
                stopScroll();
                console.log("スクロール終了");
            }
        }, 1000);
    }

    // スクロール停止関数
    function stopScroll() {
        if (!isScrolling) return;

        clearInterval(scrollInterval);
        scrollInterval = null;
        isScrolling = false;

        button.textContent = 'スクロール開始';
        button.style.backgroundColor = '#4CAF50';
    }

    // ボタンクリックイベント
    button.addEventListener('click', () => {
        if (isScrolling) {
            stopScroll();
        } else {
            startScroll();
        }
    });
};