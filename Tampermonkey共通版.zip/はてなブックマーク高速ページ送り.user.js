// ==UserScript==
// @name         はてなブックマーク高速ページ送り
// @namespace    https://tampermonkey.net/
// @version      3.1.0
// @description  超高速で次々とページを読み込む + トップに戻るボタン
// @author       AI Assistant
// @match        https://b.hatena.ne.jp/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ===== 設定 =====
    const CONFIG = {
        SCROLL_SPEED: 100,            // 一度にスクロールする量（大きいほど速い）
        SCROLL_INTERVAL: 10,          // スクロール間隔（ミリ秒、小さいほど速い）
        LOAD_WAIT: 500,               // ページ読み込み後の待機時間
        DEBUG: true
    };

    // ===== グローバル変数 =====
    let isRunning = true;
    let isLoading = false;
    let isFinished = false;
    let nextURL = null;
    let listContainer = null;
    let seenEntryIds = new Set();
    let statusBar = null;
    let controlPanel = null;
    let topButton = null;

    // ===== ユーティリティ =====

    function log(...args) {
        if (CONFIG.DEBUG) {
            console.log('[高速ページ送り]', ...args);
        }
    }

    function toAbsoluteURL(href) {
        try {
            return new URL(href, location.href).href;
        } catch (e) {
            return null;
        }
    }

    function generateItemKey(element) {
        const entryIdElement = element.querySelector('[data-entry-id]');
        if (entryIdElement) {
            const entryId = entryIdElement.getAttribute('data-entry-id');
            if (entryId) return `entry-${entryId}`;
        }

        const titleLink = element.querySelector('h3 a');
        if (titleLink && titleLink.href) {
            return `url-${titleLink.href}`;
        }

        return `text-${element.textContent.trim().substring(0, 50)}`;
    }

    // ===== 検出 =====

    function findNextPageLink(doc = document) {
        const link = doc.querySelector('p.entrylist-readmore a.js-keyboard-openable');
        if (link && link.href && link.textContent.includes('次のページ')) {
            return link;
        }
        return null;
    }

    function detectListContainer(doc = document) {
        const container = doc.querySelector('ul.entrylist-item');
        if (container) {
            const items = container.querySelectorAll('li.js-keyboard-selectable-item');
            if (items.length > 0) {
                return container;
            }
        }
        return null;
    }

    // ===== UI =====

    function createStatusBar() {
        const bar = document.createElement('div');
        bar.style.cssText = `
            position: fixed;
            left: 20px;
            bottom: 20px;
            z-index: 2147483647;
            background: rgba(0, 0, 0, 0.9);
            color: #0f0;
            padding: 12px 18px;
            border-radius: 8px;
            font-size: 14px;
            font-family: monospace;
            font-weight: bold;
            border: 2px solid #0f0;
        `;
        document.body.appendChild(bar);
        return bar;
    }

    function createControlPanel() {
        const panel = document.createElement('div');
        panel.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 2147483647;
            background: white;
            border: 3px solid #ff6600;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            font-family: sans-serif;
            font-size: 14px;
            min-width: 200px;
        `;

        const title = document.createElement('div');
        title.textContent = '⚡ 高速ページ送り';
        title.style.cssText = `
            font-weight: bold;
            margin-bottom: 12px;
            color: #ff6600;
            text-align: center;
            font-size: 16px;
        `;

        const button = document.createElement('button');
        button.style.cssText = `
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            transition: all 0.2s;
        `;

        function updateButton() {
            button.textContent = isRunning ? '⏸ 停止' : '▶ 再開';
            button.style.backgroundColor = isRunning ? '#e74c3c' : '#27ae60';
            button.style.color = 'white';
        }

        button.addEventListener('click', () => {
            isRunning = !isRunning;
            updateButton();

            if (isRunning) {
                showStatus('再開');
                startProcess();
            } else {
                showStatus('停止');
            }
        });

        updateButton();
        panel.appendChild(title);
        panel.appendChild(button);
        document.body.appendChild(panel);

        return panel;
    }

    function createTopButton() {
        const button = document.createElement('button');
        button.innerHTML = '↑<br>TOP';
        button.style.cssText = `
            position: fixed;
            right: 20px;
            bottom: 20px;
            z-index: 2147483647;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            font-family: sans-serif;
            line-height: 1.3;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            opacity: 0;
            pointer-events: none;
        `;

        button.addEventListener('mouseenter', () => {
            button.style.transform = 'scale(1.1)';
            button.style.boxShadow = '0 6px 20px rgba(0, 0, 0, 0.4)';
        });

        button.addEventListener('mouseleave', () => {
            button.style.transform = 'scale(1)';
            button.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.3)';
        });

        button.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        document.body.appendChild(button);

        // スクロールに応じて表示/非表示
        let scrollTimeout;
        window.addEventListener('scroll', () => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollTop > 300) {
                button.style.opacity = '1';
                button.style.pointerEvents = 'auto';
            } else {
                button.style.opacity = '0';
                button.style.pointerEvents = 'none';
            }
        }, { passive: true });

        return button;
    }

    function showStatus(message) {
        if (!statusBar) return;
        statusBar.textContent = message;
    }

    // ===== メイン処理 =====

    async function scrollToBottom() {
        return new Promise((resolve) => {
            const startPos = window.pageYOffset;
            const maxScroll = document.documentElement.scrollHeight - window.innerHeight;

            if (startPos >= maxScroll - 50) {
                resolve();
                return;
            }

            const interval = setInterval(() => {
                const currentPos = window.pageYOffset;
                const targetPos = document.documentElement.scrollHeight - window.innerHeight;

                if (currentPos >= targetPos - 50) {
                    clearInterval(interval);
                    resolve();
                } else {
                    window.scrollBy(0, CONFIG.SCROLL_SPEED);
                }
            }, CONFIG.SCROLL_INTERVAL);
        });
    }

    async function loadNextPage() {
        if (!nextURL || isFinished) {
            isFinished = true;
            showStatus('✓ 全ページ読み込み完了');
            isRunning = false;
            return false;
        }

        isLoading = true;
        showStatus('⏳ 読み込み中...');
        log('読み込み:', nextURL);

        try {
            const response = await fetch(nextURL, {
                credentials: 'same-origin'
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const html = await response.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            const newContainer = detectListContainer(doc);
            if (!newContainer) {
                throw new Error('コンテンツなし');
            }

            const newItems = newContainer.querySelectorAll('li.js-keyboard-selectable-item');
            let addedCount = 0;

            newItems.forEach(item => {
                const itemKey = generateItemKey(item);

                if (!seenEntryIds.has(itemKey)) {
                    seenEntryIds.add(itemKey);

                    const clonedItem = item.cloneNode(true);
                    clonedItem.removeAttribute('id');
                    clonedItem.querySelectorAll('[id]').forEach(el => el.removeAttribute('id'));

                    listContainer.appendChild(clonedItem);
                    addedCount++;
                }
            });

            // 次のページリンク更新
            const newNextLink = findNextPageLink(doc);
            if (newNextLink) {
                nextURL = toAbsoluteURL(newNextLink.href);
                log('次URL:', nextURL);
            } else {
                nextURL = null;
                isFinished = true;
            }

            showStatus(`✓ ${addedCount}件追加 (合計: ${seenEntryIds.size}件)`);
            log(`${addedCount}件追加`);

            // 既存の「次のページ」リンクを非表示
            document.querySelectorAll('p.entrylist-readmore').forEach(el => {
                el.style.display = 'none';
            });

            return true;

        } catch (error) {
            log('エラー:', error);
            showStatus(`✗ エラー: ${error.message}`);
            return false;
        } finally {
            isLoading = false;
        }
    }

    async function startProcess() {
        while (isRunning && !isFinished) {
            // 1. 最下部まで高速スクロール
            showStatus('⚡ スクロール中...');
            await scrollToBottom();

            // 2. 次ページ読み込み
            const success = await loadNextPage();

            if (!success || isFinished) {
                break;
            }

            // 3. 少し待機
            await new Promise(resolve => setTimeout(resolve, CONFIG.LOAD_WAIT));
        }
    }

    // ===== 初期化 =====

    function initialize() {
        log('初期化開始');

        const nextLink = findNextPageLink();
        if (!nextLink) {
            log('次ページリンクなし - 単一ページ');
            // TOPボタンだけは作成
            topButton = createTopButton();
            return;
        }

        nextURL = toAbsoluteURL(nextLink.href);
        if (!nextURL) {
            log('無効なURL');
            return;
        }

        listContainer = detectListContainer();
        if (!listContainer) {
            log('コンテナ未検出');
            return;
        }

        // 既存アイテム記録
        const existingItems = listContainer.querySelectorAll('li.js-keyboard-selectable-item');
        existingItems.forEach(item => {
            seenEntryIds.add(generateItemKey(item));
        });

        log(`既存${existingItems.length}件記録`);

        // UI作成
        statusBar = createStatusBar();
        controlPanel = createControlPanel();
        topButton = createTopButton();

        // 既存ページャー非表示
        document.querySelectorAll('p.entrylist-readmore').forEach(el => {
            el.style.display = 'none';
        });

        // 処理開始
        showStatus('⚡ 開始');
        startProcess();

        log('初期化完了');
    }

    // ===== 開始 =====

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        setTimeout(initialize, 300);
    }

})();