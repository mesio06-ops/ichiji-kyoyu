// ==UserScript==
// @name         はてブ注目コメント説明へジャンプ (修正版)
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  はてなブックマークのエントリーページで注目コメント説明文へワンクリックでジャンプ
// @author       You
// @match        https://b.hatena.ne.jp/entry*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const BUTTON_ID = 'hatena-jump-button-custom';

    // ボタン生成関数
    function createButton() {
        // すでにボタンがある場合は何もしない
        if (document.getElementById(BUTTON_ID)) return;

        const jumpButton = document.createElement('button');
        jumpButton.id = BUTTON_ID; // 重複防止用ID
        jumpButton.textContent = '注目コメント説明へ';
        jumpButton.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            z-index: 2147483647; /* 他の要素より手前に表示するために最大値を設定 */
            padding: 10px 15px;
            background-color: #00a4de;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        `;

        jumpButton.addEventListener('mouseenter', function() { this.style.backgroundColor = '#0088bb'; });
        jumpButton.addEventListener('mouseleave', function() { this.style.backgroundColor = '#00a4de'; });

        jumpButton.addEventListener('click', function() {
            // テキストで検索（空白や改行の影響を避けるため部分一致検索を柔軟にする）
            const targetText = '注目コメント算出アルゴリズム';

            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
            let targetNode = null;

            while(walker.nextNode()) {
                // テキストを含み、かつ親要素が表示されているものを探す
                if(walker.currentNode.textContent.includes(targetText)) {
                    targetNode = walker.currentNode.parentElement;
                    break;
                }
            }

            if(targetNode) {
                targetNode.scrollIntoView({behavior: "smooth", block: "center"});

                // ハイライト処理
                const originalTransition = targetNode.style.transition;
                const originalBackground = targetNode.style.backgroundColor;

                targetNode.style.transition = 'background-color 0.5s';
                targetNode.style.backgroundColor = '#fff3cd';

                setTimeout(() => {
                    targetNode.style.backgroundColor = originalBackground;
                    setTimeout(() => {
                         targetNode.style.transition = originalTransition;
                    }, 500);
                }, 2000);
            } else {
                alert('注目コメント説明が見つかりませんでした。\nページ下部に読み込まれていない可能性があります。');
            }
        });

        document.body.appendChild(jumpButton);
    }

    // 1. 初回実行
    createButton();

    // 2. ページ読み込み完了時にも実行
    window.addEventListener('load', createButton);

    // 3. SPA遷移対策（URLが変わったりDOMが変わったりした場合用）
    const observer = new MutationObserver((mutations) => {
        createButton();
    });
    observer.observe(document.body, { childList: true, subtree: true });

})();
