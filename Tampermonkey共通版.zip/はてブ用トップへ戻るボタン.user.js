// ==UserScript==
// @name         はてブ用トップへ戻るボタン
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  はてなブックマークサイトに右下にトップへ戻るボタンを追加
// @author       You
// @match        https://b.hatena.ne.jp/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ボタン要素を作成
    const backToTopButton = document.createElement('button');
    backToTopButton.innerHTML = '↑';
    backToTopButton.id = 'backToTopBtn';

    // ボタンのスタイルを設定
    backToTopButton.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 50px;
        height: 50px;
        background-color: #ff6600;
        color: white;
        border: none;
        border-radius: 50%;
        font-size: 20px;
        font-weight: bold;
        cursor: pointer;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        z-index: 9999;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
    `;

    // ホバー効果
    backToTopButton.addEventListener('mouseenter', function() {
        this.style.backgroundColor = '#e55a00';
        this.style.transform = 'scale(1.1)';
    });

    backToTopButton.addEventListener('mouseleave', function() {
        this.style.backgroundColor = '#ff6600';
        this.style.transform = 'scale(1)';
    });

    // クリック時の動作（スムーズスクロール）
    backToTopButton.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // ページにボタンを追加
    document.body.appendChild(backToTopButton);

    // スクロール位置に応じてボタンの表示/非表示を制御
    function toggleButtonVisibility() {
        if (window.pageYOffset > 300) {
            backToTopButton.style.opacity = '1';
            backToTopButton.style.visibility = 'visible';
        } else {
            backToTopButton.style.opacity = '0';
            backToTopButton.style.visibility = 'hidden';
        }
    }

    // スクロールイベントリスナーを追加
    window.addEventListener('scroll', toggleButtonVisibility);

    // 初期状態での表示制御
    toggleButtonVisibility();

})();
