// ==UserScript==
// @name         Reddit コメント全展開・整形・コピー
// @namespace    https://ernestweb.co.jp/
// @version      1.1.0
// @description  Redditの全コメントを取得し、「スレ主：/ID:」形式へ整形してクリップボードへコピーします
// @match        https://www.reddit.com/*
// @match        https://old.reddit.com/*
// @match        https://sh.reddit.com/*
// @grant        GM_setClipboard
// @run-at       document-idle
// ==/UserScript==

(function () {
    'use strict';

    const MORE_CHILDREN_BATCH_SIZE = 100;
    const API_INTERVAL_MS = 1100;
    const MAX_API_RETRIES = 4;

    const state = {
        running: false,
        cancelled: false,
        requests: 0,
    };

    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

    function cleanText(text) {
        return (text || '')
            .replace(/\u00a0/g, ' ')
            .replace(/[ \t]+\n/g, '\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
    }

    function removeEmojis(text) {
        return text.replace(/[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]|[\u{1F900}-\u{1F9FF}]|[\u{1FA00}-\u{1FA6F}]|[\u{1FA70}-\u{1FAFF}]|[\u{FE00}-\u{FE0F}]|[\u{1F018}-\u{1F270}]|[\u{238C}-\u{2454}]|[\u{20D0}-\u{20FF}]|[\u{E0020}-\u{E007F}]/gu, '');
    }

    function isVisible(el) {
        if (!(el instanceof HTMLElement)) return false;
        const style = getComputedStyle(el);
        return style.visibility !== 'hidden' && style.display !== 'none' && el.getClientRects().length > 0;
    }

    function getPostId() {
        const match = location.pathname.match(/\/comments\/([a-z0-9]+)/i);
        if (!match) throw new Error('Redditの投稿ページで実行してください。');
        return match[1];
    }

    function getSort() {
        const value = new URLSearchParams(location.search).get('sort') || 'confidence';
        return /^(confidence|top|new|controversial|old|qa)$/.test(value) ? value : 'confidence';
    }

    async function fetchJson(url, attempt = 1) {
        const response = await fetch(url, {
            credentials: 'include',
            headers: { Accept: 'application/json' },
        });
        state.requests += 1;

        if ((response.status === 429 || response.status >= 500) && attempt < MAX_API_RETRIES) {
            const retryAfter = Number(response.headers.get('retry-after')) || attempt * 3;
            setStatus(`Redditの応答待ち… ${retryAfter}秒`, 'working');
            await sleep(retryAfter * 1000);
            return fetchJson(url, attempt + 1);
        }
        if (!response.ok) throw new Error(`Reddit APIの取得に失敗しました（HTTP ${response.status}）`);
        return response.json();
    }

    function listingChildren(listing) {
        return listing?.data?.children || [];
    }

    function collectThings(things, comments, moreIds, order) {
        for (const thing of things) {
            if (thing.kind === 't1') {
                const data = thing.data || {};
                if (data.id && !comments.has(data.id)) {
                    comments.set(data.id, {
                        id: data.id,
                        parentId: String(data.parent_id || '').replace(/^t[13]_/, ''),
                        author: cleanText(data.author || ''),
                        content: cleanText(data.body || ''),
                        order: order.value++,
                    });
                }
                collectThings(listingChildren(data.replies), comments, moreIds, order);
            } else if (thing.kind === 'more') {
                for (const id of thing.data?.children || []) moreIds.add(id);
            }
        }
    }

    function orderComments(comments, postId) {
        const childrenByParent = new Map();
        for (const comment of comments.values()) {
            const siblings = childrenByParent.get(comment.parentId) || [];
            siblings.push(comment);
            childrenByParent.set(comment.parentId, siblings);
        }
        for (const siblings of childrenByParent.values()) siblings.sort((a, b) => a.order - b.order);

        const result = [];
        const visited = new Set();
        const visit = parentId => {
            for (const comment of childrenByParent.get(parentId) || []) {
                if (visited.has(comment.id)) continue;
                visited.add(comment.id);
                result.push(comment);
                visit(comment.id);
            }
        };
        visit(postId);

        // APIが親を返さなかった孤立コメントも欠落させない。
        [...comments.values()]
            .sort((a, b) => a.order - b.order)
            .forEach(comment => {
                if (!visited.has(comment.id)) result.push(comment);
            });
        return result;
    }

    async function fetchAllComments() {
        const postId = getPostId();
        const sort = getSort();
        const baseUrl = `${location.origin}/comments/${postId}.json?raw_json=1&limit=500&depth=100&sort=${sort}`;
        setStatus('全コメントを取得中…', 'working');
        const initial = await fetchJson(baseUrl);
        if (!Array.isArray(initial) || initial.length < 2) {
            throw new Error('Reddit APIから投稿データを取得できませんでした。');
        }

        const postData = listingChildren(initial[0])[0]?.data || {};
        const comments = new Map();
        const pendingMoreIds = new Set();
        const requestedIds = new Set();
        const order = { value: 0 };
        collectThings(listingChildren(initial[1]), comments, pendingMoreIds, order);

        while (!state.cancelled) {
            const batch = [...pendingMoreIds]
                .filter(id => !requestedIds.has(id) && !comments.has(id))
                .slice(0, MORE_CHILDREN_BATCH_SIZE);
            if (batch.length === 0) break;
            batch.forEach(id => requestedIds.add(id));

            setStatus(`全コメントを取得中… ${comments.size}件`, 'working');
            const params = new URLSearchParams({
                api_type: 'json',
                link_id: `t3_${postId}`,
                children: batch.join(','),
                sort,
                raw_json: '1',
                limit_children: 'true',
            });
            const response = await fetchJson(`${location.origin}/api/morechildren.json?${params}`);
            const things = response?.json?.data?.things;
            if (!Array.isArray(things)) throw new Error('追加コメントの応答形式が不正です。');
            collectThings(things, comments, pendingMoreIds, order);
            await sleep(API_INTERVAL_MS);
        }

        return {
            post: {
                author: cleanText(postData.author || ''),
                content: cleanText([postData.title, postData.selftext].filter(Boolean).join('\n\n')),
            },
            comments: orderComments(comments, postId),
        };
    }

    function firstText(root, selectors) {
        for (const selector of selectors) {
            const el = root.querySelector(selector);
            const text = cleanText(el?.innerText || el?.textContent || '');
            if (text) return text;
        }
        return '';
    }

    function getAuthor(root) {
        const attributeNames = ['author', 'data-author', 'data-testid-author'];
        for (const name of attributeNames) {
            const value = cleanText(root.getAttribute?.(name) || '');
            if (value) return value.replace(/^u\//, '');
        }

        const text = firstText(root, [
            'a[data-testid="comment_author_link"]',
            'a[data-click-id="user"]',
            'a.author',
            '[slot="authorName"]',
            'faceplate-hovercard[aria-label^="u/"]',
        ]);
        return text.replace(/^u\//, '');
    }

    function getPost() {
        const roots = [
            ...document.querySelectorAll('shreddit-post'),
            ...document.querySelectorAll('.thing.link'),
            ...document.querySelectorAll('[data-testid="post-container"]'),
        ];
        const root = roots.find(isVisible);
        if (!root) return null;

        const title = cleanText(
            root.getAttribute('post-title') ||
            firstText(root, ['[slot="title"]', 'h1', 'a.title'])
        );
        const body = firstText(root, [
            '[slot="text-body"] .md',
            '[slot="text-body"]',
            '[data-click-id="text"] .md',
            '.usertext-body .md',
            '[data-testid="post-content"]',
        ]);
        const content = cleanText([title, body].filter(Boolean).join('\n\n'));
        return content ? { author: getAuthor(root), content } : null;
    }

    function getComments() {
        const selectorGroups = [
            'shreddit-comment',
            '.thing.comment',
            '[data-testid="comment"]',
        ];
        const elements = [];
        const seen = new Set();

        for (const selector of selectorGroups) {
            document.querySelectorAll(selector).forEach(el => {
                if (!seen.has(el) && isVisible(el)) {
                    seen.add(el);
                    elements.push(el);
                }
            });
        }

        return elements.map(root => {
            const content = firstText(root, [
                '[slot="comment"] .md',
                '[slot="comment"]',
                '[slot="comment-body"] .md',
                '[slot="comment-body"]',
                ':scope > .entry .usertext-body .md',
                '[data-testid="comment-content"]',
                '[data-click-id="text"] .md',
            ]);
            return { author: getAuthor(root), content };
        }).filter(item => item.content && item.content !== '[deleted]' && item.content !== '[removed]');
    }

    function buildOutput(apiData = null) {
        const post = apiData?.post?.content ? apiData.post : getPost();
        const comments = apiData?.comments || getComments();
        if (!post && comments.length === 0) {
            throw new Error('投稿・コメントを抽出できませんでした。コメント欄が表示されたページで実行してください。');
        }

        const opName = post?.author || '';
        const blocks = [];
        if (post) blocks.push({ ...post, isOp: true });
        comments.forEach(comment => blocks.push({ ...comment, isOp: Boolean(opName && comment.author === opName) }));

        const formattedBlocks = blocks.map(block => {
            const prefix = block.isOp ? 'スレ主：' : 'ID:';
            return `${prefix}\n${cleanText(removeEmojis(block.content))}`;
        }).filter(block => !/^(?:スレ主：|ID:)\s*$/.test(block));

        return {
            output: formattedBlocks.join('\n\n'),
            commentCount: Math.max(0, formattedBlocks.length - (post ? 1 : 0)),
        };
    }

    function copyText(text) {
        if (typeof GM_setClipboard === 'function') {
            GM_setClipboard(text, 'text');
            return Promise.resolve();
        }
        return navigator.clipboard.writeText(text);
    }

    async function run() {
        if (state.running) return;
        state.running = true;
        state.cancelled = false;
        state.requests = 0;
        actionButton.disabled = true;
        stopButton.disabled = false;

        try {
            let apiData = null;
            try {
                apiData = await fetchAllComments();
            } catch (error) {
                console.warn('[Reddit One Click] API取得失敗。画面上のコメントへフォールバックします。', error);
                setStatus('API取得失敗・画面から抽出中…', 'working');
            }
            if (state.cancelled) {
                setStatus('停止しました', 'idle');
                return;
            }

            setStatus('整形・コピー中…', 'working');
            const result = buildOutput(apiData);
            await copyText(result.output);
            const scope = apiData ? '' : '（画面に表示中の分のみ）';
            setStatus(`完了${scope}：コメント${result.commentCount}件・${result.output.length.toLocaleString()}文字`, apiData ? 'success' : 'error');
        } catch (error) {
            console.error('[Reddit One Click]', error);
            setStatus(`エラー：${error.message}`, 'error');
        } finally {
            state.running = false;
            actionButton.disabled = false;
            stopButton.disabled = true;
        }
    }

    function setStatus(message, type) {
        status.textContent = message;
        status.dataset.type = type;
    }

    const panel = document.createElement('section');
    panel.id = 'reddit-one-click-panel';
    panel.innerHTML = `
        <div class="roc-title">Reddit コメント取得</div>
        <button type="button" id="roc-run">全取得 → 整形 → コピー</button>
        <button type="button" id="roc-stop" disabled>停止</button>
        <div id="roc-status" data-type="idle">待機中</div>
    `;

    const style = document.createElement('style');
    style.textContent = `
        #reddit-one-click-panel {
            position: fixed; right: 20px; bottom: 20px; z-index: 2147483647;
            width: 250px; padding: 14px; border: 2px solid #ff4500;
            border-radius: 12px; background: #1a1a2e; color: #eee;
            box-shadow: 0 4px 20px rgba(0,0,0,.5); font: 13px/1.4 system-ui, sans-serif;
        }
        #reddit-one-click-panel .roc-title { margin-bottom: 10px; color: #ff7145; font-weight: 700; text-align: center; }
        #reddit-one-click-panel button { padding: 8px 10px; border: 0; border-radius: 7px; color: #fff; font-weight: 700; cursor: pointer; }
        #roc-run { width: 100%; background: #0f6cbd; }
        #roc-stop { width: 100%; margin-top: 7px; background: #70404f; }
        #reddit-one-click-panel button:disabled { cursor: default; opacity: .45; }
        #roc-status { margin-top: 9px; color: #aaa; font-size: 12px; text-align: center; overflow-wrap: anywhere; }
        #roc-status[data-type="working"] { color: #65d6b0; }
        #roc-status[data-type="success"] { color: #7ee787; }
        #roc-status[data-type="error"] { color: #ff7b72; }
    `;

    document.head.appendChild(style);
    document.body.appendChild(panel);

    const actionButton = panel.querySelector('#roc-run');
    const stopButton = panel.querySelector('#roc-stop');
    const status = panel.querySelector('#roc-status');

    actionButton.addEventListener('click', run);
    stopButton.addEventListener('click', () => {
        state.cancelled = true;
        stopButton.disabled = true;
        setStatus('停止処理中…', 'idle');
    });
})();
