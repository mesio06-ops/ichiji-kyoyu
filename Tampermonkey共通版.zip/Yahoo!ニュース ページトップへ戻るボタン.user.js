// ==UserScript==
// @name         Yahoo!ニュース ページトップへ戻るボタン
// @namespace    https://news.yahoo.co.jp/
// @version      1.0
// @description  Yahoo!ニュースの記事ページ右下に、スムーズにスクロールして最上部に戻るボタンを追加します。
// @author       Gemini
// @match        https://news.yahoo.co.jp/articles/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ボタン要素を作成
    const topButton = document.createElement('button');
    topButton.innerHTML = '▲';
    topButton.setAttribute('id', 'yahoo-scroll-top-btn');

    // ボタンのスタイルを設定
    Object.assign(topButton.style, {
        position: 'fixed',
        bottom: '30px',
        right: '30px',
        width: '50px',
        height: '50px',
        borderRadius: '50%',
        backgroundColor: '#181818',
        color: '#ffffff',
        border: 'none',
        fontSize: '20px',
        fontWeight: 'bold',
        cursor: 'pointer',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.3)',
        zIndex: '99999',
        display: 'none', // 初期状態は非表示
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'opacity 0.3s ease, background-color 0.2s ease',
        opacity: '0.8'
    });

    // 画面にボタンを追加
    document.body.appendChild(topButton);

    // 一定以上スクロールされたらボタンを表示し、上部に戻ったら非表示にする
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            topButton.style.display = 'flex';
        } else {
            topButton.style.display = 'none';
        }
    });

    // マウスホバー時のエフェクトを設定
    topButton.addEventListener('mouseenter', () => {
        topButton.style.backgroundColor = '#ff4d4d'; // Yahooのアクセントカラーを意識した赤系に変化
        topButton.style.opacity = '1';
    });

    topButton.addEventListener('mouseleave', () => {
        topButton.style.backgroundColor = '#181818';
        topButton.style.opacity = '0.8';
    });

    // ボタンがクリックされたときの動作（スムーズスクロール）
    topButton.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
})();