@echo off
chcp 65001 > nul
set PYTHONUTF8=1
py -3 "%~dp0transfer.py" sites
pause
