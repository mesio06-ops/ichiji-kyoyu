@echo off
chcp 65001 > nul
set PYTHONUTF8=1
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" (
  "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" "%~dp0credential_setup.py"
) else (
  py -3 "%~dp0credential_setup.py"
)
if errorlevel 1 pause
