"""利用者本人が画面でFTPSパスワードを再登録するための補助ツール。"""

import tkinter as tk
from tkinter import messagebox, ttk

import transfer


def validate_password(password, confirmation):
    if not password:
        raise ValueError("パスワードを入力してください。")
    if any(ord(char) < 32 or ord(char) == 127 for char in password):
        raise ValueError("入力に制御文字が含まれています。欄を空にして、もう一度入力してください。")
    if password != confirmation:
        raise ValueError("二つのパスワードが一致していません。入力内容を確認してください。")
    if len(password.encode("utf-16-le")) > 2560:
        raise ValueError("パスワードが長すぎます。入力内容を確認してください。")


def main():
    window = tk.Tk()
    window.title("AI共通FTP：パスワードの再登録")
    window.resizable(False, False)
    frame = ttk.Frame(window, padding=20)
    frame.grid()
    try:
        sites = transfer.load_json(transfer.SITES) if transfer.SITES.exists() else {}
        names = [name for name, site in sites.items() if site.get("protocol") == "ftps"]
        if not names:
            messagebox.showinfo("接続先の確認", "FTPSの接続先が登録されていません。", parent=window)
            window.destroy()
            return
    except (OSError, ValueError, TypeError):
        messagebox.showerror("設定の確認", "接続先の設定を読み取れませんでした。", parent=window)
        window.destroy()
        return

    ttk.Label(frame, text="NextFTPと同じ接続先・ユーザー名か確認してください。\n"
              "パスワードはこの画面で入力します。貼り付けも使えます。\n"
              "サーバー上のファイルの転送・変更は行いません。", justify="left").grid(
                  row=0, column=0, columnspan=2, sticky="w", pady=(0, 15))
    ttk.Label(frame, text="接続先").grid(row=1, column=0, sticky="w", pady=5)
    selection = tk.StringVar(value=names[0])
    combo = ttk.Combobox(frame, textvariable=selection, values=names, state="readonly", width=40)
    combo.grid(row=1, column=1, sticky="w", pady=5)
    host = tk.StringVar()
    user = tk.StringVar()
    for row, label, variable in ((2, "ホスト名", host), (3, "ユーザー名", user)):
        ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", pady=5)
        ttk.Entry(frame, textvariable=variable, state="readonly", width=44).grid(
            row=row, column=1, sticky="w", pady=5)
    password = tk.StringVar()
    confirmation = tk.StringVar()
    entry = None
    for row, label, variable in ((4, "パスワード", password), (5, "確認用にもう一度", confirmation)):
        ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=5)
        field = ttk.Entry(frame, textvariable=variable, show="●", width=44)
        field.grid(row=row, column=1, sticky="w", pady=5)
        if entry is None:
            entry = field
    ttk.Label(frame, text="Windows資格情報マネージャーに保存します。\n"
              "パスワードをチャットへ送る必要はありません。", justify="left").grid(
                  row=6, column=0, columnspan=2, sticky="w", pady=(12, 8))

    def refresh(_event=None):
        site = sites[selection.get()]
        host.set(site.get("host", ""))
        user.set(site.get("user", ""))
        password.set("")
        confirmation.set("")

    def save():
        name = selection.get()
        site = sites[name]
        try:
            validate_password(password.get(), confirmation.get())
            if not site.get("credential_target", "").startswith("AISharedTransfer/"):
                raise ValueError("認証情報の保存先が正しくありません。")
            # 画面を開いている間に登録内容が変化した場合は保存を止めます。
            current = transfer.load_json(transfer.SITES)
            if current.get(name) != site:
                raise ValueError("接続先の設定が変わっています。画面を閉じて開き直してください。")
        except (ValueError, OSError, KeyError):
            messagebox.showerror("入力内容の確認", "パスワードの空欄・一致・制御文字と接続先の設定をご確認ください。",
                                 parent=window)
            return
        if not messagebox.askyesno("再登録の確認", f"「{name}」の登録済みパスワードを変更します。\nよろしいですか？",
                                  parent=window):
            return
        try:
            transfer.store_password(site["credential_target"], site["user"], password.get())
        except (transfer.TransferError, OSError, ValueError):
            messagebox.showerror("保存の確認", "保存に失敗しました。Windowsの資格情報を利用できるか確認してください。",
                                 parent=window)
            return
        password.set("")
        confirmation.set("")
        messagebox.showinfo("再登録完了", "パスワードを再登録しました。\n"
                            "チャットで「登録し直した」とお知らせください。\n"
                            "この画面からサーバーへの接続は行っていません。", parent=window)
        window.destroy()

    combo.bind("<<ComboboxSelected>>", refresh)
    ttk.Button(frame, text="パスワードを再登録", command=save).grid(row=7, column=1, sticky="e", pady=8)
    refresh()
    entry.focus_set()
    window.mainloop()


if __name__ == "__main__":
    main()
