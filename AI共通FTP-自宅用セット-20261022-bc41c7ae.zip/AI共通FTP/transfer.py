"""複数のAIから利用する、計画・承認付きのファイル転送ツール。"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import ctypes
from ctypes import wintypes
import ftplib
import getpass
import hashlib
import json
import msvcrt
import os
from pathlib import Path, PurePosixPath
import posixpath
import re
import shutil
import ssl
import subprocess
import sys
import time
import uuid


BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
SITES = DATA / "sites.json"
JOBS = DATA / "jobs"
MAX_AGE = 24 * 60 * 60


class TransferError(Exception):
    """利用者に表示できる、秘密情報を含まないエラー。"""


def fingerprint(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def file_state(path):
    path = Path(path)
    if not path.exists():
        return None
    if not path.is_file() or path.is_symlink() or path.is_junction():
        raise TransferError("対象は通常のファイルに限定しています。")
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            digest.update(chunk)
            size += len(chunk)
    return {"bytes": size, "sha256": digest.hexdigest()}


def save_new_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def load_json(path):
    with Path(path).open(encoding="utf-8-sig") as stream:
        return json.load(stream)


def output(value):
    print(json.dumps(value, ensure_ascii=False, indent=2))


@contextmanager
def site_lock(name):
    directory = DATA / "locks"
    directory.mkdir(parents=True, exist_ok=True)
    with (directory / (fingerprint(name) + ".lock")).open("a+b") as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        try:
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise TransferError("同じ接続先で別の計画作成・転送を実行中です。完了を待ってください。")
        try:
            yield
        finally:
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)


def safe_text(value):
    if not value or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise TransferError("空文字や改行・制御文字を含む値は使用できません。")
    return value


def validate_site(site):
    if site.get("protocol") not in {"ftps", "sftp"}:
        raise TransferError("接続方式はFTPSまたはSFTPを指定してください。")
    host = safe_text(site["host"])
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.:-]*", host):
        raise TransferError("ホスト名にはサーバーの名前またはIPアドレスだけを指定してください。")
    safe_text(site["user"])
    if not 1 <= int(site["port"]) <= 65535:
        raise TransferError("ポート番号の範囲が正しくありません。")
    remote_path(site, ".", allow_directory=True)
    local_root = Path(site["local_root"])
    if not local_root.is_absolute() or not local_root.is_dir():
        raise TransferError("パソコン側の操作フォルダーを確認してください。")
    if site["protocol"] == "sftp":
        if not re.fullmatch(r"[A-Za-z0-9_][A-Za-z0-9_.@-]*", site["user"]):
            raise TransferError("SFTPのユーザー名に未対応の文字が含まれています。")
        for field in ("identity_file", "known_hosts"):
            if not Path(site[field]).is_file():
                raise TransferError("SFTPには秘密鍵と、確認済みのknown_hostsファイルが必要です。")
    elif not site.get("credential_target", "").startswith("AISharedTransfer/"):
        raise TransferError("認証情報の登録先が正しくありません。")


def get_site(name):
    sites = load_json(SITES) if SITES.exists() else {}
    if name not in sites:
        raise TransferError("接続先が未登録です。最初に接続先登録.cmdを開いてください。")
    site = sites[name]
    validate_site(site)
    return site


def remote_path(site, value, allow_directory=False):
    root = safe_text(site["remote_root"])
    value = safe_text(value)
    for item in (root, value):
        if any(c in item for c in '\\*?[]{}"'):
            raise TransferError("サーバー側のパスに未対応の記号が含まれています。")
        if ".." in PurePosixPath(item).parts:
            raise TransferError("上位フォルダーを指定するパスは使用できません。")
    if not root.startswith("/") or root.startswith("//"):
        raise TransferError("サーバー側の操作フォルダーは / で始まるパスを指定してください。")
    root = posixpath.normpath(root)
    result = posixpath.normpath(value if value.startswith("/") else posixpath.join(root, value))
    if result != root and not result.startswith(root.rstrip("/") + "/"):
        raise TransferError("サーバー側の操作範囲を超えています。")
    if not allow_directory and result == root:
        raise TransferError("転送するファイル名を指定してください。")
    return result


def local_path(site, value):
    root = Path(site["local_root"]).resolve(strict=True)
    supplied = Path(safe_text(value))
    candidate = supplied if supplied.is_absolute() else root / supplied
    resolved = candidate.resolve()
    if resolved == root or not resolved.is_relative_to(root):
        raise TransferError("パソコン側の操作範囲を超えています。")
    if not candidate.absolute().is_relative_to(root):
        raise TransferError("操作フォルダーからの相対パスを指定してください。")
    check = root
    for part in candidate.absolute().relative_to(root).parts:
        if part in {"..", "."} or ":" in part:
            raise TransferError("上位フォルダーや特殊なパスは使用できません。")
        if hasattr(os.path, "isreserved") and os.path.isreserved(part):
            raise TransferError("Windowsで予約された名前は使用できません。")
        check = check / part
        if check.is_symlink() or check.is_junction():
            raise TransferError("リンクやジャンクションを含むパスは操作できません。")
    if not resolved.parent.is_dir():
        raise TransferError("転送先の親フォルダーを先に用意してください。")
    return resolved


class Credential(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD), ("Type", wintypes.DWORD),
        ("TargetName", wintypes.LPWSTR), ("Comment", wintypes.LPWSTR),
        ("LastWritten", wintypes.FILETIME), ("CredentialBlobSize", wintypes.DWORD),
        ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)), ("Persist", wintypes.DWORD),
        ("AttributeCount", wintypes.DWORD), ("Attributes", ctypes.c_void_p),
        ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR),
    ]


def credential_api():
    if os.name != "nt":
        raise TransferError("この版の認証情報管理はWindowsに対応しています。")
    api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    api.CredWriteW.argtypes = [ctypes.POINTER(Credential), wintypes.DWORD]
    api.CredWriteW.restype = wintypes.BOOL
    api.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD,
                              ctypes.POINTER(ctypes.POINTER(Credential))]
    api.CredReadW.restype = wintypes.BOOL
    api.CredFree.argtypes = [ctypes.c_void_p]
    api.CredFree.restype = None
    return api


def store_password(target, username, password):
    raw = password.encode("utf-16-le")
    if not raw or len(raw) > 2560:
        raise TransferError("パスワードの長さを確認してください。")
    buffer = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    cred = Credential(Type=1, TargetName=target, Comment="AI共通FTPの接続用",
                      CredentialBlobSize=len(raw), CredentialBlob=buffer, Persist=2,
                      UserName=username)
    api = credential_api()
    if not api.CredWriteW(ctypes.byref(cred), 0):
        raise TransferError("Windows資格情報マネージャーへの登録に失敗しました。")


def read_password(target):
    api = credential_api()
    pointer = ctypes.POINTER(Credential)()
    if not api.CredReadW(target, 1, 0, ctypes.byref(pointer)):
        raise TransferError("このWindowsユーザーには接続用パスワードが登録されていません。")
    try:
        return ctypes.string_at(pointer.contents.CredentialBlob,
                                pointer.contents.CredentialBlobSize).decode("utf-16-le")
    finally:
        api.CredFree(pointer)


class FTPSBackend:
    def __init__(self, site):
        self.site = site
        self.ftp = ftplib.FTP_TLS(context=ssl.create_default_context(),
                                  timeout=30, encoding=site.get("encoding", "utf-8"))
        try:
            self.ftp.connect(site["host"], int(site["port"]))
            self.ftp.login(site["user"], read_password(site["credential_target"]))
            self.ftp.prot_p()
            self.ftp.set_pasv(True)
            self.ftp.cwd(site["remote_root"])
        except BaseException:
            self.ftp.close()
            raise

    def close(self):
        self.ftp.close()

    def listing(self, directory):
        # 存在しないファイルと権限不足を区別するため、親フォルダーの一覧を取得します。
        entries = []
        for name, facts in self.ftp.mlsd(directory):
            kind = facts.get("type", "unknown")
            if kind in {"cdir", "pdir"}:
                continue
            entries.append({"name": name, "type": kind,
                            "bytes": int(facts["size"]) if "size" in facts else None})
        return entries

    def stat(self, remote):
        matches = [x for x in self.listing(posixpath.dirname(remote))
                   if x["name"] == posixpath.basename(remote)]
        if len(matches) > 1:
            raise TransferError("サーバー側のファイルを一意に確認できませんでした。")
        return matches[0] if matches else None

    def download(self, remote, local):
        with Path(local).open("xb") as stream:
            self.ftp.retrbinary("RETR " + remote, stream.write)

    def upload(self, local, remote):
        with Path(local).open("rb") as stream:
            self.ftp.storbinary("STOR " + remote, stream)


class SFTPBackend:
    def __init__(self, site):
        self.site = site
        executable = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32/OpenSSH/sftp.exe"
        if not executable.is_file():
            raise TransferError("Windows標準のOpenSSHクライアントが見つかりません。")
        host = site["host"]
        if ":" in host:
            host = "[" + host + "]"
        self.args = [str(executable), "-F", "NUL", "-b", "-", "-P", str(site["port"]),
                     "-i", str(Path(site["identity_file"]).resolve()),
                     "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=yes",
                     "-o", "PasswordAuthentication=no", "-o", "IdentitiesOnly=yes",
                     "-o", 'UserKnownHostsFile="' + str(Path(site["known_hosts"]).resolve()).replace("\\", "/") + '"',
                     "-o", "ConnectTimeout=20", "-o", "ConnectionAttempts=1",
                     "-o", "ServerAliveInterval=15", "-o", "ServerAliveCountMax=2",
                     site["user"] + "@" + host]

    def close(self):
        pass

    @staticmethod
    def quote(value):
        value = safe_text(str(value)).replace("\\", "/")
        if any(c in value for c in '"*?[]{}'):
            raise TransferError("SFTPのパスに未対応の記号が含まれています。")
        return '"' + value + '"'

    def run(self, command):
        result = subprocess.run(self.args, input=command + "\nquit\n", text=True,
                                encoding="utf-8", errors="replace", capture_output=True,
                                timeout=300, shell=False)
        if result.returncode:
            if "Host key verification failed" in result.stderr:
                raise TransferError("SFTPのサーバー鍵を確認できません。確認済みのknown_hostsを指定してください。")
            raise TransferError("SFTPの接続・操作に失敗しました。接続設定、鍵、権限を確認してください。")
        return result.stdout

    def listing(self, directory):
        result = []
        for line in self.run("ls -lan " + self.quote(directory)).splitlines():
            if not re.match(r"^[bcdlps-][rwxstST-]{9}\s", line):
                continue
            parts = line.split(None, 8)
            if len(parts) != 9 or not parts[4].isdigit():
                raise TransferError("SFTPの一覧形式を確認できませんでした。")
            name = parts[8]
            kind = {"-": "file", "d": "dir", "l": "link"}.get(parts[0][0], "unknown")
            if kind == "link":
                name = name.split(" -> ", 1)[0]
            if name in {".", ".."}:
                continue
            result.append({"name": name, "type": kind, "bytes": int(parts[4])})
        # 非空の未知形式は「空のフォルダー」として扱いません。
        for line in self.run("ls -1a " + self.quote(directory)).splitlines():
            if not line or line.startswith("sftp>") or posixpath.basename(line.strip()) in {".", ".."}:
                continue
            if not any(x["name"] == line or posixpath.join(directory, x["name"]) == line for x in result):
                raise TransferError("SFTPの一覧を安全に解析できませんでした。")
        return result

    def stat(self, remote):
        matches = [x for x in self.listing(posixpath.dirname(remote))
                   if x["name"] == posixpath.basename(remote)]
        if len(matches) > 1:
            raise TransferError("サーバー側のファイルを一意に確認できませんでした。")
        return matches[0] if matches else None

    def download(self, remote, local):
        if Path(local).exists():
            raise TransferError("作業用ファイルが既に存在しています。")
        self.run("get " + self.quote(remote) + " " + self.quote(local))

    def upload(self, local, remote):
        self.run("put " + self.quote(local) + " " + self.quote(remote))


def connect(site):
    return FTPSBackend(site) if site["protocol"] == "ftps" else SFTPBackend(site)


def check_remote_parents(backend, site, remote):
    root = posixpath.normpath(site["remote_root"])
    parent = posixpath.dirname(remote)
    relative = posixpath.relpath(parent, root)
    current = root
    if relative != ".":
        for part in PurePosixPath(relative).parts:
            current = posixpath.join(current, part)
            info = backend.stat(current)
            if info is None or info["type"] != "dir":
                raise TransferError("サーバー側の親フォルダーが存在しないか、リンクが含まれています。")


def snapshot_remote(backend, remote, destination):
    info = backend.stat(remote)
    if info is None:
        return None
    if info["type"] != "file":
        raise TransferError("サーバー側の対象は通常のファイルに限定しています。")
    backend.download(remote, destination)
    state = file_state(destination)
    if info.get("bytes") is not None and info["bytes"] != state["bytes"]:
        raise TransferError("取得中にサーバー側のファイルサイズが変化しました。計画を作り直してください。")
    return state


def make_plan(site_name, direction, local_value, remote_value, backend_factory=connect):
    get_site(site_name)
    with site_lock(site_name):
        return _make_plan(site_name, direction, local_value, remote_value, backend_factory)


def _make_plan(site_name, direction, local_value, remote_value, backend_factory=connect):
    if direction not in {"upload", "download"}:
        raise TransferError("転送方向が正しくありません。")
    site = get_site(site_name)
    local = local_path(site, local_value)
    remote = remote_path(site, remote_value)
    local_before = file_state(local)
    if direction == "upload" and local_before is None:
        raise TransferError("アップロード元のファイルが見つかりません。")
    job = JOBS / uuid.uuid4().hex
    job.mkdir(parents=True)
    if local_before is not None:
        shutil.copyfile(local, job / "local-before.bin")
        if file_state(job / "local-before.bin") != local_before or file_state(local) != local_before:
            raise TransferError("計画作成中にパソコン側のファイルが変化しました。")
    backend = backend_factory(site)
    try:
        check_remote_parents(backend, site, remote)
        remote_before = snapshot_remote(backend, remote, job / "remote-before.bin")
    finally:
        backend.close()
    if direction == "download" and remote_before is None:
        raise TransferError("ダウンロード元のファイルが見つかりません。")
    source = "local-before.bin" if direction == "upload" else "remote-before.bin"
    plan = {"version": 1, "id": job.name, "created": time.time(), "site": site_name,
            "site_fingerprint": fingerprint(site), "direction": direction,
            "local": str(local), "remote": remote,
            "local_before": local_before, "remote_before": remote_before,
            "source": source, "source_state": file_state(job / source)}
    save_new_json(job / "plan.json", plan)
    return {"計画ファイル": str(job / "plan.json"), "承認番号": fingerprint(plan),
            "接続先": {"登録名": site_name, "ホスト": site["host"], "方式": site["protocol"]},
            "操作": "アップロード" if direction == "upload" else "ダウンロード",
            "パソコン側": str(local), "サーバー側": remote,
            "上書き": (remote_before if direction == "upload" else local_before) is not None,
            "転送内容": plan["source_state"], "バックアップ保存先": str(job),
            "説明": "実際の転送は未実行です。承認後にapplyを実行してください。"}


def audit(job, status, detail=None):
    event = {"時刻": time.strftime("%Y-%m-%dT%H:%M:%S%z"), "状態": status}
    if detail:
        event["情報"] = detail
    with (job / "events.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(event, ensure_ascii=False) + "\n")


def apply_plan(plan_path, approval, backend_factory=connect):
    path = Path(plan_path).resolve(strict=True)
    if path.name != "plan.json" or path.parent.parent != JOBS.resolve():
        raise TransferError("このツールで作成した計画ファイルを指定してください。")
    plan = load_json(path)
    if fingerprint(plan) != approval:
        raise TransferError("承認番号が計画と一致しません。")
    with site_lock(plan["site"]):
        return _apply_plan(path, approval, backend_factory)


def _apply_plan(plan_path, approval, backend_factory=connect):
    path = Path(plan_path).resolve(strict=True)
    job = path.parent
    if path.name != "plan.json" or job.parent != JOBS.resolve() or not re.fullmatch(r"[0-9a-f]{32}", job.name):
        raise TransferError("このツールで作成した計画ファイルを指定してください。")
    plan = load_json(path)
    if fingerprint(plan) != approval:
        raise TransferError("承認番号が計画と一致しません。")
    if plan.get("version") != 1 or plan.get("id") != job.name:
        raise TransferError("計画の形式が正しくありません。")
    age = time.time() - plan["created"]
    if age < -60 or age > MAX_AGE:
        raise TransferError("計画の有効期限が切れています。新しい計画を作成してください。")
    site = get_site(plan["site"])
    if fingerprint(site) != plan["site_fingerprint"]:
        raise TransferError("接続設定が変化しました。計画を作り直してください。")
    direction = plan["direction"]
    if direction not in {"upload", "download"}:
        raise TransferError("転送方向が正しくありません。")
    expected_source = "local-before.bin" if direction == "upload" else "remote-before.bin"
    if plan["source"] != expected_source:
        raise TransferError("計画内の転送元が正しくありません。")
    source = job / expected_source
    if file_state(source) != plan["source_state"]:
        raise TransferError("計画の転送内容が変更されています。")
    for filename, expected in (("local-before.bin", plan["local_before"]),
                               ("remote-before.bin", plan["remote_before"])):
        if expected is not None and file_state(job / filename) != expected:
            raise TransferError("計画のバックアップが変更されています。")
    local = local_path(site, plan["local"])
    remote = remote_path(site, plan["remote"])
    if file_state(local) != plan["local_before"]:
        raise TransferError("パソコン側の内容が計画作成後に変わりました。計画を作り直してください。")
    # 排他作成により、同じ計画の二重実行と同時実行を防ぎます。
    try:
        with (job / "started.json").open("x", encoding="utf-8") as stream:
            json.dump({"started": time.time()}, stream)
    except FileExistsError:
        raise TransferError("この計画は実行済み、または実行を開始しています。新しい計画を作成してください。")
    audit(job, "実行開始")
    backend = None
    try:
        backend = backend_factory(site)
        check_remote_parents(backend, site, remote)
        current = snapshot_remote(backend, remote, job / "remote-at-apply.bin")
        if current != plan["remote_before"]:
            raise TransferError("サーバー側の内容が計画作成後に変わりました。計画を作り直してください。")
        if file_state(local) != plan["local_before"]:
            raise TransferError("確認中にパソコン側の内容が変わりました。計画を作り直してください。")
        if direction == "upload":
            audit(job, "サーバー書き込み開始", {"対象": remote})
            backend.upload(source, remote)
            after = snapshot_remote(backend, remote, job / "remote-after.bin")
            if after != plan["source_state"]:
                raise TransferError("転送後の内容が一致しません。バックアップを保持しています。")
        else:
            # 同じフォルダーに仮ファイルを置いて、確認後に転送先へ反映します。
            temporary = local.with_name(local.name + ".ai-transfer-" + job.name + ".part")
            with temporary.open("xb") as destination, source.open("rb") as origin:
                shutil.copyfileobj(origin, destination)
                destination.flush()
                os.fsync(destination.fileno())
            if file_state(temporary) != plan["source_state"]:
                raise TransferError("転送用ファイルの内容が一致しません。")
            if local_path(site, str(local)) != local or file_state(local) != plan["local_before"]:
                raise TransferError("反映直前に転送先が変化しました。")
            os.replace(temporary, local)
            if file_state(local) != plan["source_state"]:
                raise TransferError("反映後の内容が一致しません。バックアップを保持しています。")
        audit(job, "内容確認完了", plan["source_state"])
        save_new_json(job / "result.json", {"完了": True, "内容": plan["source_state"]})
        return {"完了": True, "内容確認": "SHA-256一致", "記録とバックアップ": str(job)}
    except BaseException:
        audit(job, "失敗・要確認", {"注意": "書き込み開始後の失敗では転送先を確認してください。自動再試行は行いません。"})
        raise
    finally:
        if backend is not None:
            backend.close()


def setup():
    print("接続先の登録です。パスワードはこの画面で入力し、AIのチャットには送らないでください。")
    name = input("登録名（例：公開サイト）: ").strip()
    if not re.fullmatch(r"[\w-]{1,40}", name):
        raise TransferError("登録名は40文字以内の文字・数字・ハイフン・下線で指定してください。")
    sites = load_json(SITES) if SITES.exists() else {}
    if name in sites:
        raise TransferError("同じ登録名が存在します。新しい登録名を指定してください。")
    protocol = input("接続方式（1=FTPS、2=SFTP）[1]: ").strip() or "1"
    if protocol not in {"1", "2"}:
        raise TransferError("接続方式は1または2で指定してください。")
    site = {"protocol": "ftps" if protocol == "1" else "sftp"}
    site["host"] = input("ホスト名（ftp.example.com など）: ").strip()
    default_port = 21 if protocol == "1" else 22
    site["port"] = int(input(f"ポート番号 [{default_port}]: ").strip() or default_port)
    site["user"] = input("ユーザー名: ").strip()
    site["remote_root"] = input("サーバー側の操作フォルダー（例：/public_html）: ").strip()
    supplied_root = Path(safe_text(input("パソコン側の操作フォルダー（絶対パス）: ").strip().strip('"')))
    if not supplied_root.is_absolute():
        raise TransferError("パソコン側の操作フォルダーを絶対パスで指定してください。")
    site["local_root"] = str(supplied_root.resolve(strict=True))
    password = None
    if protocol == "1":
        site["encoding"] = input("ファイル名の文字コード（utf-8 または cp932）[utf-8]: ").strip() or "utf-8"
        if site["encoding"] not in {"utf-8", "cp932"}:
            raise TransferError("文字コードはutf-8またはcp932を指定してください。")
        site["credential_target"] = "AISharedTransfer/" + uuid.uuid4().hex
        password = getpass.getpass("パスワード（画面には表示されません）: ")
    else:
        print("SFTPは鍵認証に対応しています。サーバー鍵は事前にご自身で確認してください。")
        site["identity_file"] = str(Path(input("秘密鍵ファイルのパス: ").strip().strip('"')).resolve(strict=True))
        site["known_hosts"] = str(Path(input("確認済みknown_hostsファイルのパス: ").strip().strip('"')).resolve(strict=True))
    validate_site(site)
    output({"登録名": name, **{k: v for k, v in site.items() if k != "credential_target"}})
    if input("この接続先を登録しますか？ 登録する場合は「登録」と入力: ").strip() != "登録":
        print("登録を中止しました。")
        return
    DATA.mkdir(parents=True, exist_ok=True)
    # 接続先一覧の更新前に、既存内容を別名で保存します。
    if SITES.exists():
        shutil.copyfile(SITES, DATA / ("sites-before-" + uuid.uuid4().hex + ".json"))
    if password is not None:
        store_password(site["credential_target"], site["user"], password)
        password = None
    sites[name] = site
    staging = DATA / ("sites-new-" + uuid.uuid4().hex + ".json")
    save_new_json(staging, sites)
    os.replace(staging, SITES)
    print("登録しました。実際のサーバーへの接続・転送はまだ行っていません。")


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="AI共通FTP：計画・承認・バックアップ付きのファイル送受信")
    commands = parser.add_subparsers(dest="command", required=True, title="操作")
    commands.add_parser("setup", help="ご自身の操作で接続先を登録します")
    commands.add_parser("sites", help="登録済みの接続先を表示します")
    listing = commands.add_parser("list", help="サーバー側の一覧を読み取ります")
    listing.add_argument("--site", required=True, help="接続先の登録名")
    listing.add_argument("--remote", default=".", help="操作範囲内のフォルダー")
    for name, description in (("plan-upload", "アップロード計画を作ります"),
                              ("plan-download", "ダウンロード計画を作ります")):
        command = commands.add_parser(name, help=description)
        command.add_argument("--site", required=True, help="接続先の登録名")
        command.add_argument("--local", required=True, help="パソコン側のファイル")
        command.add_argument("--remote", required=True, help="サーバー側のファイル")
    apply = commands.add_parser("apply", help="利用者が承認した計画を実行します")
    apply.add_argument("--plan", required=True, help="計画ファイルのパス")
    apply.add_argument("--approve", required=True, help="承認された計画の承認番号")
    args = parser.parse_args()
    try:
        if args.command == "setup":
            if not sys.stdin.isatty():
                raise TransferError("接続先登録.cmdから、ご自身で登録してください。")
            setup()
        elif args.command == "sites":
            sites = load_json(SITES) if SITES.exists() else {}
            output({name: {key: site[key] for key in ("protocol", "host", "port", "remote_root", "local_root")}
                    for name, site in sites.items()})
        elif args.command == "list":
            site = get_site(args.site)
            remote = remote_path(site, args.remote, allow_directory=True)
            backend = connect(site)
            try:
                # フォルダー自身を含め、操作範囲内のリンクを確認します。
                check_remote_parents(backend, site, posixpath.join(remote, "確認用ファイル"))
                output(backend.listing(remote))
            finally:
                backend.close()
        elif args.command.startswith("plan-"):
            direction = "upload" if args.command == "plan-upload" else "download"
            output(make_plan(args.site, direction, args.local, args.remote))
        else:
            output(apply_plan(args.plan, args.approve))
        return 0
    except TransferError as error:
        output({"エラー": str(error)})
    except ssl.SSLCertVerificationError:
        output({"エラー": "サーバー証明書を確認できません。証明書の検証を有効にしたまま接続設定を確認してください。"})
    except (ftplib.Error, OSError, EOFError, ValueError, KeyError, subprocess.SubprocessError):
        # サーバー応答に認証情報が含まれる可能性があるため、その本文は出力しません。
        output({"エラー": "接続・読み書き・設定の確認に失敗しました。設定と操作記録をご確認ください。"})
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
